# ISSUE022B · v0.0.0-prototype.4 owner 修复范围

本版是私有 staging 安全原型，不发布，不合入主插件，不声明 B1 或上游完整迁移通过。Rust patch、native binary、launcher 均保持 prototype.3 的固定字节；两项独立 owner review FAIL 保留为历史证据。

## 修复

- `externalVariant` 只调用自有、函数类型的 validator，禁止从 Object.prototype 命中 `__proto__`、`constructor`、`toString`、`valueOf`。
- stdout 回调的 method IR validator 异常统一转为 `BridgeFailure(protocol)`，拒绝整个 generation 的 pending/queue，终止子进程；后续显式新请求可建立新 generation，旧请求不重放。
- 单个序列化 frame 超过 `maxInflightBytes` 时，在任何 queue 分支之前返回 backpressure。即使当前繁忙，也不会将永远不可发送的请求塞入队列。
- 新增 `queueTimeoutMs`，默认继承 `timeoutMs`。入队时使用单调时钟绝对 deadline；到期撤销未发送项、释放 queue 字节及 admission，拒绝为 `queue_timeout`，不杀死仍健康的 generation。转 inflight 时清除 queue timer，并独立启动完整 execution timeout。abort、closeSession、host close、generation failure 均清理 queue timer，不允许超时后晚发或重放。
- 数值配置必须是范围内的有限安全整数；Node timer 上限为 2147483647ms。queue count/bytes 可为 0 禁止排队；backoff 可为 0，且最大值不得小于初值；总计预算加法不得超出安全整数。

## 时间契约

这是分阶段有界，不是同一端到端 deadline。startup 使用已有的 probeMs、backoff、handshake timeout；startup waiter 在任何 await 前预留 aggregate admission。queueTimeoutMs 从真正入队开始。执行 timeoutMs 从向子进程派发开始。同步 launcher probe 仍受 probeMs 自身限制；单线程事件循环阻塞会使 timer 回调延后，drain 的单调 deadline 检查防止已过期队列在回调之前被发送。

## 新负例

覆盖三个 externalVariant 路径 × 四个原型名字，使用真实 fake-child JSON own-key 响应；同 generation 的 collateral pending 一起失败，下一 generation 计数证明没有旧请求重放。另覆盖异常 validator、忙/闲状态不可发送帧、queue expiry 后预算复用、等待与执行期限分离、abort/session/host close 清理，以及 89 项非法配置断言和零队列配置。

## 不在本次修复范围

singleton 首次获取后不同调用方配置策略、上游原生开发门禁、12 个 license-material 缺口，以及后续 B1/B2/B3 集成仍单独跟进。本修复不改变 reviewer 判定规则，不用 TypeScript 重写 Rust serde，也不把包安装测试的局部通过扩大为 production/release gate。
