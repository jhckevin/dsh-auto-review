#!/bin/sh
set -eu
label=${1:-remediation}
case "$label" in remediation|final|repro-final) ;; *) exit 64 ;; esac
stage=/srv/pi-lab-dev/tmp/issue022b-native-bridge-prototype
source_root=${BRIDGE_SOURCE_ROOT:-/srv/pi-lab-dev/tmp/issue022b-bridge-worktree}
target_root=${BRIDGE_TARGET_ROOT:-/srv/pi-lab-dev/tmp/issue022b-native-bridge-debian11-target}
binary_output=${BRIDGE_BINARY_OUTPUT:-$stage/codex-approval-protocol-bridge-v2.remediated-gnu2.31}
patch_hash=$(sha256sum "$stage/codex-bridge-v2.patch" | cut -d ' ' -f 1)
image=sha256:d3a75b5ef6faa77d8074c1cb1d41b08e5f9cf6775d6651e87ffe98e41139abc7
trap 'rc=$?; printf "%s\n" "$rc" > "$stage/$label-build.rc"' EXIT
podman run --rm --network none --cpus 2 --memory 4g \
  -v "$source_root:/src:ro" \
  -v "$target_root:/target:rw" \
  -v /srv/pi-lab-dev/tmp/cargo:/cargo:rw \
  -v /srv/pi-lab-dev/tmp/rustup:/rustup:ro \
  -e CARGO_HOME=/cargo -e RUSTUP_HOME=/rustup \
  -e RUSTUP_TOOLCHAIN=1.96.0-x86_64-unknown-linux-gnu \
  -e CARGO_TARGET_DIR=/target -e CARGO_BUILD_JOBS=2 \
  -e CODEX_BRIDGE_PATCH_SHA256="$patch_hash" \
  -e PATH=/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
  -w /src/codex-rs "$image" sh -ec \
  'cargo build --locked --offline --release -p codex-approval-protocol-bridge-prototype && cargo test --locked --offline --release -p codex-approval-protocol-bridge-prototype'
strip --strip-all -o "$binary_output" "$target_root/release/codex-approval-protocol-bridge"
sha256sum "$binary_output"
