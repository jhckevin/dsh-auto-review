#!/usr/bin/env python3
"""Copy only hash-and-git-blob verified recovery material; never caches or git databases."""
import hashlib, json, pathlib, shutil
root = pathlib.Path(__file__).resolve().parent
source = root / "license-recovery"
target = root / "packages/platform/provenance/license-recovery"
target.mkdir(parents=True, exist_ok=True)
result = json.loads((source / "recovery-result.json").read_text())
for group in result["groups"]:
    for item in group["files"]:
        rel = pathlib.Path(item["artifact"])
        path = (source / rel).resolve()
        if not path.is_relative_to(source.resolve()) or (source / rel).is_symlink(): raise ValueError("unsafe recovery path")
        data = path.read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if len(data) != item["bytes"] or hashlib.sha256(data).hexdigest() != item["sha256"] or blob != item["gitBlobSha1"] or not item["gitBlobVerified"]:
            raise ValueError("unverified recovery material")
        dest = target / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)
for name in ["recovery-result.json", "inventory.json"]:
    shutil.copyfile(source / name, target / name)
supplement = json.loads((source / "published-supplement.json").read_text())
for row in supplement["rows"]:
    if not row["fullTextRecovered"]: continue
    archive = source / row["archiveArtifact"]
    if hashlib.sha256(archive.read_bytes()).hexdigest() != row["lockChecksum"]: raise ValueError("crate checksum mismatch")
    for item in row["files"]:
        path = (source / item["artifact"]).resolve()
        if not path.is_relative_to(source.resolve()): raise ValueError("unsafe published artifact path")
        if hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]: raise ValueError("published content mismatch")
        dest = target / item["artifact"]; dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(path, dest)
    dest = target / row["archiveArtifact"]; dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(archive, dest)
shutil.copyfile(source / "published-supplement.json", target / "published-supplement.json")
