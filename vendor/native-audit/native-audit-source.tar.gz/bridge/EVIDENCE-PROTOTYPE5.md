# v0.0.0-prototype.5 · generation race 实测证据

冻结源码提交：`de31e9e6e05a5aa4e14c7858f6a33d1c4c097518`。本轮只修复旧进程异步事件污染新代次的竞态，详情见 `PROTOTYPE5-GENERATION-ISOLATION.md`。

## 先失败，再修复

- 同一个新增真实 pipe 回归，先针对 prototype.4 冻结镜像运行：exit 1，第一轮即失败 `BridgeFailure: write EPIPE`。记录 `evidence/owner-prototype5-before-race.log`，SHA256 `ade268f2422815f746e7a4c067edefa93787e118f7c71cbd5ed0b0234e9a4ad1`。
- 修复后快速完整回归：21/21 通过，0 fail/cancel/skip。记录 `evidence/owner-prototype5-after-race.log`，SHA256 `b955f1716ff3159089b831169f1eda6ddcb54dfcf05f383a6dd7b037c2a7b13f`。
- 最终重新打包、离线安装两个 private prototype.5 tarball：21/21 owner 加 9/9 包场景，脚本 exit 0。记录 `evidence/package-prototype5-final.log`，SHA256 `a5fa40fe218e4f0c361dc014d34aca8535abdff148618456a42aee2d79d70511`。
- 新回归在真实 Rust child + Landlock 下连续 12 次 SIGSTOP、1MiB pipe 堵塞、20ms 后 abort、零 backoff 立即新 handshake。每轮旧请求 cancelled、新代次恰增加一次，后续合法请求仍成功。不是改用 mock 或添加重启延迟掩盖问题。
- 安装测试容器 uid65532、root-owned 安装包、只读 filesystem、network=none、16MiB noexec tmpfs；same-UID 安装依然按预期拒绝。

## 冻结对象

| 对象 | SHA256 |
| --- | --- |
| owner 与 host 副本 | `7e9bc2e8708568e2b9322ee0f35e164bf90107d6fee254fc52408d7111a4d1c9` |
| owner tests | `1703d2c8263a4895301889a927125ee83ba42a64b9c163777b09c254db4a434e` |
| host pinned provenance | `ef6149e4fac9b5145f429bf34ff9a6c181ec1d6c1a1c5881a759fc812444e320` |
| SBOM，仅 metadata version 更新 | `d8aa5fb68dff0edaf264aa720f2dc49189958db8b09d15a2a3146bb9f4f34358` |
| host prototype.5 tgz | `df243ede77d6477b7c561e194d2e603d3c8960bd9bc06234d8b791b2d475b066` |
| platform prototype.5 tgz | `40b3132ba3cdc9f35664c820651415dd6e35582fbbd752b68ab9655cdbd5057f` |
| 安装测试 image | `495fbd85d47dcee6ccf19450a864c53893d2a90430fa4737b1683597a262ca93` |

Rust patch `35c5196aee02d0a4dd229a0faf7fe782d64c435042ecc675940be8b1b785eebd`、binary `be0889b1bc892a16c8dd026f552a8152e4d633723d2495e94ebb4fd4b4351ffc` 保持不变；没有 Rust 重编译。12 个 license-material 与受控上游开发验收 runner 缺口未由本次修复处理，完整门禁仍不成立。尚未收到两位 reviewer 对 prototype.5 的最终结论，不能提前写 PASS，不发布或合入主插件。
