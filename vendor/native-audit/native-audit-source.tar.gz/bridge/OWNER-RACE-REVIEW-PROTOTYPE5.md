# Independent prototype.5 generation-isolation review

Date: 2026-09-02. Reviewer: bridge_security_review.
Verdict: PASS for this frozen race-remediation scope; P0=0/P1=0/P2=0 new findings in the reviewed diff. This is not full B1 or release acceptance.

## Frozen target

- Commit: `de31e9e6e05a5aa4e14c7858f6a33d1c4c097518`.
- Owner SHA256 verified: `7e9bc2e8708568e2b9322ee0f35e164bf90107d6fee254fc52408d7111a4d1c9`.
- Exact image: `sha256:495fbd85d47dcee6ccf19450a864c53893d2a90430fa4737b1683597a262ca93`.
- Source and report base: `/srv/pi-lab-dev/tmp/issue022b-native-bridge-prototype`.
- Compared owner source against previous frozen commit `198ac99ddf8bf136fdfb4a4373b65eaca2ca22ec`; initial working tree was clean.

Only this report was written via remote safe apply_patch. No source changes or large builds were made by this reviewer. The previous prototype.4 FAIL report remains historical evidence.

## Independent runtime verification

The exact image was run twice with `--pull=never --rm --network=none --read-only --tmpfs /tmp:rw,noexec,nosuid,nodev,size=16m`; both executions exited 0. The second complete output showed 21 tests, 21 pass, no failures/skips/cancellations, duration 5025.068967ms, plus all 9 package cases passed under uid65532.

The new real-pipe regression performs twelve successive cycles with zero backoff. Each cycle stops the real bridge, buffers a 1MiB request, cancels after 20ms, immediately starts the replacement with no delay, and requires exactly one generation increment plus a successful subsequent approved request. This is not a mock-only race test and does not conceal the race by delaying or replaying the replacement request.

Additionally the reviewer reran the original standalone reproduction, unchanged apart from selecting the new image: SIGSTOP the real process, send a 1,000,000-character rejection request, wait 20ms, abort, immediately request handshake, with baseBackoffMs=maxBackoffMs=0 and timeoutMs=1000.

Observed result:

```json
{"first":"cancelled","next":"ok","state":"running","generation":2}
```

The old result was next.kind=write / message=write EPIPE / state=backoff. The independent reproduction therefore confirms the previously identified stale-write race is resolved on the frozen version. Every transient container was removed and hosts were explicitly closed.

## Diff review

- A common isCurrent(child,generation) predicate now requires both exact child identity and generation identity.
- The stdin write completion captures its originating child/generation and ignores late errors from retired processes before calling restart. Synchronous write errors receive the same guard, and writeBlocked updates do not leak into a new generation.
- After attaching AbortSignal, send rechecks current child/generation AND exact pending item before writing. An immediately triggered abort cannot proceed to write into the retired/new process.
- Execution timeouts require both current generation and exact pending-item identity. Abort callbacks also require the same generation and current pending/queued membership.
- Queue timeout callbacks require current generation and queue membership. Existing expiry/transfer/close paths clear timer and remove/release the item; stale timers cannot settle twice or drain a replacement queue.
- Stderr and stdin drain handlers now check child/generation before charging stderr bytes or modifying backpressure. Error/exit handlers, stdout entry and each parsed stdout frame are likewise generation-bound.
- Handshake continuation checks current generation, and late startup catch cannot reset an already retired/replacement generation. Pre-child startup failure is constrained to the original startGeneration and absence of a child.
- No backoff delay was imposed as a workaround; zero backoff remains supported and tested. No implicit replay was added.

The existing queued deadline, configuration, prototype-key, framing, startup/session-close and package rejection tests all remained green in the independently executed 21+9 suite.

## Disposition and limits

The P2 in OWNER-REMEDIATION-REVIEW-PROTOTYPE4.md is resolved for the frozen commit and exact image above. No further issue was found in this generation-isolation diff and associated regression scope.

This does not certify all possible concurrency schedules or unrelated code. Rust was not rebuilt; its prior source/binary evidence remains separate. CI license gaps and the unimplemented upstream development runner remain blocked under their separate fail-closed gate. Complete B1 protocol/store/hooks, native Harness integration and production/release acceptance are not completed by this scoped PASS.
