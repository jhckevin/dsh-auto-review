# Independent Rust-only remediation review

Date: 2026-09-02. Reviewer: bridge_security_review.

Verdict: PASS for the frozen Rust remediation scope described below; P0=0/P1=0/P2=0 newly identified findings in that scope. This does NOT change the original whole-prototype FAIL into PASS, does NOT complete ISSUE-022B/B1, and is NOT production/release acceptance.

## Frozen evidence

- Upstream HEAD verified: `9f97cb79eb15b38d24c552c56fe24e211ff9cf3a`.
- `codex-bridge-v2.patch` SHA256: `35c5196aee02d0a4dd229a0faf7fe782d64c435042ecc675940be8b1b785eebd`.
- Independent `git diff HEAD --binary | sha256sum` from `/srv/pi-lab-dev/tmp/issue022b-bridge-worktree` produced the SAME patch SHA256.
- `codex-approval-protocol-bridge-v2.remediated-gnu2.31` SHA256: `be0889b1bc892a16c8dd026f552a8152e4d633723d2495e94ebb4fd4b4351ffc`.
- `rust-remediation.test.mjs` SHA256: `1f5d3a706e6ef760f8f4294b851081b40edb7af71d7a7914492d97f4764bbc3e`.
- Existing historical FAIL remains in `SECURITY-REVIEW-V2.md`, SHA256 `09aab008c3d3b690198abc59d974034a24582b7bf2231a68ba92e13e30f0c874`.

All paths without an absolute prefix refer to `/srv/pi-lab-dev/tmp/issue022b-native-bridge-prototype`. This reviewer did not modify Rust/Node source or execute a Rust build. Only this report was added using remote safe apply_patch.

## Independent executed verification

Command: `/srv/pi-lab-dev/toolchains/node-v24.8.0-linux-x64/bin/node --test rust-remediation.test.mjs`.

Observed: 6 tests, 6 pass, 0 fail/cancelled/skipped/todo; total duration 136.030734ms. The test launches the pinned remediated binary through the DSH Landlock launcher, not a JavaScript mock.

1. Twelve combinations of prefix length and Chinese/Latin-accent/emoji invalid enum values returned bounded UTF-8 Serde errors. A subsequent approved request succeeded in the same process.
2. Handshake succeeded after native network/filesystem/indirect-syscall probes; compiled patch SHA matched the frozen patch file.
3. Raw i64 extrema and values beyond JavaScript's safe integer range retained exact decimal IR/canonical wire. Overflow, float/exponent, null and raw `-0` were rejected by pinned Serde. The earlier assumption that raw `-0` should be normalized to integer zero is not retained.
4. Unknown fields remained ignored; duplicate known fields and canonical/alias duplicate environment IDs rejected.
5. A 2,300,000-character reason caused the canonicalWire+IR serialized response to exceed 4MiB: result was correlated `resource_limit` with the same id/session, followed by successful approved processing in the same process.
6. Nested x64 NonZeroUsize max `18446744073709551615` survived as opaque additionalPermissionsWire and canonical wire, with no lossy additionalPermissions object emitted.

Additional reviewer-authored inline smoke sequence executed six real requests successfully: core apply-patch with i64 minimum, core ask-for-approval alias, core reviewer alias, v2 command response, v2 file response, and exec with absent additional permissions. Result: six successes; patch startedAtMs `-9223372036854775808`; absent additionalPermissionsWire exactly null.

Existing `final-build.log`/`rust-remediation-results.log` were read. They report two Rust unit tests passed plus the implementer's six process tests. The two Rust unit tests were source-reviewed but not independently rebuilt/rerun by this reviewer. The six process tests WERE independently rerun as stated above.

## Source review

Source: `/srv/pi-lab-dev/tmp/issue022b-bridge-worktree/codex-rs/approval-protocol-bridge-prototype/src/main.rs`.

### Unicode error remediation: original P1-1

Lines 183-192 now retreat from MAX_ERROR to a valid UTF-8 character boundary before truncate. Zero is always a valid boundary, so the loop cannot underflow. Original panic reproduction is covered by the larger multilingual process test and continued same-process use. This Rust-specific finding is resolved for the frozen source/binary.

### Seccomp remediation: original P1-5

Lines 386-435 now use a minimal native x86_64 syscall allowlist with default EPERM and architecture mismatch kill. x32-numbered calls cannot match the native allowlist. io_uring, clone3, ptrace, process_vm and unlisted open/network operations do not fall through to ALLOW.

Lines 489-505 probe x32 getpid, io_uring_setup, clone3 and process_vm_readv with empty/invalid arguments and require EPERM rather than accepting ENOSYS/EINVAL/EFAULT. This avoids relying on disabled kernel features as proof of policy. Lines 509-524 still apply RLIMIT_AS/FSIZE/NOFILE/NPROC, no_new_privs, filter and probes before handshake.

Successful real handshake establishes these probes passed on this server. The source explicitly states this parser bridge does not replace the parent Harness sandbox. No claim of universal malicious-code sandboxing or cross-kernel compatibility is made. This Rust-specific finding is resolved for the frozen source/binary and tested environment.

### Bounded response encoding: Rust part of original P2-1

Lines 276-318 implement BoundedFrame::Write. Each append checks saturating length before mutation, marks overflow, and returns an error. Serialization occurs into this bounded logical frame before stdout receives any part of it. On overflow, the partial frame is discarded and a small same-id/session resource_limit response is encoded using the same bounded writer; processing then continues.

Non-resource serialization errors are not mislabeled as resource errors. MAX_LINE excludes the newline delimiter and matches the Rust input reader's definition. CanonicalWire/IR construction still allocates under the input bound and RLIMIT_AS; the source explicitly distinguishes that from final encoded-frame size. Vec capacity/RSS is not claimed to equal MAX_LINE exactly.

The Rust response-overflow behavior is resolved. The separate Node coalesced-chunk frame parsing defect was NOT re-reviewed or closed here.

### Nested integer preservation

ExecIrV1 lines 72-73 and custom serializer lines 166-180 serialize AdditionalPermissionProfile using the actual upstream Serialize implementation into string|null. This avoids passing NonZeroUsize values through serde_json Value -> JavaScript Number as authorization data. The original canonical wire remains directly serialized from the upstream type.

The field shape changed from additionalPermissions to additionalPermissionsWire within an unreleased prototype. All Node schemas/consumers/package handshake provenance must be updated together before integration; consumers must not JSON.parse this opaque wire into lossy authorization data. That Node integration remains outside this review.

### Change surface

The upstream diff contains four files only: workspace Cargo.lock, workspace Cargo.toml, added bridge Cargo.toml and added bridge main.rs. Existing upstream protocol implementations were not altered. This review assesses the adapter and these remediations, not complete parity coverage of every upstream type/method.

## Explicit limitations and remaining gates

- No Node owner lifecycle, input allocation, manifest trust, response schema or package-install gate was re-reviewed; those implementations were changing concurrently.
- This was NOT a second clean offline reproducibility build. The new Rust build was cached incremental according to supplied logs. The previous clean-build evidence cannot be transferred to this new hash.
- Independent source-to-patch equality, artifact hash and compiled handshake provenance were checked, but they do not substitute for a separate clean reproducible build.
- Linux/glibc minimum-platform matrix, root-owned/nonroot packaged installation, SBOM/license validation, mandatory CI and whole-system B1/DSH adapter acceptance remain separate gates.
- Host clock/OS/chunking and adversarial workload breadth beyond the listed tests are not exhaustively proven.
- The old report must be preserved as historical evidence. Only its Rust P1-1, Rust P1-5 and Rust response-overflow subproblem are resolved by this scoped review.
