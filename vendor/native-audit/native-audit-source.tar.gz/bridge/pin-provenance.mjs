import {readFileSync, writeFileSync} from "node:fs";
import {isDeepStrictEqual} from "node:util";
const value = { package: JSON.parse(readFileSync("packages/platform/package.json", "utf8")),
  manifest: JSON.parse(readFileSync("packages/platform/artifact-manifest.json", "utf8")) };
const target = "packages/host/expected-provenance.json";
if (process.argv[2] === "--update") writeFileSync(target, JSON.stringify(value, null, 2) + "\n");
else if (!isDeepStrictEqual(value, JSON.parse(readFileSync(target, "utf8")))) throw new Error("Host provenance pin differs; explicit reviewed update is required");
