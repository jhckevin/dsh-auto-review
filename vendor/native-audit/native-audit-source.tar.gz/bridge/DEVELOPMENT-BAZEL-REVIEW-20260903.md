# ISSUE #5：formatter 冻结与 Bazel 真实诊断

初次诊断结论（历史记录，下方有后续解除阻碍）：**开发门禁尚未完成，Bazel 阶段阻断**。没有替换现有制品 manifest、
没有改写失败为通过，也没有启动额外 Rust 全量构建。

## 已核对并冻结

- 原 c 流程的 test（2 个测试）、fix、fmt 返回成功；fmt 修改源码使 runner
  按设计拒绝该次最终验收。原 c 目录与日志保持不变。
- 独立对比 c 的 `layout-main.rs`、`layout-main_tests.rs` 与当前源：变化为
  import 逐项展开、换行、尾逗号和表达式格式，未见逻辑、权限或常量变化。
- 新开发补丁 SHA256：
  `5cb90364c0a728dc97c278815905c5f6469a9139563fb08d17808908c1bef5c7`。
  冻结提交 `480d0ae`；原 `codex-bridge-v2.patch` 未覆盖。runner 自测 11/11，
  这不是新冻结源的完整上游流程验收。

## 镜像与真实失败

验证了 BCR LLVM 0.8.11 MODULE 元数据经 gh-proxy.com 的原始 GitHub 镜像：
8213 bytes，SHA256 `0f8c30b74be64f0e91764e925d0f562c70e8d85b6cea912f724d6b3753d6a33f`，
与固定 `MODULE.bazel.lock` 一致。

诊断使用独立 HOME、Bazel batch/JVM512MiB/jobs1；downloader 只重写 BCR 元数据
到该镜像，拒绝未评估的大型源码下载。没有修改上游 justfile/MODULE 或跳过步骤。

- `just bazel-lock-update`：exit 37，约 41.67 秒；日志 SHA256
  `d954af36223f304aef62bd09efeea1e01a65e328fdf1d5b2a48bd0fd9bef9eaf`。
- `just bazel-lock-check`：exit 1，约 1.73 秒；日志 SHA256
  `b8cda1c53572b301b1a429b6a0e00e95e460b0db4c3197ee3dd089ed515b8865`。
- 两个日志均有完整结束标志，未溢出，无信号终止。

实际阻碍：上游 `MODULE.bazel` 第 552–563 行的 v8 `archive_override` 要求
完整 `v8/v8` 的 `15.0.245.2.tar.gz`，并非仅 registry 小元数据。
完整 URL 被诊断下载边界明确拒绝。本轮要求“不全量 fetch LLVM/V8”，因此
保留失败，不擅自扩大下载。失败后源码补丁 SHA 不变，没有伪造锁文件更新。

原始证据保留在服务器工作区：
`/srv/pi-lab-dev/tmp/dsh-bazel-gates-20260903.GXELwh`，含 env、downloader 配置、
执行脚本、两条日志及退出/时间/SHA 记录。该 HOME 占用 187MiB，检查时工作卷
余量约 6.8GiB。

若继续，需先对完整 V8 源码及后续依赖的镜像、完整性与磁盘预算单独评估；
成功更新/检查 Bazel lock 后重新冻结最终补丁，再开启一个新的完整受控流程。
不能把上述有界失败诊断当作正式 Bazel PASS，也不能只重命名已有 Rust 日志。

## 后续：有界依赖评估后独立 Bazel 步骤通过

澄清：前述“不全量 fetch”是协调者要求避免盲目大下载，并非用户禁止必要依赖。
逐一核验镜像、固定 integrity 与空间后，必要源码获准下载；未编译 LLVM/V8。

| 文件 | 压缩/下载字节 | 解包 regular-file 字节 | SHA256 |
|---|---:|---:|---|
| V8 15.0.245.2 | 32838188 | 163470291 | 164f3d3e0a8b4c02a386d3a88d1b1133d37e5c20be0239fecdcdde414a4340d5 |
| LLVM 22.1.8 source | 171128113 | 2023722863 | 0a120cd02aa4319887b938ed98f34907563e9b4bcdd4a2aed23a1a05dd5a8157 |
| bsdtar Linux amd64 | 1980392 | 不适用 | ae24dbc3ecf6ad628c2fdd205a52347fd4446589e750469766669e25cb80e22b |

21 个 registry 规则源码合计下载 39223603 B、解包 99935767 B；另含明确固定的
skylib/rules_rust/stardoc/Cargo/toml2json。政策登记在 `development-mirrors.json`。
gh-proxy 曾出现 403/429，bsdtar 使用 ghfast.top 镜像且全量 hash 与上游 pin 相符。

独立诊断最终实际结果（同一诊断目录，`*-bsdtar` 文件）：

- `just bazel-lock-update` exit 0，21.497 秒，1089 B 完整日志，SHA
  `0d49bccb37ee9a2fd48ea6ce28737b73072fa928c9951087d4f8fc0b790f35c4`。
- `just bazel-lock-check` exit 0，10.178 秒，1066 B 完整日志，SHA
  `95e5187c4c9aa476d4ebfa299cf8f06418dae9334be61193c12e2db5bc74e5f1`。
- 无 overflow、signal、spawn error。MODULE.bazel.lock 无变化；源码补丁仍 5cb90364…。

该诊断仍使用了上游 `.bazelrc` 默认 OS HOME 下载/变换仓库缓存，故只证明命令
真实成功，不声称干净 Bazel 状态。新 runner 镜像模块明确固定新 output_user_root、
repo_contents 和 disk cache，并绑定配置/真实 Bazel hash，须另跑完整受控流程。
历史所有非零日志保持原样；不将此次两步骤日志拼接为旧完整 runner 的成功结果。
