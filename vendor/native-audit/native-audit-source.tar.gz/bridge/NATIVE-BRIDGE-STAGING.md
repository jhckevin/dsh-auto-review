# ISSUE-022B 原生协议桥接临时工作区

本仓库是独立 staging，不是主插件仓库；不发布、不证明 ISSUE-022B 已完成。
唯一 Rust 来源为固定上游 `9f97cb79eb15b38d24c552c56fe24e211ff9cf3a` 加 `codex-bridge-v2.patch`。
`src/`、旧 `Cargo.toml`、旧 `bridge-owner.mjs` 是未纳入 Git 的 V1 留存，不参与当前构建。

## 信任边界

运行用户必须非 root。bridge、launcher 及其所有祖先必须 root-owned、
无符号链接，且运行用户不可写；不能通过同 UID chmod 555 取得信任。
生产部署需要 root-owned 的只读镜像层或挂载。Node 仍对同一打开 fd
核对 regular file、owner、size、hash，通过 /proc/self/fd 执行，禁止 JS 降级解析。

平台 manifest 和 package.json 有界读取并检查可信路径，必须与主机包
独立固定的 expected-provenance.json 完整一致；平台不能自报期望 hash。
pin-provenance.mjs --update 只能作为人工审查过的版本更新步骤，
CI 仅运行 --check。模拟桥接脚本只用于测试，不出现在生产 tarball。

## 协议与生命周期

原始 wire 永远以字符串跨越 Node/Rust 边界；i64 为十进制字符串。
additionalPermissionsWire 保留真实上游序列化，不在 JS 解析后进行权限判定。
未知字段、别名、默认值等由真实上游 serde 处理，不另造近似 TS parser。

所有请求在启动和序列化前检查 primitive 类型和原始字节上限；
await 启动后重新检查 session/host。关闭、取消、超时、协议异常
终止相关 generation，不自动重放；排队和 inflight 都有数量/字节预算。
按每个响应帧而非整个 stdout chunk 限额，并按 method 校验 IR。
合法输入导致响应超限时由 Rust 返回 resource_limit，保持进程可用。

## 构建与分发

Debian 11 基线构建镜像固定为
`sha256:d3a75b5ef6faa77d8074c1cb1d41b08e5f9cf6775d6651e87ffe98e41139abc7`。
底层 Debian 镜像已固定 digest；准备镜像的 APT 元数据不是时间锁定的，
因此只在实际 builder image ID 和 builder-dpkg.txt 相同前提下声称环境一致。
Cargo 使用 --locked --offline，编译容器 network=none，源码只读。

run-package-e2e.sh 构建 root 安装、非 root 运行、只读根文件系统、
network=none 的临时测试容器，验证宿主/平台双 tarball。
ci-check.sh 是组合门禁：制品和许可证、容器测试、干净源码重建缺一不可。
clean-rebuild-ci.sh 不沿用旧 target；它需要已准备好的 builder 和 Cargo 缓存。

当前 npm 包名仅为未发布原型占位名；正式命名应为项目自有
@jhckevin/auto-review-*。必须保留上游 LICENSE/NOTICE，
不得以去品牌为由删除法定版权归属。

## 尚未完成

- 当前 SBOM 是目标 normal/build 输入图，不等于全部静态链接清单或法律认证。
- license-audit.json 当前记录缺少源可证许可证文本的组件；组合门禁真实失败。
- 原型安全/协议历史 FAIL 留在各 REVIEW 文件；局部 Rust PASS 不替代全模块审查。
- 此桥接只覆盖已实现的七个 wire 方法，B1/B2/B3 其余调用链另行完成。
- 禁止将旧 patch 的复现结果移用于新 patch；每次版本都需要新证据。
- 固定上游开发门禁尚未满足：sibling *_tests.rs 布局、just fmt、just fix -p、just test/nextest，以及 Cargo.lock 变更的 bazel-lock-update；直接 cargo test 不能冒充这些门禁。此冻结补丁后续必须用独立 ISSUE 修正并审查。
