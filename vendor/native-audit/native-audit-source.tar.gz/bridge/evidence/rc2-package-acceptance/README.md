# rc2 package acceptance

The frozen host/platform npm archives are identified by `host-pack.json` and
`platform-pack.json`. No model API or real user conversations were involved.
The platform includes source-bound f development evidence and official launcher
source materials. Two Rust 1.95 clean builds produced byte-identical binaries.

The first inherited-fixture run failed one of 25 tests: a newly copied test
binary had 0755 rather than the test's required 0555 permissions. No production
package bytes were changed. A cold-install preparation check also rejected the
inherited host-only directory because it contained a platform dependency.

The corrected additional fixture uses fresh `/cold-install` and
`/cold-host-only` projects with explicit package manifests and npm `--prefix`.
It verifies actual package versions, platform absence in host-only, and native
execution from cold-install. The existing upgrade/mutation cases are retained.
The final nonroot65532, read-only, network-none run passed 25 owner/scope tests
and 13 package modes, with exit0 and OOMKilled=false. The fixture image is
`2ead0399b266a179aa42105fce90706fdc51a042cad9815e052b7b398e49a8c3`.

This is a fresh npm project installation inside a controlled inherited OS image,
not a claim of a pristine operating system, full Guardian migration, or legal
certification. Raw earlier failure logs are retained, not relabelled as success.
