use super::*;

#[test]
fn frame_limit_rejects_before_appending_overflow() {
    let mut frame = BoundedFrame {
        bytes: Vec::new(),
        exceeded: false,
    };
    frame.write_all(&vec![b'x'; MAX_LINE]).unwrap();
    assert!(frame.write_all(b"overflow").is_err());
    assert_eq!(frame.bytes.len(), MAX_LINE);
    assert!(frame.exceeded);
}

#[test]
fn unicode_errors_are_bounded_at_character_boundaries() {
    for prefix in ["", "x", "xx", "xxx"] {
        for character in ["中", "é", "😀"] {
            let original = format!("{prefix}{}", character.repeat(5000));
            let error = bridge_error("serde", original.clone());
            assert!(error.message.len() <= MAX_ERROR);
            assert!(original.starts_with(&error.message));
            assert!(original.is_char_boundary(error.message.len()));
            assert!(MAX_ERROR - error.message.len() < 4);
        }
    }
    assert_eq!(bridge_error("serde", "short").message, "short");
}
