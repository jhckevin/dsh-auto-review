# Refs #5：f 受控开发执行与首个候选构建绑定

本目录是选择性复制的真实 f 执行证据，不包含 HOME、下载缓存、变换仓库或 target。
`acceptance-receipt.json` 记录逐文件 SHA/大小；复制后使用真实候选 manifest 再次
执行 `verifyDevelopmentRun`：accepted=true，固定 11 步完整通过。runner 实现
冻结于 `7c3c59623a565b0e615d6e8932d72e18eeea80db`，没有事后改写 implementation。

源补丁 `5cb90364c0a728dc97c278815905c5f6469a9139563fb08d17808908c1bef5c7`，
Rust 1.95.0；18 个有效 Cargo 配置候选检查、6 个实际 Rust 工具 hash、固定 Bazel
配置和前后源码状态已绑定。nextest 2/2、fix、fmt、Bazel update/check 都实际成功。
测试使用共享 Cargo 编译缓存；Bazel output/变换缓存和 HOME 为本轮新建。此证据
不是无缓存完整 Rust clean build，也不等于恶意同 UID 操作者无法伪造的签名证明。

`candidate/` 保存第一遍真实新二进制的构建/源/容器记录：
7,937,504 bytes，SHA `dd6ad6bf0ebec9ae36d40fdaa91dda8aabb21bc3191366a5b0e25b8f5e10888b`，
build exit 0、OOMKilled=false，源码前后相同。该 manifest 专门用于本候选绑定；
没有覆盖旧 rc1 manifest。二进制本体不重复纳入此证据目录。

验收范围仅是固定 bridge 的开发工作流及首构建绑定，`releaseEligible=false`。
第二 clean build 重现、实际 rc2 打包安装/协议/安全测试与完整产品验收分别处理；
后续若完成，应新增独立 receipt，不能把本目录历史“尚未建立”描述当作总状态。
最终公开 native source archive 必须从包含完整 rc2 材料映射的最终候选树生成。

旧 c/d/e 原始轨迹保留在执行服务器，不把它们重新标作当前强化 runner 通过。
公开文件检查未命中 API key、GitHub token、私钥格式；此有限扫描不是一般 DLP 证明。
