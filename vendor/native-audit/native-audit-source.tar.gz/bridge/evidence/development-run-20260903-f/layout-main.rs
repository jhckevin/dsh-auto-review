use codex_app_server_protocol::CommandExecutionApprovalDecision;
use codex_app_server_protocol::CommandExecutionRequestApprovalResponse;
use codex_app_server_protocol::FileChangeApprovalDecision;
use codex_app_server_protocol::FileChangeRequestApprovalResponse;
use codex_protocol::approvals::ApplyPatchApprovalRequestEvent;
use codex_protocol::approvals::ExecApprovalKind;
use codex_protocol::approvals::ExecApprovalRequestEvent;
use codex_protocol::approvals::ExecPolicyAmendment;
use codex_protocol::approvals::NetworkApprovalContext;
use codex_protocol::approvals::NetworkPolicyAmendment;
use codex_protocol::config_types::ApprovalsReviewer;
use codex_protocol::models::AdditionalPermissionProfile;
use codex_protocol::parse_command::ParsedCommand;
use codex_protocol::protocol::AskForApproval;
use codex_protocol::protocol::FileChange;
use codex_protocol::protocol::ReviewDecision;
use serde::Deserialize;
use serde::Serialize;
use serde_json::Value;
use serde_json::json;
use std::collections::HashMap;
use std::fs::OpenOptions;
use std::io::BufRead;
use std::io::BufReader;
use std::io::BufWriter;
use std::io::Write;
use std::io::{self};
use std::os::fd::RawFd;
use std::path::PathBuf;

const UPSTREAM: &str = "9f97cb79eb15b38d24c552c56fe24e211ff9cf3a";
const MAX_LINE: usize = 4 * 1024 * 1024;
const MAX_ERROR: usize = 4096;
const IR_VERSION: u16 = 1;
const PATCH_SHA: &str = env!("CODEX_BRIDGE_PATCH_SHA256");

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Request {
    id: String,
    session_id: String,
    method: String,
    #[serde(default)]
    wire: Option<String>,
}

#[derive(Serialize)]
struct Error {
    kind: &'static str,
    message: String,
}

#[derive(Serialize)]
struct Response {
    id: String,
    session_id: String,
    ok: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    result: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    error: Option<Error>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ExecIrV1 {
    schema_version: u16,
    kind: ExecApprovalKind,
    call_id: String,
    plugin_id: Option<String>,
    script_path: Option<String>,
    approval_id: Option<String>,
    turn_id: String,
    environment_id: Option<String>,
    started_at_ms: String,
    command: Vec<String>,
    cwd: String,
    reason: Option<String>,
    network_approval_context: Option<NetworkApprovalContext>,
    proposed_execpolicy_amendment: Option<ExecPolicyAmendment>,
    proposed_network_policy_amendments: Option<Vec<NetworkPolicyAmendment>>,
    #[serde(serialize_with = "serialize_optional_permissions_wire")]
    additional_permissions_wire: Option<AdditionalPermissionProfile>,
    available_decisions: Option<Vec<ReviewDecision>>,
    parsed_cmd: Vec<ParsedCommand>,
    effective_approval_id: String,
}

impl From<ExecApprovalRequestEvent> for ExecIrV1 {
    fn from(value: ExecApprovalRequestEvent) -> Self {
        let effective_approval_id = value.effective_approval_id();
        Self {
            schema_version: IR_VERSION,
            kind: value.kind,
            call_id: value.call_id,
            plugin_id: value.plugin_id,
            script_path: value.script_path,
            approval_id: value.approval_id,
            turn_id: value.turn_id,
            environment_id: value.environment_id,
            started_at_ms: value.started_at_ms.to_string(),
            command: value.command,
            cwd: value.cwd.to_string(),
            reason: value.reason,
            network_approval_context: value.network_approval_context,
            proposed_execpolicy_amendment: value.proposed_execpolicy_amendment,
            proposed_network_policy_amendments: value.proposed_network_policy_amendments,
            additional_permissions_wire: value.additional_permissions,
            available_decisions: value.available_decisions,
            parsed_cmd: value.parsed_cmd,
            effective_approval_id,
        }
    }
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ApplyPatchIrV1 {
    schema_version: u16,
    call_id: String,
    turn_id: String,
    started_at_ms: String,
    changes: HashMap<PathBuf, FileChange>,
    reason: Option<String>,
    grant_root: Option<PathBuf>,
}

impl From<ApplyPatchApprovalRequestEvent> for ApplyPatchIrV1 {
    fn from(value: ApplyPatchApprovalRequestEvent) -> Self {
        Self {
            schema_version: IR_VERSION,
            call_id: value.call_id,
            turn_id: value.turn_id,
            started_at_ms: value.started_at_ms.to_string(),
            changes: value.changes,
            reason: value.reason,
            grant_root: value.grant_root,
        }
    }
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ReviewDecisionIrV1 {
    schema_version: u16,
    decision: ReviewDecision,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct AskForApprovalIrV1 {
    schema_version: u16,
    policy: AskForApproval,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ApprovalsReviewerIrV1 {
    schema_version: u16,
    reviewer: ApprovalsReviewer,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct V2CommandResponseIrV1 {
    schema_version: u16,
    decision: CommandExecutionApprovalDecision,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct V2FileResponseIrV1 {
    schema_version: u16,
    decision: FileChangeApprovalDecision,
}

fn serialize_optional_permissions_wire<S>(
    value: &Option<AdditionalPermissionProfile>,
    serializer: S,
) -> Result<S::Ok, S::Error>
where
    S: serde::Serializer,
{
    // FileSystemPermissions includes NonZeroUsize, whose full x64 range cannot
    // be represented by JS Number. Preserve its original custom serde wire;
    // consumers must not JSON.parse it into authorization data.
    match value {
        Some(profile) => serializer
            .serialize_some(&serde_json::to_string(profile).map_err(serde::ser::Error::custom)?),
        None => serializer.serialize_none(),
    }
}

fn bridge_error(kind: &'static str, message: impl Into<String>) -> Error {
    let mut message = message.into();
    if message.len() > MAX_ERROR {
        let mut boundary = MAX_ERROR;
        while !message.is_char_boundary(boundary) {
            boundary -= 1;
        }
        message.truncate(boundary);
    }
    Error { kind, message }
}

fn parse_with<T, I>(wire: Option<String>, map: impl FnOnce(T) -> I) -> Result<Value, Error>
where
    T: serde::de::DeserializeOwned + Serialize,
    I: Serialize,
{
    let wire = wire.ok_or_else(|| bridge_error("invalid_request", "wire is required"))?;
    let parsed: T =
        serde_json::from_str(&wire).map_err(|error| bridge_error("serde", error.to_string()))?;
    let canonical_wire =
        serde_json::to_string(&parsed).map_err(|error| bridge_error("serde", error.to_string()))?;
    let ir = serde_json::to_value(map(parsed))
        .map_err(|error| bridge_error("serde", error.to_string()))?;
    Ok(json!({"canonicalWire": canonical_wire, "ir": ir}))
}

fn dispatch(request: Request) -> Result<Value, Error> {
    match request.method.as_str() {
        "handshake" => {
            if request.wire.is_some() {
                return Err(bridge_error(
                    "invalid_request",
                    "handshake does not accept wire",
                ));
            }
            Ok(json!({
                "protocol": 2,
                "upstreamCommit": UPSTREAM,
                "bridgePatchSha256": PATCH_SHA,
                "irVersion": IR_VERSION,
                "os": std::env::consts::OS,
                "arch": std::env::consts::ARCH,
                "hardening": {
                    "noNewPrivileges": true,
                    "network": "seccomp-deny",
                    "filesystem": "seccomp-deny-open-plus-launcher",
                    "rlimits": true
                }
            }))
        }
        "parse_core_exec" => {
            parse_with::<ExecApprovalRequestEvent, _>(request.wire, ExecIrV1::from)
        }
        "parse_core_apply_patch" => {
            parse_with::<ApplyPatchApprovalRequestEvent, _>(request.wire, ApplyPatchIrV1::from)
        }
        "parse_core_review_decision" => {
            parse_with::<ReviewDecision, _>(request.wire, |decision| ReviewDecisionIrV1 {
                schema_version: IR_VERSION,
                decision,
            })
        }
        "parse_core_ask_for_approval" => {
            parse_with::<AskForApproval, _>(request.wire, |policy| AskForApprovalIrV1 {
                schema_version: IR_VERSION,
                policy,
            })
        }
        "parse_core_approvals_reviewer" => {
            parse_with::<ApprovalsReviewer, _>(request.wire, |reviewer| ApprovalsReviewerIrV1 {
                schema_version: IR_VERSION,
                reviewer,
            })
        }
        "parse_v2_command_response" => {
            parse_with::<CommandExecutionRequestApprovalResponse, _>(request.wire, |response| {
                V2CommandResponseIrV1 {
                    schema_version: IR_VERSION,
                    decision: response.decision,
                }
            })
        }
        "parse_v2_file_response" => {
            parse_with::<FileChangeRequestApprovalResponse, _>(request.wire, |response| {
                V2FileResponseIrV1 {
                    schema_version: IR_VERSION,
                    decision: response.decision,
                }
            })
        }
        _ => Err(bridge_error("invalid_method", "unknown method")),
    }
}

struct BoundedFrame {
    bytes: Vec<u8>,
    exceeded: bool,
}

impl Write for BoundedFrame {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        if self.bytes.len().saturating_add(bytes.len()) > MAX_LINE {
            self.exceeded = true;
            return Err(io::Error::other("response frame exceeds 4 MiB"));
        }
        self.bytes.extend_from_slice(bytes);
        Ok(bytes.len())
    }

    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

fn write_response(writer: &mut impl Write, response: &Response) -> io::Result<()> {
    // Bound the final encoded frame before writing any of it to stdout.
    // canonicalWire/IR construction remains bounded by input + RLIMIT_AS,
    // not by this final-output encoder. MAX_LINE excludes the delimiter.
    let mut frame = BoundedFrame {
        bytes: Vec::new(),
        exceeded: false,
    };
    if let Err(error) = serde_json::to_writer(&mut frame, response) {
        if !frame.exceeded {
            return Err(io::Error::other(error));
        }
        frame.bytes.clear();
        frame.exceeded = false;
        let limited = Response {
            id: response.id.clone(),
            session_id: response.session_id.clone(),
            ok: false,
            result: None,
            error: Some(bridge_error(
                "resource_limit",
                "encoded response exceeds 4 MiB",
            )),
        };
        serde_json::to_writer(&mut frame, &limited).map_err(io::Error::other)?;
    }
    writer.write_all(&frame.bytes)?;
    writer.write_all(b"\n")?;
    writer.flush()
}

enum Frame {
    Eof,
    Line(Vec<u8>),
}

fn read_frame(reader: &mut impl BufRead) -> io::Result<Frame> {
    let mut line = Vec::with_capacity(4096);
    loop {
        let available = reader.fill_buf()?;
        if available.is_empty() {
            if line.is_empty() {
                return Ok(Frame::Eof);
            }
            return Err(io::Error::new(
                io::ErrorKind::UnexpectedEof,
                "unterminated bridge frame",
            ));
        }
        let newline = available.iter().position(|byte| *byte == b'\n');
        let take = newline.map_or(available.len(), |index| index);
        if line.len().saturating_add(take) > MAX_LINE {
            return Err(io::Error::new(
                io::ErrorKind::InvalidData,
                "bridge frame exceeds 4 MiB",
            ));
        }
        line.extend_from_slice(&available[..take]);
        reader.consume(take + usize::from(newline.is_some()));
        if newline.is_some() {
            return Ok(Frame::Line(line));
        }
    }
}

fn set_limit(resource: libc::__rlimit_resource_t, soft: u64, hard: u64) -> io::Result<()> {
    let limit = libc::rlimit {
        rlim_cur: soft,
        rlim_max: hard,
    };
    // SAFETY: setrlimit only reads the initialized rlimit structure.
    if unsafe { libc::setrlimit(resource, &limit) } == 0 {
        Ok(())
    } else {
        Err(io::Error::last_os_error())
    }
}

fn filter_stmt(code: u16, value: u32) -> libc::sock_filter {
    libc::sock_filter {
        code,
        jt: 0,
        jf: 0,
        k: value,
    }
}

fn filter_jump(code: u16, value: u32, jt: u8, jf: u8) -> libc::sock_filter {
    libc::sock_filter {
        code,
        jt,
        jf,
        k: value,
    }
}

fn install_bridge_seccomp() -> io::Result<()> {
    const AUDIT_ARCH_X86_64: u32 = 0xc000_003e;
    const RET_KILL: u32 = 0x8000_0000;
    const RET_ALLOW: u32 = 0x7fff_0000;
    const RET_ERRNO: u32 = 0x0005_0000;
    const LD_W_ABS: u16 = 0x20;
    const JMP_JEQ_K: u16 = 0x15;
    const RET_K: u16 = 0x06;
    // The bridge only parses JSON through inherited pipes. Deny unknown and
    // x32-numbered syscalls by default instead of maintaining a bypass-prone
    // blacklist. This does not replace the parent Harness sandbox.
    let allowed = [
        libc::SYS_read,
        libc::SYS_write,
        libc::SYS_readv,
        libc::SYS_writev,
        libc::SYS_close,
        libc::SYS_fstat,
        libc::SYS_lseek,
        libc::SYS_mmap,
        libc::SYS_mprotect,
        libc::SYS_munmap,
        libc::SYS_mremap,
        libc::SYS_madvise,
        libc::SYS_brk,
        libc::SYS_rt_sigaction,
        libc::SYS_rt_sigprocmask,
        libc::SYS_rt_sigreturn,
        libc::SYS_sigaltstack,
        libc::SYS_futex,
        libc::SYS_sched_yield,
        libc::SYS_clock_gettime,
        libc::SYS_getrandom,
        libc::SYS_getpid,
        libc::SYS_gettid,
        libc::SYS_exit,
        libc::SYS_exit_group,
        libc::SYS_restart_syscall,
    ];
    let mut filters = vec![
        filter_stmt(LD_W_ABS, 4),
        filter_jump(JMP_JEQ_K, AUDIT_ARCH_X86_64, 1, 0),
        filter_stmt(RET_K, RET_KILL),
        filter_stmt(LD_W_ABS, 0),
    ];
    for syscall in allowed {
        filters.push(filter_jump(JMP_JEQ_K, syscall as u32, 0, 1));
        filters.push(filter_stmt(RET_K, RET_ALLOW));
    }
    filters.push(filter_stmt(RET_K, RET_ERRNO | libc::EPERM as u32));
    let program = libc::sock_fprog {
        len: filters.len() as u16,
        filter: filters.as_mut_ptr(),
    };
    // SAFETY: prctl receives valid scalar arguments and a pointer to filters alive for the call.
    let result = unsafe {
        libc::prctl(
            libc::PR_SET_SECCOMP,
            libc::SECCOMP_MODE_FILTER,
            &program as *const libc::sock_fprog,
        )
    };
    if result == 0 {
        Ok(())
    } else {
        Err(io::Error::last_os_error())
    }
}

fn probe_network_denied() -> io::Result<()> {
    // SAFETY: socket has no pointer arguments.
    let fd: RawFd = unsafe { libc::socket(libc::AF_INET, libc::SOCK_STREAM, 0) };
    if fd >= 0 {
        // SAFETY: fd was returned by socket.
        unsafe { libc::close(fd) };
        return Err(io::Error::other("network socket unexpectedly available"));
    }
    if io::Error::last_os_error().raw_os_error() == Some(libc::EPERM) {
        Ok(())
    } else {
        Err(io::Error::last_os_error())
    }
}

fn probe_filesystem_read_only() -> io::Result<()> {
    let path = format!("/tmp/codex-approval-bridge-probe-{}", std::process::id());
    match OpenOptions::new().write(true).create_new(true).open(&path) {
        Ok(_) => {
            let _ = std::fs::remove_file(&path);
            Err(io::Error::other("filesystem sandbox is not read-only"))
        }
        Err(error)
            if matches!(
                error.raw_os_error(),
                Some(libc::EPERM | libc::EACCES | libc::EROFS)
            ) =>
        {
            Ok(())
        }
        Err(error) => Err(error),
    }
}

fn probe_indirect_syscalls_denied() -> io::Result<()> {
    // Invalid/empty arguments avoid side effects even if a filter regresses.
    // EPERM (not ENOSYS/EINVAL/EFAULT) verifies the installed deny-by-default
    // filter, including kernels where the x32 ABI is not enabled.
    for syscall in [
        (libc::SYS_getpid as u64 | 0x4000_0000) as libc::c_long,
        libc::SYS_io_uring_setup,
        libc::SYS_clone3,
        libc::SYS_process_vm_readv,
    ] {
        // SAFETY: no valid userspace pointer is supplied; none of these calls
        // can create a valid object with all arguments set to zero.
        let result =
            unsafe { libc::syscall(syscall, 0usize, 0usize, 0usize, 0usize, 0usize, 0usize) };
        if result != -1 || io::Error::last_os_error().raw_os_error() != Some(libc::EPERM) {
            return Err(io::Error::other("indirect syscall unexpectedly available"));
        }
    }
    Ok(())
}

fn harden_process() -> io::Result<()> {
    if std::env::consts::OS != "linux" || std::env::consts::ARCH != "x86_64" {
        return Err(io::Error::other("bridge supports linux x86_64 only"));
    }
    set_limit(libc::RLIMIT_AS, 256 * 1024 * 1024, 256 * 1024 * 1024)?;
    set_limit(libc::RLIMIT_FSIZE, 0, 0)?;
    set_limit(libc::RLIMIT_NOFILE, 32, 32)?;
    set_limit(libc::RLIMIT_NPROC, 1, 1)?;
    // SAFETY: PR_SET_NO_NEW_PRIVS uses scalar arguments only.
    if unsafe { libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) } != 0 {
        return Err(io::Error::last_os_error());
    }
    install_bridge_seccomp()?;
    probe_network_denied()?;
    probe_filesystem_read_only()?;
    probe_indirect_syscalls_denied()
}

fn main() -> io::Result<()> {
    harden_process()?;
    let mut reader = BufReader::new(io::stdin().lock());
    let mut writer = BufWriter::new(io::stdout().lock());
    loop {
        let Frame::Line(line) = read_frame(&mut reader)? else {
            return Ok(());
        };
        let request = match serde_json::from_slice::<Request>(&line) {
            Ok(request)
                if !request.id.is_empty()
                    && request.id.len() <= 128
                    && !request.session_id.is_empty()
                    && request.session_id.len() <= 256 =>
            {
                request
            }
            Ok(_) => {
                write_response(
                    &mut writer,
                    &Response {
                        id: String::new(),
                        session_id: String::new(),
                        ok: false,
                        result: None,
                        error: Some(bridge_error(
                            "invalid_request",
                            "bounded id and session_id are required",
                        )),
                    },
                )?;
                continue;
            }
            Err(error) => {
                write_response(
                    &mut writer,
                    &Response {
                        id: String::new(),
                        session_id: String::new(),
                        ok: false,
                        result: None,
                        error: Some(bridge_error("invalid_envelope", error.to_string())),
                    },
                )?;
                continue;
            }
        };
        let id = request.id.clone();
        let session_id = request.session_id.clone();
        let response = match dispatch(request) {
            Ok(result) => Response {
                id,
                session_id,
                ok: true,
                result: Some(result),
                error: None,
            },
            Err(error) => Response {
                id,
                session_id,
                ok: false,
                result: None,
                error: Some(error),
            },
        };
        write_response(&mut writer, &response)?;
    }
}

#[cfg(test)]
#[path = "main_tests.rs"]
mod tests;
