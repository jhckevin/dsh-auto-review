#!/usr/bin/env python3
"""Isolated offline candidate build; never changes frozen artifacts or services."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
IMAGE = 'sha256:d3a75b5ef6faa77d8074c1cb1d41b08e5f9cf6775d6651e87ffe98e41139abc7'
UPSTREAM = '9f97cb79eb15b38d24c552c56fe24e211ff9cf3a'
PATCH = '5cb90364c0a728dc97c278815905c5f6469a9139563fb08d17808908c1bef5c7'
NAME = 'native-candidate-rust195-20260903-xbfg9x'
EVIDENCE = ROOT/'evidence'

def capture(args):
    return subprocess.check_output(args, timeout=60)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def source_proof():
    base = ['git', '-C', str(ROOT/'src')]
    return {'upstreamCommit': capture(base+['rev-parse', 'HEAD']).decode().strip(),
            'patchSha256': digest(capture(base+['diff', '--binary', 'HEAD'])),
            'cargoLockSha256': digest((ROOT/'src/codex-rs/Cargo.lock').read_bytes())}

def save(name, data):
    with (EVIDENCE/name).open('x') as f:
        f.write(json.dumps(data, indent=2)+'\n')

before = source_proof()
if before['upstreamCommit'] != UPSTREAM or before['patchSha256'] != PATCH:
    raise RuntimeError('candidate source does not match fixed patch')
if digest((EVIDENCE/'development.patch').read_bytes()) != PATCH:
    raise RuntimeError('input patch changed')
if shutil.disk_usage(ROOT).free < 12*1024**3:
    raise RuntimeError('insufficient initial disk headroom')
save('source-before.json', before)
save('builder-image.json', json.loads(capture(['podman','image','inspect',IMAGE])))
base = ['podman','run','--pull=never','--network=none','--cpus=1','--memory=4g',
        '--pids-limit=256','-v',str(ROOT/'src')+':/src:ro',
        '-v',str(ROOT/'target')+':/target:rw',
        '-v','/srv/pi-lab-dev/tmp/cargo:/cargo:rw',
        '-v','/srv/pi-lab-dev/tmp/rustup:/rustup:ro',
        '-e','CARGO_HOME=/cargo','-e','RUSTUP_HOME=/rustup',
        '-e','RUSTUP_TOOLCHAIN=1.95.0-x86_64-unknown-linux-gnu',
        '-e','CARGO_BUILD_JOBS=1','-e','CARGO_TARGET_DIR=/target',
        '-e','CODEX_BRIDGE_PATCH_SHA256='+PATCH,
        '-e','PATH=/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
        '-w','/src/codex-rs']
metadata = base+['--rm',IMAGE,'sh','-ec',
    'rustc -vV; cargo -vV; ldd --version; dpkg-query -W gcc g++ binutils libc6 libssl-dev pkg-config']
with (EVIDENCE/'toolchain.log').open('xb') as log:
    subprocess.run(metadata,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
command = base+['--name',NAME,IMAGE,'cargo','build','--locked','--offline','--release',
                '-p','codex-approval-protocol-bridge-prototype']
save('build-command.json',command)
start=time.time()
with (EVIDENCE/'build.log').open('xb') as log, (EVIDENCE/'resources.jsonl').open('x') as resources:
    proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
    while proc.poll() is None:
        free=shutil.disk_usage(ROOT).free
        resources.write(json.dumps({'time':time.time(),'freeBytes':free,'below8GiB':free<8*1024**3})+'\n')
        resources.flush()
        time.sleep(10)
    rc=proc.returncode
(EVIDENCE/'build.rc').write_text(str(rc)+'\n')
state=json.loads(capture(['podman','inspect','--format','{{json .State}}',NAME]))
save('container-state.json',state)
save('source-after.json',source_proof())
save('build-result.json',{'exitCode':rc,'elapsedSeconds':time.time()-start,
    'OOMKilled':state.get('OOMKilled'),'sourceUnchanged':source_proof()==before,
    'buildLogSha256':digest((EVIDENCE/'build.log').read_bytes())})
if rc or state.get('OOMKilled') or source_proof()!=before:
    raise RuntimeError('candidate build failed or source changed')
strip=['podman','run','--pull=never','--rm','--network=none','--memory=256m',
       '-v',str(ROOT/'target')+':/target:rw',IMAGE,'strip','--strip-all',
       '-o','/target/bridge-candidate','/target/release/codex-approval-protocol-bridge']
with (EVIDENCE/'strip.log').open('xb') as log:
    subprocess.run(strip,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
binary=ROOT/'bridge-candidate-rust195-gnu231'
shutil.copyfile(ROOT/'target/bridge-candidate',binary)
binary.chmod(0o755)
with (EVIDENCE/'binary-platform.log').open('xb') as log:
    subprocess.run(['readelf','--version-info',str(binary)],stdout=log,stderr=subprocess.STDOUT,check=True)
save('candidate.json',{'scope':'candidate only; no package replacement or publication',
    'binary':binary.name,'sha256':digest(binary.read_bytes()),'bytes':binary.stat().st_size,
    'patchSha256':PATCH,'rust':'1.95.0','image':IMAGE,'source':before})
print((EVIDENCE/'candidate.json').read_text())
