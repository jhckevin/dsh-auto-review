# v0.0.0-prototype.3 阶段证据（不是发布验收）

冻结源码提交：df54fac836e94db9858ded0692082a5b20d477da。
此记录只追加可核验结果，不改原型代码，不将历史 FAIL 改写为 PASS。

## 已实测

- 固定 Rust 补丁 SHA256：35c5196aee02d0a4dd229a0faf7fe782d64c435042ecc675940be8b1b785eebd。
- GNU2.31 二进制 SHA256：be0889b1bc892a16c8dd026f552a8152e4d633723d2495e94ebb4fd4b4351ffc。
- 原型 Rust 单测 2/2、进程回归 6/6；另有两个限定 Rust 范围的独立审查。
- 新补丁在新源码/新 target 上干净重建并 cmp 字节一致；见 ROOT-VERIFICATION-20260902.md。
- 当前 owner 14/14，包含启动前计数/字节 admission（32并发，只接纳2/1，拒绝30/31，随后正常恢复）、关闭竞态、取消、背压、逐帧限制与恶意响应。
- 私有 prototype.3 双 tarball 在 Debian11、uid65532、只读根文件系统和 network=none 下通过9种安装/拒绝案例：
  正常无损i64调用，同UID只读拒绝，缺平台拒绝，manifest额外字段/错误版本/越界路径/超长/符号链接/包版本不符拒绝。
- 测试镜像：5aeee04da1b3d986ca08021bdc35d437d7c64acb97a4bae2b90e350f8dc23e6d。
- 宿主 tarball SHA256：dfaf5ebd79ce1350d487ef3fbcfd2252d6fa27489d5177355a4f40894540b3ef。
- 平台 tarball SHA256：9d389497eb125e9c26d9b31c474cd6b22647791a17c9f0fd79e12005743ab93a。

## 必须保留的未完成项

组合CI真实退出1，同时报告 LICENSE-GATE-FAIL 和 UPSTREAM-DEVELOPMENT-GATE-FAIL。
672个目标构建输入组件中，原先缺60份文本，经固定commit/git-blob材料补回47个，
再从匹配Cargo.lock的原始crate补回bech32完整MIT，仍有12个缺口。
这些只是源可证许可证材料，不是法律适用性的认证；不允许发布。

上游sibling测试布局、just fmt/fix/test(nextest)、bazel-lock-update仍未通过；
干净重建和cargo test不能替代它们。主插件B1/B2/B3也未完成。
owner/包的新一轮独立复审在此记录时尚未完成。

## 失败轨迹和资源

保留先前“旧平台tarball未更新被hash/size门禁拒绝”和“旧shell mock未稳定到达跨session检查”的原始日志。
后者已用正确协议握手后的真实wrong-session响应替换，不接受timeout冒充该断言。
许可证文件保持原始字节；源码空白检查不自动格式化上游原文或固定补丁。

本次只清理已结束的旧v2编译缓存4.9GiB；
主代理另清理完成比对后的新复现一次性target3.4GiB。
源码、补丁、二进制、日志保留；缓存可以重新编译，但被删除的缓存文件本身不可恢复。
未修改主插件工作区；其原先单个approval-protocol.ts草稿仍冻结。
