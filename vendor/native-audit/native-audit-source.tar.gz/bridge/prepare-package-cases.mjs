import {cpSync, readFileSync, writeFileSync, symlinkSync, unlinkSync} from "node:fs";
for (const kind of ["manifest-extra", "manifest-version", "manifest-path", "manifest-size", "manifest-symlink", "package-version"]) {
  const root = "/public-case-" + kind;
  cpSync("/install", root, {recursive: true});
  const pkg = root + "/node_modules/@jhckevin/dsh-auto-review-bridge-linux-x64-gnu/";
  const file = pkg + (kind === "package-version" ? "package.json" : "artifact-manifest.json");
  const value = JSON.parse(readFileSync(file, "utf8"));
  if (kind === "manifest-extra") value.extra = true;
  if (kind === "manifest-version") value.schemaVersion = 99;
  if (kind === "manifest-path") value.bridge.path = "../../../bin/sh";
  if (kind === "package-version") value.version = "9.9.9";
  if (kind === "manifest-size") writeFileSync(file, " ".repeat(65537));
  else if (kind === "manifest-symlink") {
    const original = file + ".original"; writeFileSync(original, JSON.stringify(value)); unlinkSync(file); symlinkSync(original, file);
  } else writeFileSync(file, JSON.stringify(value));
}
