# ISSUE-022B 继续执行与验收边界

状态：开发中；不是发布验收报告。2026-09-02。

## 已现场核对的基线

- 主工作区：`/srv/pi-lab-dev/worktrees/dsh-auto-review-native`。
- HEAD：`da79c3cd4285f20e857b6839e0515a60cfd62ae0`；B1 旧实现尚未通过独立审查。
- `src/codex-parity/approval-protocol.ts` 存在未提交草稿，冻结保留，不能用 reset/checkout 丢弃。
- 固定上游：`9f97cb79eb15b38d24c552c56fe24e211ff9cf3a`。
- source/inventory gate 已重新执行通过：15 个模块、270 个上游文件。
- manifest 仅 approval-action-and-cache、guardian-action-format 为 complete；不能据此声明全模块完成。
- 第二次隔离 Rust 构建 rc=0；字节一致性须单独核对，不以 rc 代替。

## 本阶段顺序

1. 完成平台原型的双构建哈希、root-owned 安装与非 root 运行、同 UID 拒绝、离线双 tarball、许可证和构建清单。
2. 独立审查实际代码与产物：进程/字节边界、取消、身份关联、原生 sandbox、可信产物、协议覆盖。发现问题先修复，重新审查；不预写 PASS。
3. 重新检查主工作区 diff 与固定上游，再决定是否合入桥接层。即使原型通过，也不代表 B1 全部覆盖。
4. 补齐 B1 协议与真值测试：默认/别名/未知字段/null、完整 i64、Exec 全字段和推导方法、v2 双向映射、拒绝文本；不能让 V8 Number 先吞掉 wire 精度。
5. 补齐真实 ApprovalStore/PermissionRequest 依赖真值。静态 JSON 长度/固定内容断言不计行为移植验收。
6. 独立中文提交后，两个 subagent 针对同一 commit 审查；两者均通过才能更新模块证据。
7. 重新检查代码库后进入 B2 中央审批阶段，再 B3 原生 DSH 接入。Guardian 模型协议、上下文、证据与 UI 是后续模块，不能提前标完成。

## 不得降低的门禁

- 平台包和 launcher 必须来自运行账户不可改写的信任根；同 UID chmod 0555 不是不可变保证。
- 仅支持经验证的 Linux x64/glibc 基线；不支持的平台和缺失/损坏产物明确失败，不静默回退旧 TypeScript。
- tarball 必须包含必要许可证/NOTICE、补丁及精确上游来源；产品命名不替代法定署名。
- 源码、测试真值、运行时以及打包安装分别验收，单元测试不能替代真实安装与隔离验证。
- 不改线上服务，不重启历史实验，不读无关聊天/凭据。
- 只在服务器开发；大 target 清理前确认绝对路径、用途与无活动进程，保留构建日志/哈希/失败证据。
