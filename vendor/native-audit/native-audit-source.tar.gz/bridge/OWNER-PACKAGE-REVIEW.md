# Independent owner, package-entry and CI review

Date: 2026-09-02. Reviewer: bridge_security_review.
Verdict: FAIL. Findings in this review: P0=0, P1=1, P2=1.

## Frozen target

- Source commit: `df54fac836e94db9858ded0692082a5b20d477da`, private prototype.3.
- At read time HEAD was `78c05aa3129506d28886b247111995c0b6a3470b`; independent diff inspection confirmed only evidence documents/logs were added after the target commit.
- `bridge-owner-v2.mjs`: `a4e1ea00391d2d992454de837e1454f28312b4ed764b17d831c23b7dfcadd094`.
- `packages/host/index.mjs`: `900497fd39ae8d0b1aa56b2a33a64a70614e81c22c629567772527c971df733d`.
- `bridge-owner-v2.test.mjs`: `541e34fa30b6f2c08dcacca0fe68206d583c143813fcb9d12cecfb881d26c605`.
- Independently rerun test image: `sha256:5aeee04da1b3d986ca08021bdc35d437d7c64acb97a4bae2b90e350f8dc23e6d`.
- Base directory: `/srv/pi-lab-dev/tmp/issue022b-native-bridge-prototype`.

Only this report was written, through remote safe apply_patch. Source, licenses and original evidence files were not changed by this reviewer. Rust was not recompiled or re-reviewed in this scope. Later remediation is not a basis for this verdict.

## Independent runtime results

Ran the existing exact image using `podman run --pull=never --rm --network=none --read-only --tmpfs /tmp:rw,noexec,nosuid,nodev,size=16m IMAGE`.

Observed 14/14 owner tests passed, 0 failures/skips/cancellations, duration 1260.876158ms. All 9 package cases passed under uid65532: installed, same-uid rejection, host-only rejection, manifest-extra, manifest-version, manifest-path, manifest-size, manifest-symlink and package-version rejection. These establish the tested runtime cases, not combined CI acceptance.

## P1: CI license/development completion trusts self-reported status rather than validating coverage and evidence

Location: `verify-artifacts.mjs:22-35`; called by `ci-check.sh` before its final success marker.

The current true artifacts are correctly rejected: `combined-ci.log` reports 12 components missing source-backed license material and pending upstream development gates. That truthful current failure is not disputed.

However the completion predicates are insufficient:

- Development checks only `upstream.status === "passed"` and `upstream.evidence.length !== 0`. It does not verify upstreamCommit, fixed required-gate coverage, each gate's result, command, source/patch binding, exit status, actual log existence or log hash. A nonempty string array is treated as sufficient evidence by the code.
- License checks trust `audit.missing.length`. SBOM-to-audit coverage is only an overall component count. The verifier loops over licenseMaterials properties that happen to exist, but does not require each component to have one or more valid materials. It does not independently derive missing coverage or compare component identities against the source dependency graph.
- Hashing listed material files is useful but does not establish that every actual component has material. The derived missing list must not be the authority for its own completeness.

This is a static code finding. An attempted in-memory stub test of these predicates was rejected by Auto Review as spoofing approval evidence; it did not execute, no data was changed, and no bypass/retry was attempted. No synthetic success is claimed. The original failure logs remain intact.

Required correction before a combined gate can be called fail-closed:

1. Validate exact, versioned evidence schemas with bounded arrays/strings and fixed upstreamCommit plus source/patch SHA binding.
2. Hard-code or independently derive the expected development gate IDs (test layout, formatting, lint/fix, nextest, lock update), requiring exactly one actual result for every required gate and no duplicates or omitted gates.
3. Each result must include a recognized command, exit status, source identity, and an existing package-contained log path/hash. Verify those files and hashes, and applicable completion markers/results. Do not accept an arbitrary nonempty evidence list or summary passed field.
4. Derive actual dependency/component IDs from the fixed source graph; reconcile exact ID sets, not just counts, with SBOM and license audit.
5. Require each component's nonempty source-backed material list (or a narrowly explicit validated exception), validate contained regular-file paths and hashes, and recompute missing coverage. The summary missing field may be checked for consistency but cannot replace that computation.
6. Keep the combined CI success marker unreachable until all gates pass. Do not remove or weaken the current pending/12-missing checks merely to make runtime results green.

This is not an assertion that the current development gates or missing licenses were completed. They remain blocked.

## P2: A queued request larger than maxInflightBytes can block the queue forever

Locations: `bridge-owner-v2.mjs:341-356,477-484,538-545`; option normalization at `584-605`.

When a slot is busy, requests are checked against the queue byte budget and enqueued before the per-request maxInflightBytes check. If the head item is larger than that cap, drain always returns without sending it. Timeouts are created only in send, so the item has no timeout and blocks all items behind it indefinitely. Startup admission's combined budget does not prevent this because maxQueueBytes can be larger than maxInflightBytes.

Independent reproduction in the exact read-only/nonroot image:

```js
// Real root-owned test bridge/launcher; normal expected protocol 2.
const host = acquireHostBridge({ ...realArtifactOptions,
  maxInflight: 1, maxQueue: 4,
  maxInflightBytes: 1024, maxQueueBytes: 8192, timeoutMs: 100 });
const session = host.createSession();
await host.request(session, 'handshake');
process.kill(host.pid, 'SIGSTOP');
const first = host.request(session, 'handshake');
let outcome = 'pending';
const queued = host.request(session, 'parse_core_review_decision',
  JSON.stringify({ denied: { rejection: 'x'.repeat(2000) } }))
  .then(() => outcome = 'resolved', error => outcome = error.kind);
await new Promise(resolve => setTimeout(resolve, 10));
process.kill(host.pid, 'SIGCONT');
await first;
await new Promise(resolve => setTimeout(resolve, 350));
console.log(outcome, host.state); // observed: pending, running
await host.close();
await queued;
```

Observed output: `{"outcome":"pending","state":"running","timeoutMs":100,"waitedMs":350}`. Cleanup explicitly closed the host; no container was left running.

Default 8MiB inflight budget with a 4MiB frame cap does not trigger this case. It affects supported custom budget options, hence P2 rather than claiming all production requests hang.

Required: reject an individually unsendable item before either queue path, or define explicit bounded queue rejection/deadline behavior. Validate option ranges/combinations. Add a regression that proves the oversized head rejects and a following small request completes.

## Improvements verified against the prior FAIL

- raw wire must be a primitive string and is bounded before serialization/startup; encoded length is estimated without constructing the full encoded envelope;
- startup waiters reserve count and byte budgets before the first await;
- session membership is rechecked after startup and close/backoff/handshake paths now check closed state;
- response parsing is per newline-delimited frame, not aggregate chunk size;
- method-specific IR and full handshake shape validation exists, including exact i64 decimal checks and opaque additionalPermissionsWire;
- package metadata and manifest are bounded/trusted-read before use, compared exactly with host-pinned provenance, and artifact paths are package-contained;
- root ownership, non-root execution, complete ancestry checks, same-fd hashing/execution and rejection of same-UID installation remain in place;
- combined CI currently fails honestly instead of converting 14+9 runtime successes into release acceptance.

## Scope and disposition

FAIL remains until the two findings above receive frozen-source fixes and independent re-review. This report does not audit other reviewers' additional findings or claim their absence. In particular, any separately reported prototype-key validator bug must retain its own evidence and remediation gate.

No claim is made that complete B1, full Codex parity, native Harness integration, production rollout or all upstream development gates are finished. Existing Rust-only review and clean rebuild evidence remain separate from this owner/package/CI verdict.
