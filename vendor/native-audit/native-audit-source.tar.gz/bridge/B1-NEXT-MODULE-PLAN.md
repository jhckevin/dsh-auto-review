# B1 下一最小原生覆盖模块计划（未实现）

状态：**仅只读源码核对与实施计划；没有实现，没有运行 Rust build。完整 B1 仍 FAIL。**

建议只选择一个独立子模块：**ExecApprovalRequestEvent 有效可选决定的原生派生**。暂不捆绑 Core 三种 Default、Core/V2 映射或 app-server 生命周期。理由：两个上游公开方法集中于一个固定源文件，无 SessionServices/网络/异步状态依赖，可以用真实 Rust 类型和方法建立小而完整的差分闭环。

## 固定源码核对

上游 commit：`9f97cb79eb15b38d24c552c56fe24e211ff9cf3a`；下列通过 git show 固定对象重读，不依赖 dirty checkout。

| 候选块 | 精确路径/符号 | 本轮范围 |
| --- | --- | --- |
| Exec 有效列表 | `codex-rs/protocol/src/approvals.rs:322` `ExecApprovalRequestEvent::effective_available_decisions`；`:336` `default_available_decisions` | 选中 |
| Core Ask 默认 | `codex-rs/protocol/src/protocol.rs:965` `AskForApproval` 的 derive Default / OnRequest 标记 | 延后；默认 on-request，不是 null 解析成功 |
| Core Reviewer 默认 | `codex-rs/protocol/src/config_types.rs:183` `ApprovalsReviewer` User 默认 | 延后 |
| Core Decision 默认 | `codex-rs/protocol/src/protocol.rs:4045` `impl Default for ReviewDecision` | 延后；Denied rejection=denied |
| Core 到 V2 | `codex-rs/app-server-protocol/src/protocol/v2/item.rs:84` `impl From<CoreReviewDecision> for CommandExecutionApprovalDecision` | 延后 |
| V2 File 到 Core | `codex-rs/app-server/src/bespoke_event_handling.rs:1981` `map_file_change_approval_decision`；`:1991` `on_file_change_request_approval_response` | 延后 |
| V2 Command 到 Core | 同文件`:2033` `on_command_execution_request_approval_response` | 延后；映射和 completion status 不可混为一个 serde parser |
| turn-transition | `codex-rs/app-server/src/server_request_error.rs:5` `is_turn_transition_server_request_error` | 延后；只检查 data.reason 是否字符串 turnTransition，不靠 message/code 猜测 |

选中源 blob：`c051430ec4a3fde5ca30b4832bf720995a9c5467`（`codex-rs/protocol/src/approvals.rs`）。

映射候选的已核对事实（不在本次实现）：MCP amendment/Denied/TimedOut 到 V2 Decline；Abort 到 Cancel；network amendment 保留 Allow/Deny。V2 Decline 到 Denied("rejected by user")；Cancel 到 Abort。坏响应/client/receiver错误到 Denied("approval request failed")，command completion 为 Failed；turnTransition 直接 return，不提交伪 Denied。必须另开模块验证这些生命周期。

## 选中模块的准确行为

- available_decisions 为 Some 时克隆原列表，包括空数组、顺序、重复项，不重新筛选。
- None 才调用 default_available_decisions；serde 的缺失/null 都是 None。
- network context 存在：Approved、ApprovedForSession、可选首个 action=Allow 的 network amendment、Abort；忽略后续 Allow，不加入 Deny。
- 无 network 而 additional permissions 存在：Approved、Abort，即使附 execpolicy amendment 也不加入。
- 普通：Approved、可选 execpolicy amendment、Abort。
- 此模块只是提示可选列表派生，不是授权判定；不能添加 offered-decisions membership 强制执行。

## 最小真实 Rust Oracle 案例

每例从 raw JSON string 用 `serde_json::from_str::<ExecApprovalRequestEvent>` 构造；调用真实 `effective_available_decisions()`。不要手写替代判断。公共 base：call_id=c，command=[]，cwd=/work，parsed_cmd=[]，started_at_ms=0。

表中 A=Approved、S=ApprovedForSession、X=Abort；E(v)=ApprovedExecpolicyAmendment(v)，N(host)=NetworkPolicyAmendment(host,Allow)。实际 golden 存真实 serde JSON，不存这些简写。

| ID | base 的新增字段 | 真实期望 |
| --- | --- | --- |
| E01 | 无 | [A,X] |
| E02 | available_decisions:null | [A,X] |
| E03 | available_decisions:[]；同时附 network/permissions/amendment | [] |
| E04 | available_decisions:[abort,approved,approved] | 顺序和重复原样 |
| E05 | proposed_execpolicy_amendment:[git,status] | [A,E([git,status]),X] |
| E06 | proposed_execpolicy_amendment:[] | [A,E([]),X]，Some(empty)不等于None |
| E07 | network_approval_context:{host:a.test,protocol:https}，无 amendments | [A,S,X] |
| E08 | 同 E07；amendments=[Deny(a.test)] | [A,S,X] |
| E09 | 同 E07；amendments=[Deny(a.test),Allow(b.test),Allow(c.test)] | [A,S,N(b.test),X]，上游不自行匹配 context host |
| E10 | 同 E09；另外附 permissions 和 exec amendment | 与 E09 相同，网络优先 |
| E11 | 无 network；additional_permissions:{network:null,file_system:null}；exec amendment=[git] | [A,X]，permissions优先 |
| E12 | additional_permissions:null；exec amendment=[git] | [A,E([git]),X] |
| E13 | 无 network context，但有网络 Allow amendment | [A,X]，孤立 amendment 不触发网络分支 |

另用真实静态 `default_available_decisions` 对 E01/E05/E06/E07/E08/E09/E10/E11/E12/E13 的字段直接调用，确认两入口一致。E03/E04 必须只由 effective 方法断言，不能误用 default 方法。

原始 wire 再加三个拒绝控制：available_decisions 为对象、包含未知 enum、null enum 项；应在真实 serde 解析阶段拒绝，不执行派生。i64 -0 已知拒绝可保持现有测试，不扩大本模块数字范围。

## 拟实施步骤与验收

1. Owner prototype.4 修复冻结通过后才开始；不跨改正在审查的 owner。
2. 在新的独立提交/模块中让 Rust Exec IR 输出 `effectiveAvailableDecisions`：移动 event 字段前先调用真实方法。字段是 Vec<ReviewDecision>，不由 TypeScript 再推导。
3. 同步内部 IR schema/version 与 host-pinned patch provenance；owner严格校验该新字段为 coreDecision数组。不得允许旧包冒充新IR。
4. 建单独上游 Rust oracle test，使用上述13+3例；记录commit/blob/patch SHA和所有结果。真实静态方法与实例方法均被调用。
5. 每个golden由bridge raw-wire调用消费，对新IR字段逐项断言；不只断言数组长度。全量输入unknown/null行为仍属于原Rust serde，不在owner重新解释。
6. 增 negative mock：新字段缺失、类型错误、非法variant须protocol拒绝；不得导致宿主崩溃。
7. 小范围回归原七接口与包provenance/无精度损失；重新打包后独立subagent逐项审查。相关许可证/upstream-development gate继续保持真实失败，不能为本模块放宽。
8. 只允许标记本子模块派生行为已实现/已差分测试。Core defaults、opaque、V2映射、PermissionRequest、ApprovalStore和完整B1仍不得标complete。

本文件仅提出实施清单；没有新增Bridge方法、IR字段、oracle或测试代码。
