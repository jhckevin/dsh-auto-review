import assert from "node:assert/strict";
import { accessSync, constants, lstatSync, existsSync, readFileSync } from "node:fs";
const mode = process.argv[2];
assert.notEqual(process.geteuid(), 0);
delete process.env.DSH_AUTO_REVIEW_NATIVE_RUNTIME;
const runtimeMode = ["protected-runtime", "writable-runtime", "relative-runtime"].includes(mode);
if (runtimeMode) process.env.DSH_AUTO_REVIEW_NATIVE_RUNTIME = mode === "relative-runtime" ? "relative/platform"
  : (mode === "writable-runtime" ? "/public-sameuid" : "/install") + "/node_modules/@jhckevin/dsh-auto-review-bridge-linux-x64-gnu";
const base = mode === "same-uid" ? "/public-sameuid" : mode === "host-only" || runtimeMode ? "/cold-host-only" : mode === "cold-installed" ? "/cold-install" : mode === "installed" ? "/install" : "/public-case-" + mode;
if (mode === 'host-only' || runtimeMode) {
  assert.equal(existsSync(base+'/node_modules/@jhckevin/dsh-auto-review-bridge-linux-x64-gnu'), false);
}
if (mode === 'cold-installed') {
  for (const name of ['host','linux-x64-gnu']) {
    const p=base+'/node_modules/@jhckevin/dsh-auto-review-bridge-'+name+'/package.json';
    assert.equal(JSON.parse(readFileSync(p,'utf8')).version,'0.1.0-rc.2');
    assert.equal(lstatSync(p).uid,0);
  }
}
const { acquireCodexApprovalBridge } = await import(base + "/node_modules/@jhckevin/dsh-auto-review-bridge-host/index.mjs");
if (["same-uid", "writable-runtime", "relative-runtime"].includes(mode) || mode.startsWith("manifest-") || mode === "package-version") {
  assert.throws(acquireCodexApprovalBridge, e => e.kind === "artifact");
} else if (mode === "host-only") {
  assert.throws(acquireCodexApprovalBridge, e => e.kind === "artifact" && /unavailable/.test(e.message));
} else {
  const host = acquireCodexApprovalBridge();
  try {
    if (mode === "same-uid") {
      await assert.rejects(host.request(host.createSession(), "handshake"), e => e.kind === "artifact");
    } else {
      const artifact = (mode === 'cold-installed' ? '/cold-install' : '/install') + "/node_modules/@jhckevin/dsh-auto-review-bridge-linux-x64-gnu/bin/codex-approval-protocol-bridge";
      assert.equal(lstatSync(artifact).uid, 0);
      assert.throws(() => accessSync(artifact, constants.W_OK));
      const result = await host.request(host.createSession(), "parse_core_exec",
        '{"call_id":"pkg","command":[],"cwd":"/work","parsed_cmd":[],"started_at_ms":9223372036854775807}');
      assert.equal(result.ir.startedAtMs, "9223372036854775807");
      assert.match(result.canonicalWire, /9223372036854775807/);
    }
  } finally { await host.close(); }
}
console.log(JSON.stringify({mode, uid: process.geteuid(), status: "passed"}));
