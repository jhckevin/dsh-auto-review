#!/usr/bin/env python3
"""Declaration-material integrity only; leaves upstream-file and legal gates separate."""
import hashlib,json,pathlib,tarfile,tomllib
if not __debug__:
    raise RuntimeError('integrity gate refuses Python optimization that disables assertions')
ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT/'packages/platform/provenance/license-declarations'
def read(relative):
    path=BASE/relative
    if not path.resolve().is_relative_to(BASE.resolve()): raise ValueError('path escapes evidence')
    for part in [path,*path.parents]:
        if part==BASE.parent: break
        if part.is_symlink(): raise ValueError('symlink evidence')
    if not path.is_file() or path.stat().st_size>2*1024*1024: raise ValueError('invalid evidence file')
    return path.read_bytes()
sha=lambda data:hashlib.sha256(data).hexdigest()
lockBytes=read('Cargo.lock')
assert sha(lockBytes)=='9df7b57921c509ea84e7d524f60367fc260d38d080d9c9f3787b3a56ff7752ea'
lock=tomllib.loads(lockBytes.decode())['package']
value=json.loads(read('declarations.json'))
expected={'allocative@0.3.6','allocative_derive@0.3.6','debugserver-types@0.5.0','display_container@0.9.0',
          'eventsource-stream@0.2.3','fxhash@0.2.1','io_tee@0.1.1','linux-keyutils@0.2.4',
          'lock_free_hashtable@0.1.4','static_interner@0.1.2','strong_hash@0.1.0','strong_hash_derive@0.1.0'}
assert len(value['components'])==len(expected)==12
assert {x['component'] for x in value['components']}==expected
standard={'Apache-2.0':'074e6e32c86a4c0ef8b3ed25b721ca23aca83df277cd88106ef7177c354615ff','MIT':'b05785f9f18e6716bab63424b11454513b9943a222595b70411009202fc592b5'}
assert {x['license'] for x in value['standardTexts']}==set(standard)
for item in value['standardTexts']: assert sha(read(item['artifact']))==item['sha256']==standard[item['license']]
count=0
for row in value['components']:
    name,version=row['component'].split('@'); prefix=name+'-'+version
    checksum=next(p['checksum'] for p in lock if p['name']==name and p['version']==version)
    assert sha(read(row['archive']))==row['archiveSha256']==checksum
    with tarfile.open(BASE/row['archive']) as tar:
        package=tomllib.loads(tar.extractfile(prefix+'/Cargo.toml').read().decode())['package']
        assert package['license']==row['originalLicenseExpression']
        assert package.get('authors',[])==row['authors']
        assert row['selectedStandard']==('Apache-2.0' if 'Apache-2.0' in package['license'] else 'MIT')
        expectedFiles={m.name for m in tar.getmembers() if m.isfile() and (pathlib.PurePosixPath(m.name).name in ['Cargo.toml','Cargo.toml.orig','README.md','README'] or m.name.endswith('.rs'))}
        assert len(row['files'])==len(expectedFiles) and {x['archiveMember'] for x in row['files']}==expectedFiles
        for item in row['files']:
            raw=tar.extractfile(item['archiveMember']).read()
            assert read(item['artifact'])==raw and sha(raw)==item['sha256']
            count+=1
print(json.dumps({'declarationMaterialIntegrity':'PASS','components':12,'originalFiles':count,'upstreamLicenseFilesComplete':False,'legalApproval':False}))
