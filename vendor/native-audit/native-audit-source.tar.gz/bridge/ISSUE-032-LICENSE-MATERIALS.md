# ISSUE-032 / GitHub #5：v0.1.0-rc.1 后续许可证材料门禁修复

## 修复范围

本提交修复许可证材料发现与验证，不修改原生协议、二进制、运行器或冻结的 `dist/public-rc1/*.tgz`。新材料位于工作树，只有未来新版本重新打包后才会进入新的发布包；旧 rc.1 包的历史 FAIL 记录不被改写。

旧检查器只收集上游名为 LICENSE/NOTICE 等的文件。因此，已在固定发布 crate 中声明 MIT/Apache-2.0、但未随附独立 LICENSE 文件的依赖被统一归为缺件。现增加严格分类的来源证据，不能用任意 README 或布尔状态消除失败。

## 两类经过实际验证的材料

1. **精确上游原文：2 项。** `allocative@0.3.6`、`allocative_derive@0.3.6` 的发布 crate checksum 对应固定 Cargo.lock，分别 62、4 份非 Cargo 生成文件与上游 `fc41670cf9cfebd86ba597925081577897112c51` 完全一致。该 commit 的根 `LICENSE-APACHE`、`LICENSE-MIT` 原文随来源归档保存；不能替换为同名模板。
2. **固定发布授权声明 + 独立规范正文：10 项。** 校验固定 Cargo.lock、原 `.crate` checksum、原始 manifest 的精确 SPDX 表达式、作者/仓库字段、许可分支，以及固定 SPDX v3.27.0 正文 SHA。保留完整原 `.crate`，同时逐字节分发全部非空成员，避免仅挑选 Rust/README 文件遗漏其他位置的 copyright/notice。原作者字段为空时仍为空，不发明权利人或年份。

第二类是 `debugserver-types@0.5.0`、`display_container@0.9.0`、`eventsource-stream@0.2.3`、`fxhash@0.2.1`、`io_tee@0.1.1`、`linux-keyutils@0.2.4`、`lock_free_hashtable@0.1.4`、`static_interner@0.1.2`、`strong_hash@0.1.0`、`strong_hash_derive@0.1.0`。它们没有被宣称恢复了独立上游 LICENSE。

## 验证链

- `license-evidence.py`：每次从固定 lock、archive、原文件、标准文本重算；未知/缺失/变化表达式、源 hash 不匹配、文件缺失、路径穿越、symlink 或来源分类错误均失败。Python `-O` 不会关闭判断。
- `provenance/license-exact-source/`：精确 allocative 源码/许可证归档与逐文件 proof。
- `provenance/license-material-coverage.json`：可读材料清单，不是信任依据；必须等于实时重算结果。
- `licenses/<组件>/original-crate/`：从固定发布 archive 逐字节复制的全部非空成员。
- `licenses/<组件>/normative-*.txt`：独立标识的规范正文，不冒充上游文件。
- `evidence-gates.mjs`：在全 672 组件清单验证之前调用实际来源检查，要求 SBOM 材料集合和类型与重算结果完全一致。仅有非空材料数组不够。
- `generate-sbom.py`：先构建原清单，再接入上述来源材料；仅修复已证实的 `missing license text/expression`，不消除其他来源错误。

材料覆盖 `missing=[]` 与 `upstreamLicenseFilesMissing` 是不同字段；后者仍明确列出 10 项。`legalApproval=false` 保留，这不是法律充分性认证，也不是完整 Guardian 或生产安全保证。

## 本次执行证据

- `python3 license-evidence.test.py`：12/12 PASS。覆盖 archive 与自报 checksum 一起篡改、标准正文篡改、错误表达式/许可选择、组件遗漏/重复、原文件变动/遗漏、作者伪造、分发副本篡改/symlink、精确上游 proof 篡改、路径非法、伪造 coverage 与 Python 优化模式。
- `node --test evidence-gates.test.mjs license-source-gate.test.mjs`：8/8 PASS。包括假 clean audit、将声明伪标为原 LICENSE、非空但不完整的材料列表。
- `python3 check-license-declarations.py`：12 项原声明、119 个筛选原文件校验 PASS，独立上游文件完整性仍 false。
- `node verify-artifacts.mjs`：许可证材料部分通过；完整命令仍在开发流程门禁报错，未打印完整 VALID。运行器由独立 ISSUE 实现，此提交不修它。

冻结制品仍为 host SHA256 `1fa0edd6d68811818622cdaff4bb240c743ad8484548d710c9b8629ca4415d27`、platform `7e879d7384d2ede31ddeca0928d85e7f6203734232b49ea0aa8a32324424a24d`；bridge binary `be0889b1bc892a16c8dd026f552a8152e4d633723d2495e94ebb4fd4b4351ffc`、launcher `a752bc72f111fcc573c3e61fb90fa544541dac0ca498d2e279e1630d7c659b31`。没有重新编译或覆盖这些产物。
