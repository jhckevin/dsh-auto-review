#!/usr/bin/env python3
"""Verify actual npm tar material bytes and source-bound declaration mapping."""
import argparse
import importlib.util
import json
from pathlib import Path
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('license_evidence', ROOT/'license-evidence.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)

def extract_package(archive_path, destination):
    gate.require(archive_path.is_file() and archive_path.stat().st_size <= 32*1024**2, 'archive input bound')
    seen = set()
    total = 0
    with tarfile.open(archive_path, 'r:gz') as archive:
        for index, member in enumerate(archive):
            parts = member.name.split('/')
            gate.require(index < 30000 and parts[0] == 'package' and len(parts) > 1
                         and all(p and p not in ('.','..') and '\\' not in p and '\0' not in p for p in parts), 'unsafe package member')
            gate.require(member.isfile() and member.name not in seen, 'duplicate or nonregular package member')
            gate.require(0 <= member.size <= 16*1024**2, 'member size bound')
            total += member.size
            gate.require(total <= 64*1024**2, 'archive expansion bound')
            seen.add(member.name)
            target = destination.joinpath(*parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            data = archive.extractfile(member).read(member.size+1)
            gate.require(len(data) == member.size, 'archive member length mismatch')
            with target.open('xb') as out:
                out.write(data)
    return destination/'package'

def verify_tree(platform):
    source,_ = gate.inspect(platform)
    sbom = json.loads(gate.read(platform,'provenance/sbom.cdx.json'))
    refs = 0
    for component in sbom['components']:
        props = [p for p in component.get('properties',[]) if p['name'] == 'licenseMaterials']
        gate.require(len(props) == 1, 'missing/duplicate material property')
        materials = json.loads(props[0]['value'])
        gate.require(materials, 'component has no license materials')
        expected = source['components'].get(component['bom-ref'])
        if expected:
            gate.require(materials == expected['materials'], 'SBOM/source mapping mismatch')
        for material in materials:
            gate.require(gate.sha(gate.read(platform,material['path'])) == material['sha256'], 'packed material hash mismatch')
            refs += 1
    gate.require(len(sbom['components']) == 672 and refs == 1350, 'fixed graph/material coverage mismatch')
    return {'components':672,'verifiedMaterialReferences':refs,'sourceBoundComponents':len(source['components']),
            'upstreamOriginalLicenseFilesMissing':len(source['upstreamLicenseFilesMissing']),'legalApproval':False}

def verify_archive(path):
    with tempfile.TemporaryDirectory(prefix='native-npm-license-') as temp:
        return verify_tree(extract_package(path,Path(temp)))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('archive', type=Path)
    args = parser.parse_args()
    print(json.dumps(verify_archive(args.archive), indent=2))
