import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync, statSync} from 'node:fs';
import {test} from 'node:test';
import {createHostBridge} from './bridge-owner-v2.mjs';
import {createCodexApprovalBridge, acquireCodexApprovalBridge} from '/install/node_modules/@jhckevin/dsh-auto-review-bridge-host/index.mjs';

function artifact(path) {
  return {path, realpath:path, size:statSync(path).size,
    sha256:createHash('sha256').update(readFileSync(path)).digest('hex')};
}
function options(extra={}) {
  return {bridge:artifact('/opt/tests/codex-approval-protocol-bridge-v2.linux-x64-gnu'),
    launcher:artifact('/opt/tests/landlock-run.linux-x64'),
    expectedHandshake:{protocol:2,upstreamCommit:'9f97cb79eb15b38d24c552c56fe24e211ff9cf3a',
      bridgePatchSha256:'5cb90364c0a728dc97c278815905c5f6469a9139563fb08d17808908c1bef5c7',
      irVersion:1,os:'linux',arch:'x86_64'},timeoutMs:1000,shutdownMs:30,...extra};
}
const gone = pid => assert.throws(()=>process.kill(pid,0),error=>error.code==='ESRCH');

test('independent installed factories isolate sessions, children and disposal', async()=>{
  const a=createCodexApprovalBridge(), b=createCodexApprovalBridge();
  try {
    assert.notEqual(a,b);
    const sa=a.createSession(), sb=b.createSession();
    await a.request(sa,'handshake'); await b.request(sb,'handshake');
    assert.notEqual(a.pid,b.pid);
    await assert.rejects(b.request(sa,'handshake'),error=>error.kind==='session');
    const pid=a.pid, first=a.close();
    assert.equal(a.close(),first);
    await first; gone(pid);
    assert.equal(a.state,'closed');
    assert.equal((await b.request(sb,'parse_core_review_decision','"approved"')).ir.decision,'approved');
    const c=createCodexApprovalBridge();
    try {assert.equal((await c.request(c.createSession(),'handshake')).protocol,2)} finally {await c.close()}
  } finally {await Promise.all([a.close(),b.close()])}
});

test('close rejects active and queued work and observes forced child exit',async()=>{
  const owner=createHostBridge(options({maxInflight:1}));
  const session=owner.createSession();
  await owner.request(session,'handshake');
  const pid=owner.pid;
  process.kill(pid,'SIGSTOP');
  const pending=owner.request(session,'parse_core_review_decision','"approved"');
  const queued=owner.request(session,'parse_core_review_decision','"approved"');
  const assertions=[pending,queued].map(p=>assert.rejects(p,error=>error.kind==='closed'));
  try {
    const closed=owner.close(); assert.equal(owner.close(),closed);
    await closed; await Promise.all(assertions);
    gone(pid); assert.equal(owner.state,'closed');
    assert.throws(()=>owner.createSession(),error=>error.kind==='closed');
  } finally {await owner.close()}
});

test('close during startup cannot spawn or revive the disposed owner',async()=>{
  const owner=createHostBridge(options());
  const pending=owner.request(owner.createSession(),'handshake');
  const rejected=assert.rejects(pending,error=>error.kind==='closed');
  await owner.close(); await rejected;
  await new Promise(resolve=>setTimeout(resolve,50));
  assert.equal(owner.pid,undefined); assert.equal(owner.state,'closed');
});

test('closing a factory does not close the legacy singleton',async()=>{
  const legacy=acquireCodexApprovalBridge(), independent=createCodexApprovalBridge();
  const session=legacy.createSession();
  try {
    assert.equal(legacy,acquireCodexApprovalBridge());
    await legacy.request(session,'handshake');
    await independent.close();
    assert.equal((await legacy.request(session,'handshake')).protocol,2);
  } finally {await legacy.close()}
});
