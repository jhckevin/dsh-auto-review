#!/usr/bin/env python3
"""Preserve fixed crate declarations plus clearly labelled normative license text."""
import hashlib, json, pathlib, re, shutil, tarfile, tomllib
ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT/'packages/platform/provenance/license-declarations'
LOCK = pathlib.Path('/srv/pi-lab-dev/tmp/issue022b-bridge-worktree/codex-rs/Cargo.lock')
CACHE = pathlib.Path('/srv/pi-lab-dev/tmp/issue022b-native-bridge-prototype/license-recovery/published-evidence')
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(LOCK.read_bytes()) == '9df7b57921c509ea84e7d524f60367fc260d38d080d9c9f3787b3a56ff7752ea'
lock = tomllib.loads(LOCK.read_text())['package']
missing = json.loads((ROOT/'packages/platform/provenance/license-audit.json').read_text())['missing']
OUT.mkdir(exist_ok=False)
standard = OUT/'standard'; standard.mkdir()
standards = []
for license in ['Apache-2.0','MIT']:
    source = ROOT/'.license-cache/standard'/f'{license}.txt'
    target = standard/source.name; shutil.copyfile(source,target)
    standards.append({'license':license,'artifact':str(target.relative_to(OUT)), 'sha256':sha(target.read_bytes()),
      'source':'https://ghfast.top/https://raw.githubusercontent.com/spdx/license-list-data/v3.27.0/text/'+source.name,
      'scope':'Normative SPDX license text, not an upstream crate LICENSE or invented copyright notice'})
rows=[]
for text in missing:
    component=text.split(':')[0]; name,version=component.split('@'); prefix=name+'-'+version
    archive=CACHE/prefix/(prefix+'.crate')
    expected=next(p['checksum'] for p in lock if p['name']==name and p['version']==version)
    assert sha(archive.read_bytes())==expected, component
    target=OUT/prefix; target.mkdir()
    shutil.copyfile(archive,target/archive.name)
    files=[]; declaration=None; notices=[]
    with tarfile.open(archive) as tar:
      for member in tar.getmembers():
        path=pathlib.PurePosixPath(member.name)
        if not member.isfile() or path.parts[0]!=prefix or '..' in path.parts: continue
        local=pathlib.Path(*path.parts[1:])
        if local.name not in ['Cargo.toml','Cargo.toml.orig','README.md','README'] and local.suffix!='.rs': continue
        assert member.size<=2*1024*1024
        data=tar.extractfile(member).read()
        dest=target/'original'/local; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
        files.append({'artifact':str(dest.relative_to(OUT)),'sha256':sha(data),'bytes':len(data),'archiveMember':member.name})
        if str(local)=='Cargo.toml': declaration=tomllib.loads(data.decode())['package']
        for i,line in enumerate(data.decode().splitlines()):
          if re.search(r'copyright|licensed under|apache license|MIT license',line,re.I):
            notices.append({'artifact':str(dest.relative_to(OUT)), 'line':i+1, 'text':line})
    assert declaration and declaration.get('license'),component
    expression=declaration['license']; chosen='Apache-2.0' if 'Apache-2.0' in expression else 'MIT'
    assert chosen=='Apache-2.0' or expression=='MIT'
    rows.append({'component':component,'originalLicenseExpression':expression,'selectedStandard':chosen,
      'authors':declaration.get('authors',[]),'repository':declaration.get('repository'),
      'archive':str((target/archive.name).relative_to(OUT)),'archiveSha256':expected,
      'upstreamLicenseFileFound':False,'copyrightNoticeStatus':'only original notices retained; absent notices not invented',
      'files':files,'noticeLocations':notices})
(OUT/'declarations.json').write_text(json.dumps({'schemaVersion':1,'status':'source declarations and standard texts; not legal certification',
  'cargoLockSha256':sha(LOCK.read_bytes()),'standardTexts':standards,'components':rows},indent=2)+'\n')
print(json.dumps({'components':len(rows),'files':sum(len(r['files']) for r in rows),'upstreamFileGate':'unchanged; 12 missing','legalApproval':False}))
