#!/bin/sh
IFS= read -r handshake
id=$(printf '%s' "$handshake" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
session=$(printf '%s' "$handshake" | sed -n 's/.*"session_id":"\([^"]*\)".*/\1/p')
printf '{"id":"%s","session_id":"%s","ok":true,"result":{"protocol":1,"upstreamCommit":"9f97cb79eb15b38d24c552c56fe24e211ff9cf3a","bridgePatchSha256":"prototype","os":"linux","arch":"x86_64"}}\n' "$id" "$session"
IFS= read -r request
id=$(printf '%s' "$request" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
printf '{"id":"%s","session_id":"wrong-session","ok":true,"result":{}}\n' "$id"
