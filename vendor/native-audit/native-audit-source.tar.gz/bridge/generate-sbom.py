#!/usr/bin/env python3
"""Target-specific build-input SBOM and verbatim license material, not a legal certification."""
import hashlib, json, os, pathlib, re, shutil, subprocess, tarfile, tomllib
ROOT = pathlib.Path(__file__).resolve().parent
SOURCE = pathlib.Path(os.environ.get("CODEX_BRIDGE_SOURCE", "/srv/pi-lab-dev/tmp/issue022b-bridge-repro-source"))
CARGO = pathlib.Path("/srv/pi-lab-dev/tmp/cargo")
OUT = ROOT / "packages/platform/provenance"
LICENSES = ROOT / "packages/platform/licenses"
LOCK = tomllib.loads((SOURCE / "codex-rs/Cargo.lock").read_text())
lock_entries = LOCK["package"]
LICENSES.mkdir(exist_ok=True)
components, edges, stack, errors = {}, {}, [], []
git_manifests = list((CARGO / "git/checkouts").glob("*/*/**/Cargo.toml"))
recovered = {}
recovery_root = OUT / "license-recovery"
if (recovery_root / "recovery-result.json").exists():
    inventory = {x["component"]: x for x in json.loads((recovery_root / "inventory.json").read_text())}
    for group in json.loads((recovery_root / "recovery-result.json").read_text())["groups"]:
        for item in group["files"]:
            path = (recovery_root / item["artifact"]).resolve()
            if not path.is_relative_to(recovery_root.resolve()): raise ValueError("unsafe recovery path")
            data = path.read_bytes()
            blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
            if hashlib.sha256(data).hexdigest() != item["sha256"] or blob != item["gitBlobSha1"]: raise ValueError("recovery hash mismatch")
            for component in item["components"]:
                if inventory[component].get("commit") != item["commit"]: raise ValueError("recovery commit mismatch")
                recovered.setdefault(component, []).append(path)
    supplement = json.loads((recovery_root / "published-supplement.json").read_text())
    for row in supplement["rows"]:
        if not row["fullTextRecovered"]: continue
        name, version = row["component"].split("@")
        checksum = next(x["checksum"] for x in lock_entries if x["name"] == name and x["version"] == version)
        if hashlib.sha256((recovery_root / row["archiveArtifact"]).read_bytes()).hexdigest() != checksum: raise ValueError("supplement checksum mismatch")
        for item in row["files"]:
            if "licenseEvidenceLines" not in item: continue
            path = (recovery_root / item["artifact"]).resolve()
            if not path.is_relative_to(recovery_root.resolve()) or hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]: raise ValueError("supplement content mismatch")
            recovered.setdefault(row["component"], []).append(path)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def find_source(name, version, label):
    local = re.search(r"\((/[^)]+)\)", label)
    if local: return pathlib.Path(local.group(1))
    paths = list((CARGO / "registry/src").glob("*/" + name + "-" + version))
    if "https://" in label:
        paths = []
        for manifest in git_manifests:
            try:
                p = tomllib.loads(manifest.read_text()).get("package", {})
                if p.get("name") == name and p.get("version") == version: paths.append(manifest.parent)
            except (ValueError, OSError): pass
    if len(paths) != 1: raise ValueError("source lookup ambiguous/missing: " + name + " " + version)
    return paths[0]
for line in (OUT / "cargo-tree-depth.txt").read_text().splitlines():
    match = re.fullmatch(r"(\d+)(\S+) v([^ ]+)(.*?)\|(.+?)(?: \(\*\))?", line)
    if not match: raise ValueError("bad cargo tree line")
    depth, name, version, label, expression = match.groups()
    depth = int(depth)
    ref = name + "@" + version
    if depth > len(stack): raise ValueError("invalid dependency depth")
    stack = stack[:depth]
    if stack: edges.setdefault(stack[-1], set()).add(ref)
    stack.append(ref)
    edges.setdefault(ref, set())
    if ref in components: continue
    src = find_source(name, version, label)
    package = tomllib.loads((src / "Cargo.toml").read_text()).get("package", {})
    files = [p for p in src.iterdir() if p.is_file() and re.match(r"(?i)^(license|licence|copying|copyright|notice)", p.name)]
    if isinstance(package.get("license-file"), str): files.append(src / package["license-file"])
    if src.is_relative_to(SOURCE) and not files: files = [SOURCE / "LICENSE", SOURCE / "NOTICE"]
    # Some nested git crates inherit repository-root notices.
    if not files and src.is_relative_to(CARGO / "git/checkouts"):
        for parent in src.parents:
            if parent == CARGO / "git/checkouts": break
            files = [p for p in parent.iterdir() if p.is_file() and re.match(r"(?i)^(license|licence|copying|copyright|notice)", p.name)]
            if files: break
    if not files: files = recovered.get(ref, [])
    if not files or expression in ["", "UNKNOWN"]: errors.append(ref + ": missing license text/expression")
    target = LICENSES / ref
    target.mkdir(exist_ok=True)
    material = []
    for index, path in enumerate(sorted(set(files))):
        dest = target / (str(index) + "-" + path.name)
        shutil.copyfile(path, dest)
        material.append({"path": str(dest.relative_to(ROOT / "packages/platform")), "sha256": sha(dest)})
    candidates = [p for p in lock_entries if p["name"] == name and p["version"] == version]
    if len(candidates) != 1: errors.append(ref + ": ambiguous lock source")
    entry = candidates[0]
    component = {"type": "library", "bom-ref": ref, "name": name, "version": version,
      "licenses": [{"expression": expression}], "properties": [
        {"name": "buildScope", "value": "target normal+build dependency; includes build-only inputs"},
        {"name": "source", "value": entry.get("source", "fixed-upstream:" + name)},
        {"name": "licenseMaterials", "value": json.dumps(material, sort_keys=True)}]}
    if entry.get("checksum"): component["hashes"] = [{"alg": "SHA-256", "content": entry["checksum"]}]
    components[ref] = component
sbom = {"bomFormat": "CycloneDX", "specVersion": "1.6", "version": 1,
  "metadata": {"component": {"type": "application", "name": "auto-review-native-bridge", "version": "0.1.0-rc.2"}},
  "components": sorted(components.values(), key=lambda v: v["bom-ref"]),
  "dependencies": [{"ref": k, "dependsOn": sorted(v)} for k, v in sorted(edges.items())]}
(OUT / "sbom.cdx.json").write_text(json.dumps(sbom, indent=2) + "\n")
(OUT / "license-audit.json").write_text(json.dumps({"scope": "target normal/build dependency inventory; legal review still required",
  "components": len(components), "missing": errors, "sourceGraphSha256": sha(OUT / "cargo-tree-depth.txt")}, indent=2) + "\n")
subprocess.run(['python3', str(ROOT/'license-evidence.py'), '--materialize'], check=True, stdout=subprocess.DEVNULL)
audit = json.loads((OUT/'license-audit.json').read_text())
print(json.dumps({'components': len(components), 'missing': audit['missing'],
                  'upstreamLicenseFilesMissing': audit['upstreamLicenseFilesMissing'], 'legalApproval': False}))
if audit['missing']: raise SystemExit(1)
