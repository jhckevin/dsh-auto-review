# 2026-09-02 主审现场核验

本文件不是发布通过声明。主插件仓库保持原 HEAD 和冻结草稿，未合入或部署本原型。

## 冻结 Rust 修复

- 上游：`9f97cb79eb15b38d24c552c56fe24e211ff9cf3a`。
- 补丁 SHA256：`35c5196aee02d0a4dd229a0faf7fe782d64c435042ecc675940be8b1b785eebd`。
- GNU2.31 制品 SHA256：`be0889b1bc892a16c8dd026f552a8152e4d633723d2495e94ebb4fd4b4351ffc`。
- 首次缓存增量构建、Rust 两项单测成功，见 final-build.log。
- 新建固定提交的干净 worktree、全新 target、同一 builder image、只读源码、禁网构建成功，见 repro-final-build.log。
- 主审执行 sha256sum 和 cmp：新 clean 制品与缓存增量制品逐字节一致。
- 新 worktree 最初继承 sparse 配置，因 Cargo 文件未检出导致 apply --check 失败；未应用补丁。随后仅在新 worktree 禁用 sparse，确认 clean 后重新检查/应用成功。此准备失败不计构建通过。
- 主审进程回归 6/6，通过记录在 rust-remediation-results.log；旧输出 cap 缺陷的 4/5 失败记录保留在 rust-before-output-cap.log。
- 两份独立限定 Rust 审查报告分别为 RUST-REMEDIATION-REVIEW.md、RUST-SECOND-REVIEW.md。它们不涵盖完整 B1、owner 或安装包。

## 许可证材料字节与来源核验

主审重新计算（不采用下载者自报的 verified 布尔值）：

- 31 份 Git 来源文本的字节数、SHA256 和 Git blob SHA1 均匹配恢复清单。
- 13 份发布 .crate 的 SHA256 与固定 Codex Cargo.lock 对应 name/version/checksum 匹配。
- 25 份保留的 archive member 与 .crate 中对应成员逐字节一致。
- 原恢复 47 个组件，加 bech32 源文件中的完整 MIT 文本，共 48/60；仍缺 12 项。
- 此结论仅表示所保存原文与其来源一致，不是法律充分性判断，也不是分发门禁通过。

## 仍不满足的条件

- 全部协议与审批运行时未完成；PROTOCOL-COVERAGE-REVIEW.md 的 FAIL 保留。
- owner/平台包必须在最终冻结版本上独立审查，不以 Rust PASS 替代。
- 12 项许可证材料缺口必须保持失败，不能用模板伪装来源。
- 固定上游 AGENTS 规定的测试布局、just fmt/fix/test、Bazel lock 门禁未完成；本轮 cargo test 结果不能冒充这些门禁。
- 本轮不是模型评测，没有调用 Flash/Pro 评审模型，不产生模型安全成功率结论。
