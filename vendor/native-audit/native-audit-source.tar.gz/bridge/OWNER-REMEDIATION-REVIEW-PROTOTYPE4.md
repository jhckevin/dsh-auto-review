# Independent owner/package prototype.4 remediation review

Date: 2026-09-02. Reviewer: bridge_security_review.
Verdict: FAIL. P0=0/P1=0/P2=1 newly reproduced finding.

## Frozen target

- Commit: `198ac99ddf8bf136fdfb4a4373b65eaca2ca22ec`.
- Owner SHA256: `efd4cc34a16707e85713ad981119477156711c0e99c8a35b4f4ea5c30a1f6a3d`.
- Owner test SHA256: `34f19bbe7d561836096fcbb3f0760219408936cd0c1642b2aabdda830e4633af`.
- Exact test image: `sha256:dbddb9a31f323bf4a83a31cc8bf3ea45570c0b27a98ef84dab4e57f37042cb19`.
- Base path: `/srv/pi-lab-dev/tmp/issue022b-native-bridge-prototype`.

Source was clean at initial read and matched the specified commit/hash. Only this report was written with safe apply_patch. No source modifications, large builds, license edits or evidence substitutions were performed. Later fixes are outside this verdict.

## Independent verification completed

Ran the exact image with `--pull=never --rm --network=none --read-only --tmpfs /tmp:rw,noexec,nosuid,nodev,size=16m`.

- Owner: 20 tests, 20 pass, 0 failures/skips/cancellations, duration 4284.38932ms.
- Package: all 9 cases passed at uid65532 (installed and eight expected rejection cases).
- This includes the 89 finite/safe-integer/timer-boundary configuration negative assertions, prototype-key response tests, bounded admission, queued expiry, per-frame decoding, closed session/startup tests and real artifact execution.

Re-executed my earlier real-bridge queue deadlock reproduction with the same maxInflight=1, maxInflightBytes=1024, maxQueueBytes=8192 and timeoutMs=100. The oversized queued candidate now rejects with backpressure in 0.475557ms rather than remaining pending. The next small request returned approved on generation 1. This previous finding is resolved.

The queue timeout change is explicitly per-stage: startup uses its separate probe/backoff/handshake bounds; queue waiting begins on queue insertion; actual dispatch receives a fresh execution timeout. This is not a single end-to-end deadline. Within that contract, monotonic queueDeadline checks, timer clearing, queue removal and byte-budget release are present, and the tests demonstrate replacement requests can progress after expiry and no late queue timer runs after abort/session-close/host-close.

## P2: A stale stdin write callback can kill the next bridge generation

Location: `bridge-owner-v2.mjs:487-500`, especially 498-499. Related unguarded callbacks: 448-452.

The async callback registered by child.stdin.write calls this.#restart on an error without checking that the callback belongs to the current child. After cancellation kills a child with an outstanding buffered write, its eventual EPIPE can arrive after a replacement child has already been assigned. The stale callback then terminates that replacement and rejects its unrelated new handshake/request.

This was independently reproduced in the exact frozen image with a real bridge, not a mock. The explicit zero backoff configuration is supported and validated by this version; the default 25ms backoff was not claimed to reproduce this timing.

Reproduction core (real root-owned artifact descriptors were computed from /opt/tests):

```js
const host = acquireHostBridge({ ...realArtifactOptions,
  baseBackoffMs: 0, maxBackoffMs: 0, timeoutMs: 1000 });
const session = host.createSession();
await host.request(session, 'handshake');
process.kill(host.pid, 'SIGSTOP');
const controller = new AbortController();
const first = host.request(session, 'parse_core_review_decision',
  JSON.stringify({ denied: { rejection: 'x'.repeat(1000000) } }),
  { signal: controller.signal }).then(() => 'ok', error => error.kind);
await new Promise(resolve => setTimeout(resolve, 20));
controller.abort();
const next = host.request(session, 'handshake').then(() => 'ok',
  error => ({ kind: error.kind, message: error.message }));
console.log({ first: await first, next: await next,
  state: host.state, generation: host.generation });
await host.close();
```

Observed:

```json
{"first":"cancelled","next":{"kind":"write","message":"write EPIPE"},"state":"backoff","generation":2}
```

The first request was correctly cancelled. The new generation was incorrectly failed by an old generation's write completion. Cleanup explicitly closed the host and removed the transient container.

Required correction:

- Capture the child/generation for each async write callback and ignore stale callbacks before touching shared state or calling restart.
- Apply the same ownership check to stderr data and stdin drain handlers; the stdout/exit handlers already have child identity protection, but stderr/drain do not. They must not charge a new stderr budget, clear its backpressure or drain its queue from an old process's event.
- Review timeout/abort callbacks for matching item/generation ownership where applicable.
- Add a real-pipe backpressure regression using zero backoff, immediate cancellation and next-generation request. Do not mask this by imposing a delay or replaying the failed new request.

## Scope disposition

The previously identified unsendable queue-head defect is resolved, and the shipped 20+9 tests pass. Nevertheless this frozen owner cannot receive scoped PASS until the stale callback race is fixed and independently checked. The prototype-key change uses own-property checks and catches validator exceptions; no new issue in that change was found by this reviewer.

CI false-green prevention was separately reviewed at commit94d725b. Actual license and development gates remain blocked; this report neither reruns those gates nor claims their completion. Rust, full B1 parity, native Harness integration and production release are outside this review. Preserve this FAIL as history and use a new frozen review for remediation.
