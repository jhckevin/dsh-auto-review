# ISSUE #5：受控上游开发工作流执行器

这里的 runner 是冻结 Codex Rust bridge 补丁的开发规范执行与证据采集器，
不是 Guardian 模型、DSH 工具执行器，也不意味着复制了整个 Codex 安全架构。

## 执行契约

`node development-runner.mjs ABS_SOURCE NEW_ABS_OUTPUT FROZEN_PATCH`

- 仅 Linux x86_64；源 HEAD 固定 `9f97cb79eb15b38d24c552c56fe24e211ff9cf3a`。
- 源目录必须独立、绝对、规范路径，输出必须是新的外部目录，拒绝覆盖旧证据。
- 源变更仅限 bridge crate、workspace Cargo.toml/Cargo.lock、MODULE.bazel.lock。
  新文件必须 `git add -N` 纳入真实 diff；不接受遗漏未跟踪源文件的摘要。
- 校验 sibling `main_tests.rs` 布局及真实测试函数。此静态检查不是 Rust parser；
  随后的实际 nextest 编译/执行仍是必需步骤。
- 固定命令，不接受任意命令或步骤成功覆盖：工具版本，`just test -p
  codex-approval-protocol-bridge-prototype`，`just fix -p ...`，`just fmt`，
  `just bazel-lock-update`，`just bazel-lock-check`。Cargo 依赖有变化，所以
  Bazel 步骤不可省略。没有 shared crate 改动，不擅自展开全 workspace 测试。
- 遵循固定 AGENTS：test 后执行 fix/fmt，不在本次流程中自动重测。任何命令
  改变源 diff 都立即失败并留下记录；维护者必须审阅新改动、重新冻结补丁并
  重建/复审新制品，不能将旧二进制与新源混称同一验收。
- PATH 必须全部绝对；环境白名单无 API key/代理/LD_PRELOAD/RUSTFLAGS。
  新 HOME/TMP；允许明确 CARGO_HOME/RUSTUP_HOME/CARGO_TARGET_DIR 使用预置缓存。
  `CARGO_BUILD_JOBS=1`、`CARGO_INCREMENTAL=0`、Cargo offline 固定。Cargo offline
  编译必需的 `CODEX_BRIDGE_PATCH_SHA256` 只能由冻结 patch 的真实字节计算并注入，
  验证器要求它与 manifest 一致；不继承用户提供的同名值。uv 索引固定为
  `https://pypi.tuna.tsinghua.edu.cn/simple` 并记录，不接受任意覆盖 URL。
  不等于所有步骤网络隔离：Bazel、formatter 工具仍可能联网；外部执行环境必须
  单独控制网络/镜像及 CPU、内存、磁盘。该脚本自身不声称提供 OS sandbox。
- 当前版本禁止任何 `RUSTUP_TOOLCHAIN` override（包括 1.95），使用固定源
  rust-toolchain.toml，并独立核验实际 rustc 1.95.0。旧版本 1.96 诊断历史保留，
  不可算作本版本严格上游开发门禁通过。
- 可选 `UV_CACHE_DIR` 和 `DOTSLASH_CACHE` 仅接受已有 canonical 工具缓存目录，
  不接受文件、symlink alias、相对路径或配置参数；路径进入环境证据。既有缓存
  属可信构建工具输入，不继承旧 HOME/配置/会话。实际启动前单独核验预期
  buildifier 与 Ruff 缓存二进制 hash，不将其称为包管理全缓存安全证明。
- 每一步保留命令、实际 tool 路径/文件 SHA、单调起止时间、exit/signal、合并
  stdout/stderr 日志 SHA/长度、前后源 patch/lock SHA。日志每步最多 64 MiB；
  溢出持续 drain 并判失败，不通过杀 Rust PID 缩短任务。外部中止只留下不完整
  记录，门禁拒绝。脚本不承诺单步运行时长上限。

### Cargo 配置与真实 Rust 工具绑定

仅允许固定上游 `codex-rs/.cargo/config.toml` 的完整 SHA（其中是 Windows target
配置）。检查 source/codex-rs、source、output 的所有祖先及 CARGO_HOME 下两种
`config`/`config.toml` 名称；其它配置和配置目录 symlink（包含 dangling）均拒绝，
不会解析或输出可能包含凭据的外部配置内容。各命令前后复核配置存在性与 hash。

通过受控 `rustup which --toolchain 1.95.0` 解析 cargo、rustc、cargo-clippy、
clippy-driver、cargo-fmt、rustfmt 六个真实工具。要求同一固定 1.95 bin 目录，
把该目录放在 PATH 第二位（第一位仅有 Bazel wrapper），因此 Cargo 子进程的
rustc 也从该目录解析，不再仅依赖 rustup dispatcher 的 hash。实际文件 hash、
固定查询参数和路径进入证据，各命令前后复核。不把这称为恶意同 UID / 动态库
攻击者的完整沙盒；执行宿主与整套已安装工具链仍是可信输入。

旧 e 流程已真实完成并通过其对应版本验证，但没有本节增强证据；必须另执行 f，
不得将 e 的结果复制为增强后 runner 的通过记录。

## 证据验收与信任边界

### 固定 Bazel 镜像环境（Refs #5）

`development-mirrors.json` 固定 293 条精确 URL、镜像与 SHA256：264 条锁文件
registry 元数据及 29 个已评估规则源码/工具。Bazel 按自身 pinned integrity
验证下载及 repository cache；策略不是跳过上游哈希的替代下载器。不允许通配
任意 GitHub 下载，不开放任意 mirror URL、Bazel flag、override_repository。
精确 URL 限制指原地址 rewrite 集合；Bazel downloader 的 allow 原语按 host，
因此并非恶意代码通用 URL 防火墙。三个镜像 host 上的直接请求仍可被 downloader
允许。保证依赖于固定源码、锁文件与上游 integrity；不得声称网络级绝对资源白名单。

runner 生成固定包装入口（仅安全绝对路径字符），禁用系统、HOME、自动 workspace
rc，只显式加载字节固定的上游 `.bazelrc` 和生成的资源/镜像配置。上游可选
`user.bazelrc` 在各步骤前后必须不存在，包含 dangling symlink。上游配置内容
不重写；新增 `.bazelrc`、MODULE.bazel、BuildBuddy helper 的源码 hash 绑定。

唯一可选输入 `DSH_DEVELOPMENT_REPOSITORY_CACHE=/canonical/path` 是下载缓存目录；
默认使用本次新目录。新 repo-contents、disk-cache、output-user-root 均位于本次
output，不复用 OS HOME 中的变换后仓库。缓存仍属可信执行环境，不把其路径当
OS 隔离。新策略、生成配置、包装脚本、真实 Bazel executable SHA 进入证据，
每条命令前后复核，不接受修改配置后仅更新自报 hash。包装入口不新增调度能力。

2026-09-03 独立诊断中真实 `just bazel-lock-update` 和 `just bazel-lock-check`
均 exit 0；MODULE.bazel.lock 未改变，formatter 后补丁仍为 `5cb90364…`。
这不等于新增镜像模块下完整 runner 已通过，也不能为旧二进制替换 manifest。
旧失败执行与独立 Bazel 日志必须保留。

输出目录需完整收集到平台包 `provenance/development-execution/`（仅证据文件，
不要打包 home/tmp/target 或 bazel 的任何缓存；保留 bazel/policy.json、config.bazelrc、
downloader.cfg、bin/bazel 四个证据文件）。`inspectExecutedDevelopmentEvidence` 校验固定路径、
无 symlink、有限文件大小、每一步顺序/参数/退出/日志完整性及 hash，绑定当前
runner/verifier 源 SHA、平台 manifest patch 与 Cargo.lock。缺文件、手填 status、
修改 argv、部分步骤、旧证据、源漂移均不能通过。

这些 SHA 不是签名，也不能对抗能修改整个工作目录/程序的恶意同 UID 操作者。
真实执行必须由可信 CI/受控维护环境调用固定 runner，保留其外部进程日志与不可变
artifact，并独立审阅。工具缓存、PATH 工具、Cargo config、内核是执行环境信任边界，
不得把生成一份合法 JSON 当成不可伪造的执行证明。

成功只代表此 bridge 补丁的 scoped 开发流程。许可证原文覆盖、binary/launcher provenance、
原生 owner 安全、clean 双构建重现、DSH 集成与生产行为仍分别验收；不能修改任何
独立失败门禁来扩大结论。当前新增测试属于 runner 自身的真实小进程/负例测试，
不代表 upstream Rust 的 just/nextest/Bazel 已经成功执行。
