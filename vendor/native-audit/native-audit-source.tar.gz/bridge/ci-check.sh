#!/bin/sh
echo "Historical rc1/1.96 entry: does not validate rc2. See RC2-REPRODUCIBILITY.md." >&2
exit 2
# Mandatory combined acceptance. Diagnostic runtime checks alone do not satisfy this gate.
set -eu
cd "$(dirname "$0")"
export PATH=/srv/pi-lab-dev/toolchains/node-v24.8.0-linux-x64/bin:$PATH
node --check bridge-owner-v2.mjs
node pin-provenance.mjs --check
node --test evidence-gates.test.mjs
node verify-artifacts.mjs
sh run-package-e2e.sh
sh clean-rebuild-ci.sh
printf '%s\n' 'NATIVE-BRIDGE-COMBINED-CI-VALID'
