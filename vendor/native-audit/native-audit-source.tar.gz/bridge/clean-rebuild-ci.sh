#!/bin/sh
echo "Historical rc1/1.96 entry: does not validate rc2. See RC2-REPRODUCIBILITY.md." >&2
exit 2
# Clean fixed-source rebuild; requires prepared builder image and Cargo mirror cache.
set -eu
stage=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
source_repo=/srv/pi-lab-dev/tmp/issue022b-bridge-worktree
commit=9f97cb79eb15b38d24c552c56fe24e211ff9cf3a
image=sha256:d3a75b5ef6faa77d8074c1cb1d41b08e5f9cf6775d6651e87ffe98e41139abc7
scratch=$(mktemp -d /srv/pi-lab-dev/tmp/issue022b-clean-ci.XXXXXX)
printf '%s\n' "$scratch"
test "$(realpath "$scratch")" = "$scratch"
cleanup() {
  rc=$?
  trap - EXIT HUP INT TERM
  if [ "$rc" = 0 ] && [ "${KEEP_BRIDGE_CI_WORKDIR:-0}" = 0 ]; then
    test ! -L "$scratch" && test "$(realpath "$scratch")" = "$scratch" || exit 65
    case "$scratch" in /srv/pi-lab-dev/tmp/issue022b-clean-ci.*) ;; *) exit 65;; esac
    for leaf in src target; do
      test ! -L "$scratch/$leaf" && test "$(realpath "$scratch/$leaf")" = "$scratch/$leaf" || exit 65
    done
    git -C "$source_repo" worktree remove --force "$scratch/src" || exit 65
    test ! -L "$scratch" && test "$(realpath "$scratch")" = "$scratch" || exit 65
    rm -rf -- "$scratch"
  else
    printf 'Retained build evidence: %s (exit %s)\n' "$scratch" "$rc" >&2
  fi
  exit "$rc"
}
trap cleanup EXIT HUP INT TERM
git -C "$source_repo" worktree add --detach "$scratch/src" "$commit"
git -C "$scratch/src" sparse-checkout disable
test -z "$(git -C "$scratch/src" status --porcelain)"
git -C "$scratch/src" apply --check "$stage/codex-bridge-v2.patch"
git -C "$scratch/src" apply "$stage/codex-bridge-v2.patch"
mkdir "$scratch/target"
hash=$(sha256sum "$stage/codex-bridge-v2.patch" | cut -d ' ' -f 1)
podman run --pull=never --rm --network=none --cpus=2 --memory=4g \
  -v "$scratch/src:/src:ro" -v "$scratch/target:/target:rw" \
  -v /srv/pi-lab-dev/tmp/cargo:/cargo:rw -v /srv/pi-lab-dev/tmp/rustup:/rustup:ro \
  -e CARGO_HOME=/cargo -e RUSTUP_HOME=/rustup -e CARGO_TARGET_DIR=/target \
  -e RUSTUP_TOOLCHAIN=1.96.0-x86_64-unknown-linux-gnu -e CARGO_BUILD_JOBS=2 \
  -e CODEX_BRIDGE_PATCH_SHA256="$hash" \
  -e PATH=/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
  -w /src/codex-rs "$image" sh -ec 'cargo build --locked --offline --release -p codex-approval-protocol-bridge-prototype'
podman run --pull=never --rm --network=none -v "$scratch/target:/target:rw" "$image" \
  strip --strip-all -o /target/rebuilt /target/release/codex-approval-protocol-bridge
sha256sum "$scratch/target/rebuilt"
cmp "$scratch/target/rebuilt" "$stage/packages/platform/bin/codex-approval-protocol-bridge"
