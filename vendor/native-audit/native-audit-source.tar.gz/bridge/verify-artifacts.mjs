import assert from "node:assert/strict";
import {readFileSync, statSync} from "node:fs";
import {createHash} from "node:crypto";
import {execFileSync} from "node:child_process";
import {inspectLicenseEvidence, inspectDevelopmentEvidence} from "./evidence-gates.mjs";
const sha = path => createHash("sha256").update(readFileSync(path)).digest("hex");
const root = "packages/platform/";
const manifest = JSON.parse(readFileSync(root + "artifact-manifest.json", "utf8"));
const pinned = JSON.parse(readFileSync("packages/host/expected-provenance.json", "utf8"));
assert.deepEqual(manifest, pinned.manifest);
assert.deepEqual(JSON.parse(readFileSync(root + "package.json", "utf8")), pinned.package);
assert.equal(manifest.upstreamCommit, "9f97cb79eb15b38d24c552c56fe24e211ff9cf3a");
assert.equal(sha("codex-bridge-development.patch"), manifest.patchSha256);
assert.equal(sha(root + "provenance/codex-bridge-development.patch"), manifest.patchSha256);
for (const spec of [manifest.bridge, manifest.launcher]) {
  assert.equal(statSync(root + spec.path).size, spec.size);
  assert.equal(sha(root + spec.path), spec.sha256);
}
assert.equal(manifest.buildImageSha256, "d3a75b5ef6faa77d8074c1cb1d41b08e5f9cf6775d6651e87ffe98e41139abc7");
assert.equal(sha(root + "provenance/builder-dpkg.txt"), manifest.builderDpkgSha256);
assert.equal(execFileSync("podman", ["image", "inspect", "sha256:" + manifest.buildImageSha256, "--format", "{{.Id}}"], {encoding:"utf8"}).trim(), manifest.buildImageSha256);
assert.equal(sha("bridge-owner-v2.mjs"), sha("packages/host/bridge-owner.mjs"));
const failedGates = [];
execFileSync('python3', ['launcher-evidence.py', '--platform-root', root], {stdio:'inherit'});
let sourceMaterialAudit;
try {
  const audit = inspectLicenseEvidence(root);
  sourceMaterialAudit = audit;
  if (audit.missing.length) failedGates.push("LICENSE-GATE-FAIL: " + audit.missing.length + " components lack source-backed license material");
} catch (error) {
  failedGates.push("LICENSE-GATE-FAIL: " + String(error.message));
}
try {
  const upstream = inspectDevelopmentEvidence(root);
  if (!upstream.accepted) failedGates.push(upstream.reason);
} catch (error) {
  failedGates.push("UPSTREAM-DEVELOPMENT-GATE-FAIL: " + String(error.message));
}
if (sourceMaterialAudit) {
  console.log(JSON.stringify({
    scope: "source-bound material coverage; not legal sufficiency certification",
    upstreamLicenseFilesMissing: sourceMaterialAudit.upstreamLicenseFilesMissing,
    upstreamLicenseFilesMissingCount: sourceMaterialAudit.upstreamLicenseFilesMissing.length,
    legalApproval: sourceMaterialAudit.legalApproval,
  }));
}
if (failedGates.length) throw new Error(failedGates.join("; "));
console.log("ARTIFACT-AND-SOURCE-MATERIAL-GATE-VALID");
