# Owner / 平台包第二独立限定审查

## 结论

**FAIL；P0=0，P1=1，P2=0（本次限定范围）。完整 B1 仍 FAIL，不可 close。**

已独立重跑现有 14 个 owner 测试和 9 个包场景，全部通过；但额外畸形 IR 样本发现未捕获 TypeError，说明现有负例仍不充分。

审查者：`/root/protocol_coverage_review`。范围：七方法 IR 验证、原始 wire 保留、生命周期/预算、host-pinned provenance、负面平台 manifest 和 CI 保留失败。未大构建、未改源码；唯一文件写入为本报告。

冻结源 commit：`df54fac836e94db9858ded0692082a5b20d477da`。实际读取时 HEAD 为 `a3121378e618abeb8ea7901d3f4615e8052b89ef`；已核对二者 diff 仅 12 个证据文档/日志，无源码变更。

- owner SHA256：`a4e1ea00391d2d992454de837e1454f28312b4ed764b17d831c23b7dfcadd094`。
- host index SHA256：`900497fd39ae8d0b1aa56b2a33a64a70614e81c22c629567772527c971df733d`。
- expected-provenance SHA256：`5d2a5b20f2643e4b000255e039b3ca17db1a326862f57fbf3943f9812c3d953d`。
- 独立执行镜像 ID：`5aeee04da1b3d986ca08021bdc35d437d7c64acb97a4bae2b90e350f8dc23e6d`。

## P1：原型键导致 IR 校验抛异常而不是 fail closed

位置：`bridge-owner-v2.mjs:195-196`，包中复制件具有相同代码；消费路径 `:525-526`。

`externalVariant` 执行 `variants[key]?.(item)`，没有要求 key 是 variants 自有属性。对 JSON 解析得到的 `{"__proto__":{}}`，取到 Object.prototype（不是函数），发生 `TypeError: variants[key] is not a function`。

独立复现：只读源文本通过 data URL 临时导出原 `validateMethodResult`，未替换其代码，传入：

```js
validateMethodResult('parse_core_review_decision', {
  canonicalWire: '"approved"',
  ir: { schemaVersion: 1, decision: JSON.parse('{"__proto__":{}}') }
})
```

实际结果为 TypeError，不是 false。constructor、toString、valueOf 三个补充键返回 false，但不能消除 __proto__ 的故障。

`#onData` 仅对 validateResponse 使用 try/catch，随后 validateMethodResult 不受异常保护。因此若子进程返回一个信封/关联 ID 合法、decision 含该键的畸形成功响应，异常将逃逸 stdout data 回调；按该代码会崩宿主，而不是终止该 bridge generation、拒绝 pending 并保持宿主存活。

这是畸形 bridge 输出容错缺口，不是声称正常固定 Rust serde 会输出该 variant，也不是授权绕过。直接谓词复现已执行；真实 mock 子进程端到端崩溃测试本次未编写，必须作为修复验收补上。

修复要求：

1. variants 索引前 Object.hasOwn；同时检查对应 handler 为 function，或使用无原型映射。
2. 将整个 method IR 验证置于异常收敛边界，将验证异常转换成 BridgeFailure(protocol) 并清理 generation。
3. 至少对 CoreDecision、V2CommandDecision、Granular 三条 externalVariant 路径补 __proto__/constructor/toString/valueOf 负例。
4. 通过 mock 子进程发送正确 id/session 但畸形 IR，断言宿主仍存活、全部 pending 按协议拒绝、旧子进程停止、无自动重放。

## 其他已核验部分

- IR 按 method 区分完整字段集合、enum、nullable、数组和 i64 十进制范围。上述异常问题之外未在本次源码/样本发现新偏差，但不是完整上游协议覆盖声明。
- exactKeys 限制的是 Bridge 内部输出 IR，不是上游输入 wire；Rust 仍负责输入 unknown-field/alias/default 行为，边界区分正确。
- canonicalWire 只验证为字符串并原样返回；没有 JS JSON.parse 它。这里保证不改写，不等于验证 canonicalWire 与 IR 的全部语义一致。
- additionalPermissionsWire 为字符串或 null，避免嵌套 NonZeroUsize 进入 JS Number；必须维持 raw 使用约束，不可在后续授权消费者中再损失精度。
- 启动等待者在 await 前预留数量/字节；queue/pending 分别计费；取消终止整个 generation，关闭后再检查 session/state，现有对应用例通过。
- 平台包 package.json 和 artifact-manifest 经 readTrustedJson 读取后，与 host 随包固定 EXPECTED 深比较；运行时不是用平台自报的 hash 作为期望。
- artifact 路径防逃逸；全路径 root-owned、非符号链接、运行用户不可写；bridge/launcher 同 FD 校验再执行；同 UID 包和缺平台包 fail closed。

## 独立执行证据

使用现有镜像，不 build：

```text
podman run --pull=never --rm --network=none --read-only
  --tmpfs /tmp:rw,noexec,nosuid,nodev,size=16m
  5aeee04da1b3d986ca08021bdc35d437d7c64acb97a4bae2b90e350f8dc23e6d
```

结果：owner 14/14，0 fail/skip/cancel。包场景全部输出 passed、uid=65532：installed、same-uid、host-only、manifest-extra、manifest-version、manifest-path、manifest-size、manifest-symlink、package-version。负面场景 passed 意味预期拒绝成立，不是平台被允许。

独立运行 `node verify-artifacts.mjs` 返回非零，准确保留：

```text
LICENSE-GATE-FAIL: 12 components lack source-backed license material;
UPSTREAM-DEVELOPMENT-GATE-FAIL: required original development gates remain incomplete
```

组合 `ci-check.sh` 先执行该 gate，之后才 package E2E 和 clean-rebuild；因此当前不会输出 NATIVE-BRIDGE-COMBINED-CI-VALID。未因 runtime 测试通过而放宽许可证或 upstream-development 门禁。本次没有重跑大构建。

## 限定与后续

原 `PROTOCOL-COVERAGE-REVIEW.md` 的完整 B1 缺口不变。修复上述 P1 后需要新冻结源码/hash、重打包和独立复审；不得只修改测试期望、将畸形 IR 异常忽略，或把本报告已有 14+9 通过视为 owner 最终 PASS。
