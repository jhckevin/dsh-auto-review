import { spawn, spawnSync } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import {
  accessSync, closeSync, constants, fstatSync, lstatSync, openSync, readSync, realpathSync,
} from "node:fs";
import { dirname } from "node:path";

const MAX_FRAME_BYTES = 4 * 1024 * 1024;
const MAX_ERROR_BYTES = 4096;
const MAX_KIND_BYTES = 64;
const SESSION = Symbol("bridge-session");
function encodedStringBytes(value, limit) {
  let bytes = 2;
  for (let i = 0; i < value.length; i += 1) {
    const code = value.charCodeAt(i);
    if (code === 34 || code === 92 || [8, 9, 10, 12, 13].includes(code)) bytes += 2;
    else if (code < 32) bytes += 6;
    else if (code < 128) bytes += 1;
    else if (code < 2048) bytes += 2;
    else if (code >= 0xd800 && code <= 0xdbff && i + 1 < value.length
      && value.charCodeAt(i + 1) >= 0xdc00 && value.charCodeAt(i + 1) <= 0xdfff) { bytes += 4; i += 1; }
    else if (code >= 0xd800 && code <= 0xdfff) bytes += 6;
    else bytes += 3;
    if (bytes > limit) return bytes;
  }
  return bytes;
}
const UTF8_DECODER = new TextDecoder("utf-8", { fatal: true });
let singleton;
let singletonSignature;

function waitForChildExit(child, timeoutMs) {
  if (child.exitCode !== null || child.signalCode !== null) return Promise.resolve(true);
  return new Promise(resolve => {
    let timer;
    const finish = exited => {
      clearTimeout(timer);
      child.removeListener("exit", onExit);
      resolve(exited);
    };
    const onExit = () => finish(true);
    child.once("exit", onExit);
    timer = setTimeout(() => finish(false), timeoutMs);
  });
}

export class BridgeFailure extends Error {
  constructor(kind, message) {
    super(message);
    this.name = "BridgeFailure";
    this.kind = kind;
  }
}

function plainObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function exactKeys(value, expected) {
  const keys = Object.keys(value).sort();
  return keys.length === expected.length && keys.every((key, index) => key === expected[index]);
}

function parseVersion(version) {
  const match = /^(\d+)\.(\d+)/u.exec(version ?? "");
  if (!match) return undefined;
  return [Number(match[1]), Number(match[2])];
}

function versionAtLeast(actual, minimum) {
  const a = parseVersion(actual), m = parseVersion(minimum);
  return a !== undefined && m !== undefined && (a[0] > m[0] || (a[0] === m[0] && a[1] >= m[1]));
}

function hashSameFd(fd, first) {
  const hash = createHash("sha256");
  const buffer = Buffer.allocUnsafe(64 * 1024);
  let position = 0;
  while (position < first.size) {
    const count = readSync(fd, buffer, 0, Math.min(buffer.length, first.size - position), position);
    if (count === 0) throw new BridgeFailure("artifact", "artifact truncated during hashing");
    hash.update(buffer.subarray(0, count));
    position += count;
  }
  const second = fstatSync(fd);
  for (const field of ["dev", "ino", "size", "mtimeMs"]) {
    if (second[field] !== first[field]) throw new BridgeFailure("artifact", "artifact changed during hashing");
  }
  return hash.digest("hex");
}

function verifyTrustedPath(path) {
  if (process.geteuid?.() === undefined || process.geteuid() === 0) {
    throw new BridgeFailure("artifact", "bridge host must run as a non-root user");
  }
  if (!path.startsWith("/") || realpathSync(path) !== path) {
    throw new BridgeFailure("artifact", "artifact path must be absolute and canonical");
  }
  let cursor = path;
  for (;;) {
    const stat = lstatSync(cursor);
    if (stat.isSymbolicLink()) throw new BridgeFailure("artifact", "artifact path contains a symlink");
    if (stat.uid !== 0 || (stat.mode & 0o022) !== 0) {
      throw new BridgeFailure("artifact", "artifact trust root is writable or has the wrong owner");
    }
    let writable = false;
    try { accessSync(cursor, constants.W_OK); writable = true; }
    catch (error) { if (error.code !== "EACCES" && error.code !== "EROFS") throw error; }
    if (writable) throw new BridgeFailure("artifact", "artifact trust root is writable by runtime user");
    const parent = dirname(cursor);
    if (parent === cursor) break;
    cursor = parent;
  }
}

function openVerifiedArtifact(spec, requiredUid) {
  verifyTrustedPath(spec.path);
  const resolved = realpathSync(spec.path);
  if (resolved !== spec.realpath) throw new BridgeFailure("artifact", "artifact realpath mismatch");
  let fd;
  try {
    fd = openSync(spec.path, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_CLOEXEC);
    const stat = fstatSync(fd);
    if (!stat.isFile()) throw new BridgeFailure("artifact", "artifact is not a regular file");
    if (stat.uid !== 0) throw new BridgeFailure("artifact", "artifact owner mismatch");
    if (stat.size !== spec.size) throw new BridgeFailure("artifact", "artifact size mismatch");
    if (hashSameFd(fd, stat) !== spec.sha256) throw new BridgeFailure("artifact", "artifact sha256 mismatch");
    return fd;
  } catch (error) {
    if (fd !== undefined) closeSync(fd);
    if (error instanceof BridgeFailure) throw error;
    throw new BridgeFailure("artifact", error.message);
  }
}


export function readTrustedJson(path, maxBytes = 65536) {
  let fd;
  try {
    verifyTrustedPath(path);
    fd = openSync(path, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_CLOEXEC);
    const stat = fstatSync(fd);
    if (!stat.isFile() || stat.uid !== 0 || stat.size > maxBytes || stat.size < 2) {
      throw new BridgeFailure("artifact", "trusted JSON has invalid size, type, or owner");
    }
    const bytes = Buffer.alloc(stat.size + 1);
    let length = 0;
    for (;;) {
      const count = readSync(fd, bytes, length, bytes.length - length, length);
      if (count === 0) break;
      length += count;
      if (length > stat.size) throw new BridgeFailure("artifact", "trusted JSON changed during read");
    }
    const after = fstatSync(fd);
    if (length !== stat.size || after.size !== stat.size || after.mtimeMs !== stat.mtimeMs) {
      throw new BridgeFailure("artifact", "trusted JSON changed during read");
    }
    return JSON.parse(UTF8_DECODER.decode(bytes.subarray(0, length)));
  } catch (error) {
    throw error instanceof BridgeFailure ? error : new BridgeFailure("artifact", "trusted JSON could not be verified");
  } finally { if (fd !== undefined) closeSync(fd); }
}

function validateResponse(line) {
  let response;
  try {
    response = JSON.parse(UTF8_DECODER.decode(line));
  } catch {
    throw new BridgeFailure("protocol", "malformed bridge response");
  }
  if (!plainObject(response) || typeof response.id !== "string" || response.id.length === 0
      || Buffer.byteLength(response.id) > 128 || typeof response.session_id !== "string"
      || response.session_id.length === 0 || Buffer.byteLength(response.session_id) > 256
      || typeof response.ok !== "boolean") {
    throw new BridgeFailure("protocol", "invalid bridge response envelope");
  }
  if (response.ok) {
    if (!exactKeys(response, ["id", "ok", "result", "session_id"]) || !plainObject(response.result)) {
      throw new BridgeFailure("protocol", "invalid successful bridge response");
    }
  } else {
    if (!exactKeys(response, ["error", "id", "ok", "session_id"]) || !plainObject(response.error)
        || !exactKeys(response.error, ["kind", "message"])
        || typeof response.error.kind !== "string" || response.error.kind.length === 0
        || Buffer.byteLength(response.error.kind) > MAX_KIND_BYTES
        || typeof response.error.message !== "string"
        || Buffer.byteLength(response.error.message) > MAX_ERROR_BYTES) {
      throw new BridgeFailure("protocol", "invalid bridge error response");
    }
  }
  return response;
}


const textValue = value => typeof value === "string";
const nullable = check => value => value === null || check(value);
const arrayOf = check => value => Array.isArray(value) && value.every(check);
const oneOf = values => value => values.includes(value);
const shape = (value, fields) => plainObject(value)
  && exactKeys(value, Object.keys(fields).sort())
  && Object.entries(fields).every(([key, check]) => check(value[key]));
const i64Decimal = value => textValue(value) && /^(0|-[1-9][0-9]*|[1-9][0-9]*)$/u.test(value)
  && value.length <= 20 && BigInt(value) >= -(1n << 63n) && BigInt(value) < (1n << 63n);
const networkAmendment = value => shape(value, {host: textValue, action: oneOf(["allow", "deny"])});
const networkContext = value => shape(value, {host: textValue, protocol: oneOf(["http", "https", "socks5_tcp", "socks5_udp"])});
const parsedCommand = value => shape(value, {type: oneOf(["read"]), cmd: textValue, name: textValue, path: textValue})
  || shape(value, {type: oneOf(["list_files"]), cmd: textValue, path: nullable(textValue)})
  || shape(value, {type: oneOf(["search"]), cmd: textValue, query: nullable(textValue), path: nullable(textValue)})
  || shape(value, {type: oneOf(["unknown"]), cmd: textValue});
const externalVariant = (value, variants) => plainObject(value) && Object.keys(value).length === 1
  && Object.entries(value).every(([key, item]) => Object.hasOwn(variants, key)
    && typeof variants[key] === "function" && variants[key](item) === true);
const coreDecision = value => oneOf(["approved", "approved_for_session", "approved_mcp_policy_amendment", "timed_out", "abort"])(value)
  || externalVariant(value, {
    denied: v => shape(v, {rejection: textValue}),
    approved_execpolicy_amendment: v => shape(v, {proposed_execpolicy_amendment: arrayOf(textValue)}),
    network_policy_amendment: v => shape(v, {network_policy_amendment: networkAmendment}),
  });
const fileDecision = oneOf(["accept", "acceptForSession", "decline", "cancel"]);
const commandDecision = value => fileDecision(value) || externalVariant(value, {
  acceptWithExecpolicyAmendment: v => shape(v, {execpolicy_amendment: arrayOf(textValue)}),
  applyNetworkPolicyAmendment: v => shape(v, {network_policy_amendment: networkAmendment}),
});
const fileChange = value => shape(value, {type: oneOf(["add", "delete"]), content: textValue})
  || shape(value, {type: oneOf(["update"]), unified_diff: textValue, move_path: nullable(textValue)});

// This validates the bridge envelope/IR, not upstream input serde: wire parsing remains Rust-owned.
function validateMethodResult(method, result) {
  if (method === "handshake") return shape(result, {
    protocol: v => v === 2, upstreamCommit: v => /^[0-9a-f]{40}$/u.test(v),
    bridgePatchSha256: v => /^[0-9a-f]{64}$/u.test(v), irVersion: v => v === 1,
    os: v => v === "linux", arch: v => v === "x86_64",
    hardening: v => shape(v, {noNewPrivileges: x => x === true, network: x => x === "seccomp-deny",
      filesystem: x => x === "seccomp-deny-open-plus-launcher", rlimits: x => x === true}),
  });
  if (!shape(result, {canonicalWire: textValue, ir: plainObject}) || result.ir.schemaVersion !== 1) return false;
  const common = {schemaVersion: v => v === 1};
  switch (method) {
    case "parse_core_exec": return shape(result.ir, {...common,
      kind: oneOf(["command", "write_stdin"]), callId: textValue, pluginId: nullable(textValue),
      scriptPath: nullable(textValue), approvalId: nullable(textValue), turnId: textValue,
      environmentId: nullable(textValue), startedAtMs: i64Decimal, command: arrayOf(textValue),
      cwd: textValue, reason: nullable(textValue), networkApprovalContext: nullable(networkContext),
      proposedExecpolicyAmendment: nullable(arrayOf(textValue)),
      proposedNetworkPolicyAmendments: nullable(arrayOf(networkAmendment)),
      additionalPermissionsWire: nullable(textValue), availableDecisions: nullable(arrayOf(coreDecision)),
      parsedCmd: arrayOf(parsedCommand), effectiveApprovalId: textValue});
    case "parse_core_apply_patch": return shape(result.ir, {...common,
      callId: textValue, turnId: textValue, startedAtMs: i64Decimal,
      changes: v => plainObject(v) && Object.values(v).every(fileChange),
      reason: nullable(textValue), grantRoot: nullable(textValue)});
    case "parse_core_review_decision": return shape(result.ir, {...common, decision: coreDecision});
    case "parse_core_ask_for_approval": return shape(result.ir, {...common, policy: v =>
      oneOf(["untrusted", "on-request", "never"])(v) || externalVariant(v, {granular: g => shape(g, {
        sandbox_approval: x => typeof x === "boolean", rules: x => typeof x === "boolean",
        mcp_elicitations: x => typeof x === "boolean", skill_approval: x => typeof x === "boolean",
        request_permissions: x => typeof x === "boolean"})})});
    case "parse_core_approvals_reviewer": return shape(result.ir, {...common, reviewer: oneOf(["user", "auto_review"])});
    case "parse_v2_command_response": return shape(result.ir, {...common, decision: commandDecision});
    case "parse_v2_file_response": return shape(result.ir, {...common, decision: fileDecision});
    default: return false;
  }
}

class NativeBridgeHost {
  #options;
  #state = "idle";
  #child;
  #buffer = Buffer.alloc(0);
  #pending = new Map();
  #queue = [];
  #sessions = new Set();
  #starting;
  #closing;
  #generation = 0;
  #failures = 0;
  #nextStartAt = 0;
  #pendingBytes = 0;
  #queueBytes = 0;
  #writeBlocked = false;
  #stderrBytes = 0;
  #lastFailure;
  #admittedCount = 0;
  #admittedBytes = 0;

  constructor(options) {
    this.#options = options;
    const glibc = process.report?.getReport()?.header?.glibcVersionRuntime;
    if (!versionAtLeast(glibc, options.minimumGlibc)) {
      throw new BridgeFailure("abi", `glibc ${options.minimumGlibc}+ is required`);
    }
  }

  get generation() { return this.#generation; }
  get pid() { return this.#child?.pid; }
  get state() { return this.#state; }

  #isCurrent(child, generation) {
    return child !== undefined && this.#child === child && this.#generation === generation;
  }

  createSession() {
    if (this.#state === "closed" || this.#state === "closing") throw new BridgeFailure("closed", "bridge host closed");
    const handle = Object.freeze({ [SESSION]: randomUUID() });
    this.#sessions.add(handle);
    return handle;
  }

  async closeSession(handle) {
    this.#requireSession(handle);
    this.#sessions.delete(handle);
    if ([...this.#pending.values()].some(item => item.handle === handle)
        || this.#queue.some(item => item.handle === handle)) {
      this.#restart(new BridgeFailure("session_closed", "session closed with pending bridge work"));
    }
  }

  async request(handle, method, wire, { signal } = {}) {
    this.#requireSession(handle);
    if (typeof method !== "string" || method.length === 0 || Buffer.byteLength(method) > 128
        || (wire !== undefined && typeof wire !== "string")) {
      throw new BridgeFailure("invalid_request", "method and raw wire must be strings");
    }
    if (wire !== undefined && Buffer.byteLength(wire) > MAX_FRAME_BYTES) {
      throw new BridgeFailure("resource_limit", "raw wire exceeds 4 MiB before serialization");
    }
    if (signal?.aborted) throw new BridgeFailure("cancelled", "bridge request cancelled");
    // Reserve before any await: startup waiters are part of the bounded population.
    // 512 includes maximum correlation/session IDs, envelope keys, and punctuation.
    const admissionBytes = 512 + encodedStringBytes(method, MAX_FRAME_BYTES)
      + (wire === undefined ? 0 : encodedStringBytes(wire, MAX_FRAME_BYTES));
    if (admissionBytes > MAX_FRAME_BYTES) throw new BridgeFailure("resource_limit", "escaped wire exceeds frame budget");
    if (this.#admittedCount >= this.#options.maxInflight + this.#options.maxQueue
      || this.#admittedBytes + admissionBytes > this.#options.maxInflightBytes + this.#options.maxQueueBytes) {
      throw new BridgeFailure("backpressure", "bridge admission budget exceeded before startup");
    }
    this.#admittedCount += 1; this.#admittedBytes += admissionBytes;
    try { return await this.#requestAdmitted(handle, method, wire, signal); }
    finally { this.#admittedCount -= 1; this.#admittedBytes -= admissionBytes; }
  }

  async #requestAdmitted(handle, method, wire, signal) {
    await this.#start();
    if (this.#state === "closed" || this.#state === "closing") {
      throw new BridgeFailure("closed", "bridge host closed while request was starting");
    }
    this.#requireSession(handle);
    if (signal?.aborted) {
      const failure = new BridgeFailure("cancelled", "one request was cancelled; the bridge generation was terminated");
      this.#restart(failure);
      throw failure;
    }
    const id = this.#mintId();
    const envelope = { id, session_id: handle[SESSION], method };
    if (wire !== undefined) envelope.wire = wire;
    let bytes;
    try {
      bytes = Buffer.from(JSON.stringify(envelope) + "\n", "utf8");
    } catch (error) {
      throw new BridgeFailure("invalid_request", error.message);
    }
    if (bytes.length > MAX_FRAME_BYTES) throw new BridgeFailure("resource_limit", "request exceeds 4 MiB");
    // A request that can never fit inflight must not enter the queue, even while busy.
    if (bytes.length > this.#options.maxInflightBytes) {
      throw new BridgeFailure("backpressure", "single bridge request exceeds inflight byte budget");
    }
    const item = { id, handle, bytes, signal, method };
    if (this.#pending.size >= this.#options.maxInflight || this.#writeBlocked) {
      if (this.#queue.length >= this.#options.maxQueue
          || this.#queueBytes + bytes.length > this.#options.maxQueueBytes) {
        throw new BridgeFailure("backpressure", "bridge queue budget exceeded");
      }
      this.#queueBytes += bytes.length;
      return new Promise((resolve, reject) => {
        Object.assign(item, { resolve, reject });
        const child = this.#child, generation = this.#generation;
        item.queueDeadline = performance.now() + this.#options.queueTimeoutMs;
        item.queueTimer = setTimeout(() => {
          if (!this.#isCurrent(child, generation) || !this.#queue.includes(item)) return;
          this.#expireQueued(item);
          this.#drain();
        }, this.#options.queueTimeoutMs);
        this.#queue.push(item);
        this.#attachAbort(item);
      });
    }
    if (this.#pendingBytes + bytes.length > this.#options.maxInflightBytes) {
      throw new BridgeFailure("backpressure", "bridge inflight byte budget exceeded");
    }
    return new Promise((resolve, reject) => {
      Object.assign(item, { resolve, reject });
      this.#send(item);
    });
  }

  close() {
    this.#closing ??= this.#close();
    return this.#closing;
  }

  async #close() {
    this.#state = "closing";
    this.#failAll(new BridgeFailure("closed", "bridge host closed"));
    const child = this.#child;
    this.#child = undefined;
    try {
      if (child) {
        child.stdin.end();
        if (!await waitForChildExit(child, this.#options.shutdownMs)) {
          child.kill("SIGKILL");
          if (!await waitForChildExit(child, this.#options.shutdownMs)) {
            throw new BridgeFailure("shutdown_timeout", "bridge child did not exit after forced shutdown");
          }
        }
      }
    } finally {
      this.#sessions.clear();
      this.#state = "closed";
    }
  }

  #requireSession(handle) {
    if (!plainObject(handle) || !this.#sessions.has(handle)) {
      throw new BridgeFailure("session", "unknown bridge session handle");
    }
  }

  #mintId() {
    for (let attempt = 0; attempt < 16; attempt += 1) {
      const id = this.#options.idFactory();
      if (typeof id === "string" && id.length > 0 && Buffer.byteLength(id) <= 128
          && !this.#pending.has(id) && !this.#queue.some(item => item.id === id)) return id;
    }
    throw new BridgeFailure("id_collision", "unable to mint unique bridge request id");
  }

  async #start() {
    if (this.#state === "closed" || this.#state === "closing") throw new BridgeFailure("closed", "bridge host closed");
    if (this.#starting) return this.#starting;
    if (this.#child && this.#state === "running") return;
    this.#starting = this.#spawnAndHandshake();
    try { await this.#starting; } finally { this.#starting = undefined; }
  }

  async #spawnAndHandshake() {
    const delay = Math.max(0, this.#nextStartAt - Date.now());
    if (delay > 0) await new Promise(resolve => setTimeout(resolve, delay));
    if (this.#state === "closed" || this.#state === "closing") {
      throw new BridgeFailure("closed", "bridge host closed during restart backoff");
    }
    const startGeneration = this.#generation;
    let launcherFd, bridgeFd, child, generation;
    try {
      launcherFd = openVerifiedArtifact(this.#options.launcher, this.#options.artifactOwnerUid);
      bridgeFd = openVerifiedArtifact(this.#options.bridge, this.#options.artifactOwnerUid);
      const probe = spawnSync("/proc/self/fd/3", ["--probe"], {
        stdio: ["ignore", "pipe", "pipe", launcherFd],
        env: { PATH: "/usr/bin:/bin", LANG: "C.UTF-8" },
        timeout: this.#options.probeMs,
        encoding: "utf8",
      });
      if (probe.status !== 0 || !/^landlock: (fully|partially) enforced/u.test(probe.stdout)) {
        throw new BridgeFailure("sandbox", "DSH Landlock launcher is unavailable");
      }
      child = spawn("/proc/self/fd/3", [
        "--ro", "/", "--rw", "/dev/null", "--", "/proc/self/fd/4",
      ], {
        stdio: ["pipe", "pipe", "pipe", launcherFd, bridgeFd],
        env: { PATH: "/usr/bin:/bin", LANG: "C.UTF-8" },
      });
      closeSync(launcherFd); launcherFd = undefined;
      closeSync(bridgeFd); bridgeFd = undefined;
      this.#child = child;
      this.#generation += 1;
      generation = this.#generation;
      this.#state = "starting";
      this.#buffer = Buffer.alloc(0);
      this.#stderrBytes = 0;
      child.stdout.on("data", chunk => this.#onData(child, generation, chunk));
      child.stderr.on("data", chunk => {
        if (!this.#isCurrent(child, generation)) return;
        this.#stderrBytes += chunk.length;
        if (this.#stderrBytes > this.#options.maxStderrBytes) this.#restart(new BridgeFailure("protocol", "bridge stderr exceeded cap"));
      });
      child.stdin.on("drain", () => {
        if (!this.#isCurrent(child, generation)) return;
        this.#writeBlocked = false; this.#drain();
      });
      child.stdin.on("error", error => this.#onExit(child, generation, new BridgeFailure("write", error.message)));
      child.on("error", error => this.#onExit(child, generation, new BridgeFailure("spawn", error.message)));
      child.on("exit", (code, signal) => this.#onExit(child, generation,
        new BridgeFailure("crash", `bridge exited code=${code} signal=${signal}`)));
      const bootstrap = Object.freeze({ [SESSION]: "__bridge_owner__" });
      this.#sessions.add(bootstrap);
      let result;
      try { result = await this.#requestBootstrap(bootstrap); } finally { this.#sessions.delete(bootstrap); }
      if (!this.#isCurrent(child, generation) || this.#state === "closed" || this.#state === "closing") {
        throw new BridgeFailure("closed", "bridge generation closed during handshake");
      }
      for (const [key, value] of Object.entries(this.#options.expectedHandshake)) {
        if (JSON.stringify(result?.[key]) !== JSON.stringify(value)) {
          throw new BridgeFailure("handshake", `handshake mismatch for ${key}`);
        }
      }
      this.#failures = 0;
      this.#lastFailure = undefined;
      this.#state = "running";
    } catch (error) {
      if (launcherFd !== undefined) closeSync(launcherFd);
      if (bridgeFd !== undefined) closeSync(bridgeFd);
      const failure = error instanceof BridgeFailure ? error : new BridgeFailure("spawn", error.message);
      // A late startup failure must not reset an already retired or replacement generation.
      if (child ? this.#isCurrent(child, generation) : this.#generation === startGeneration && !this.#child) {
        this.#restart(failure);
      }
      throw failure;
    }
  }

  #requestBootstrap(handle) {
    const id = this.#mintId();
    const bytes = Buffer.from(JSON.stringify({ id, session_id: handle[SESSION], method: "handshake" }) + "\n");
    return new Promise((resolve, reject) => this.#send({ id, handle, bytes, resolve, reject, method: "handshake" }));
  }

  #send(item) {
    const child = this.#child, generation = this.#generation;
    if (!child) {
      item.reject(this.#lastFailure ?? new BridgeFailure("unavailable", "bridge is not running"));
      return;
    }
    this.#pendingBytes += item.bytes.length;
    const timer = setTimeout(() => {
      if (this.#isCurrent(child, generation) && this.#pending.get(item.id) === item) {
        this.#restart(new BridgeFailure("timeout", "bridge request timed out"));
      }
    }, this.#options.timeoutMs);
    Object.assign(item, { timer });
    this.#pending.set(item.id, item);
    this.#attachAbort(item);
    if (!this.#isCurrent(child, generation) || this.#pending.get(item.id) !== item) return;
    try {
      const accepted = child.stdin.write(item.bytes, error => {
        if (error && this.#isCurrent(child, generation)) this.#restart(new BridgeFailure("write", error.message));
      });
      if (this.#isCurrent(child, generation)) this.#writeBlocked = !accepted;
    } catch (error) {
      if (this.#isCurrent(child, generation)) this.#restart(new BridgeFailure("write", error.message));
    }
  }

  #attachAbort(item) {
    if (!item.signal) return;
    const child = this.#child, generation = this.#generation;
    item.onAbort = () => {
      if (this.#isCurrent(child, generation)
          && (this.#pending.get(item.id) === item || this.#queue.includes(item))) {
        this.#restart(new BridgeFailure("cancelled", "one request was cancelled; the bridge generation was terminated"));
      }
    };
    item.signal.addEventListener("abort", item.onAbort, { once: true });
    if (item.signal.aborted) item.onAbort();
  }

  #detachAbort(item) {
    if (item.signal && item.onAbort) item.signal.removeEventListener("abort", item.onAbort);
  }

  #onData(child, generation, chunk) {
    if (!this.#isCurrent(child, generation)) return;
    let start = 0;
    for (;;) {
      if (!this.#isCurrent(child, generation)) return;
      const newline = chunk.indexOf(0x0a, start);
      const fragment = chunk.subarray(start, newline < 0 ? chunk.length : newline);
      if (this.#buffer.length + fragment.length > this.#options.maxResponseFrameBytes) {
        this.#restart(new BridgeFailure("protocol", "bridge response frame exceeds byte cap")); return;
      }
      const line = this.#buffer.length === 0 ? Buffer.from(fragment) : Buffer.concat([this.#buffer, fragment]);
      if (newline < 0) { this.#buffer = line; break; }
      this.#buffer = Buffer.alloc(0);
      start = newline + 1;
      let response;
      try { response = validateResponse(line); }
      catch (error) { this.#restart(error); return; }
      const item = this.#pending.get(response.id);
      if (!item || response.session_id !== item.handle[SESSION]) {
        this.#restart(new BridgeFailure("protocol", "unknown, duplicate, late, or cross-session response")); return;
      }
      try {
        if (response.ok && !validateMethodResult(item.method, response.result)) {
          throw new BridgeFailure("protocol", "bridge result violates method IR schema");
        }
      } catch {
        // Validation failures, including unexpected validator exceptions, never escape stdout callbacks.
        this.#restart(new BridgeFailure("protocol", "bridge result violates method IR schema")); return;
      }
      this.#pending.delete(response.id);
      this.#pendingBytes -= item.bytes.length;
      clearTimeout(item.timer);
      this.#detachAbort(item);
      if (response.ok) item.resolve(response.result);
      else item.reject(new BridgeFailure(response.error.kind, response.error.message));
      this.#drain();
    }
  }

  #drain() {
    while (this.#child && !this.#writeBlocked && this.#pending.size < this.#options.maxInflight && this.#queue.length) {
      const item = this.#queue[0];
      if (performance.now() >= item.queueDeadline) { this.#expireQueued(item); continue; }
      if (this.#pendingBytes + item.bytes.length > this.#options.maxInflightBytes) return;
      this.#queue.shift();
      this.#queueBytes -= item.bytes.length;
      clearTimeout(item.queueTimer);
      this.#detachAbort(item);
      this.#send(item);
    }
  }

  #expireQueued(item) {
    const index = this.#queue.indexOf(item);
    if (index < 0) return; // Already sent, closed, or cancelled: never settle or replay twice.
    this.#queue.splice(index, 1);
    this.#queueBytes -= item.bytes.length;
    clearTimeout(item.queueTimer);
    this.#detachAbort(item);
    item.reject(new BridgeFailure("queue_timeout", "bridge request expired before dispatch"));
  }

  #onExit(child, generation, error) {
    if (!this.#isCurrent(child, generation)) return;
    this.#child = undefined;
    if (this.#state === "closing" || this.#state === "closed") return;
    this.#failures += 1;
    this.#nextStartAt = Date.now() + Math.min(this.#options.maxBackoffMs,
      this.#options.baseBackoffMs * (2 ** Math.min(this.#failures - 1, 8)));
    this.#state = "backoff";
    this.#lastFailure = error;
    this.#failAll(error);
  }

  #restart(error) {
    const child = this.#child;
    this.#child = undefined;
    if (this.#state !== "closing" && this.#state !== "closed") {
      this.#failures += 1;
      this.#nextStartAt = Date.now() + Math.min(this.#options.maxBackoffMs,
        this.#options.baseBackoffMs * (2 ** Math.min(this.#failures - 1, 8)));
      this.#state = "backoff";
    }
    this.#lastFailure = error;
    this.#failAll(error);
    child?.kill("SIGKILL");
  }

  #failAll(error) {
    for (const item of this.#pending.values()) {
      clearTimeout(item.timer); this.#detachAbort(item); item.reject(error);
    }
    for (const item of this.#queue) { clearTimeout(item.queueTimer); this.#detachAbort(item); item.reject(error); }
    this.#pending.clear(); this.#queue = [];
    this.#pendingBytes = 0; this.#queueBytes = 0; this.#writeBlocked = false;
  }
}

function normalizedOptions(options) {
  if (options.artifactOwnerUid !== undefined && options.artifactOwnerUid !== 0) {
    throw new BridgeFailure("artifact", "artifact owner must be root; same-UID install is unsupported");
  }
  const normalized = {
    ...options,
    minimumGlibc: options.minimumGlibc ?? "2.31",
    artifactOwnerUid: options.artifactOwnerUid ?? 0,
    timeoutMs: options.timeoutMs ?? 1000,
    // Queue waiting and actual execution have independent deadlines; startup is separately bounded.
    queueTimeoutMs: options.queueTimeoutMs ?? options.timeoutMs ?? 1000,
    shutdownMs: options.shutdownMs ?? 250,
    probeMs: options.probeMs ?? 2000,
    maxInflight: options.maxInflight ?? 8,
    maxQueue: options.maxQueue ?? 32,
    maxInflightBytes: options.maxInflightBytes ?? 8 * 1024 * 1024,
    maxQueueBytes: options.maxQueueBytes ?? 8 * 1024 * 1024,
    maxResponseFrameBytes: options.maxResponseFrameBytes ?? MAX_FRAME_BYTES,
    maxStderrBytes: options.maxStderrBytes ?? 16 * 1024,
    baseBackoffMs: options.baseBackoffMs ?? 25,
    maxBackoffMs: options.maxBackoffMs ?? 1000,
    idFactory: options.idFactory ?? randomUUID,
  };
  const integer = (name, minimum, maximum = Number.MAX_SAFE_INTEGER) => {
    const value = normalized[name];
    if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
      throw new BridgeFailure("configuration", `${name} must be an integer in ${minimum}..${maximum}`);
    }
  };
  for (const name of ["timeoutMs", "queueTimeoutMs", "shutdownMs", "probeMs"]) integer(name, 1, 2147483647);
  for (const name of ["baseBackoffMs", "maxBackoffMs"]) integer(name, 0, 2147483647);
  for (const name of ["maxInflight", "maxInflightBytes", "maxResponseFrameBytes", "maxStderrBytes"]) integer(name, 1);
  for (const name of ["maxQueue", "maxQueueBytes"]) integer(name, 0);
  if (normalized.maxBackoffMs < normalized.baseBackoffMs
      || !Number.isSafeInteger(normalized.maxInflight + normalized.maxQueue)
      || !Number.isSafeInteger(normalized.maxInflightBytes + normalized.maxQueueBytes)) {
    throw new BridgeFailure("configuration", "invalid backoff order or overflowing aggregate budget");
  }
  return normalized;
}

function signature(options) {
  return JSON.stringify({
    bridge: options.bridge,
    launcher: options.launcher,
    expectedHandshake: options.expectedHandshake,
    minimumGlibc: options.minimumGlibc,
    artifactOwnerUid: options.artifactOwnerUid,
  });
}

/** Independent owner for one application/plugin scope; close never affects peers. */
export function createHostBridge(options) {
  return new NativeBridgeHost(normalizedOptions(options));
}

export function acquireHostBridge(options) {
  const normalized = normalizedOptions(options);
  const nextSignature = signature(normalized);
  if (singleton) {
    if (nextSignature !== singletonSignature) {
      throw new BridgeFailure("version_isolation", "a different bridge version is already registered");
    }
    return singleton;
  }
  singleton = new NativeBridgeHost(normalized);
  singletonSignature = nextSignature;
  return singleton;
}

export async function closeHostBridgeForTests() {
  if (singleton) await singleton.close();
  singleton = undefined;
  singletonSignature = undefined;
}
