#!/bin/sh
echo "Historical rc1/1.96 entry: does not validate rc2. See RC2-REPRODUCIBILITY.md." >&2
exit 2
set -eu
cd "$(dirname "$0")"
export PATH=/srv/pi-lab-dev/toolchains/node-v24.8.0-linux-x64/bin:$PATH
cp bridge-owner-v2.mjs packages/host/bridge-owner.mjs
node pin-provenance.mjs --check
npm pack ./packages/host --pack-destination dist --ignore-scripts
npm pack ./packages/platform --pack-destination dist --ignore-scripts
podman build --pull=never --network=none -f Containerfile.package-e2e -t localhost/auto-review-bridge-package-e2e:staging . > package-e2e-build.log 2>&1
podman run --pull=never --rm --network=none --read-only --tmpfs /tmp:rw,noexec,nosuid,nodev,size=16m localhost/auto-review-bridge-package-e2e:staging > package-e2e.log 2>&1
