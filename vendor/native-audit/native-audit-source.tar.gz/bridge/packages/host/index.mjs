import { createRequire } from "node:module";
import { dirname, join, relative, isAbsolute } from "node:path";
import { isDeepStrictEqual } from "node:util";
import { realpathSync } from "node:fs";
import { acquireHostBridge, createHostBridge, BridgeFailure, readTrustedJson } from "./bridge-owner.mjs";
import EXPECTED from "./expected-provenance.json" with { type: "json" };
const require = createRequire(import.meta.url);

function artifact(root, spec) {
  const path = join(root, spec.path), rel = relative(root, path);
  if (isAbsolute(spec.path) || rel === ".." || rel.startsWith("../") || isAbsolute(rel)) {
    throw new BridgeFailure("artifact", "artifact path escapes platform package");
  }
  return {path, realpath: path, size: spec.size, sha256: spec.sha256};
}

function trustedBridgeOptions() {
  if (process.platform !== "linux" || process.arch !== "x64") {
    throw new BridgeFailure("platform", "approval bridge requires linux-x64-gnu");
  }
  let packageJson;
  const protectedRuntime = process.env.DSH_AUTO_REVIEW_NATIVE_RUNTIME;
  if (protectedRuntime !== undefined) {
    try {
      if (!isAbsolute(protectedRuntime) || realpathSync(protectedRuntime) !== protectedRuntime) throw new Error();
      packageJson = join(protectedRuntime, "package.json");
    } catch { throw new BridgeFailure("artifact", "protected runtime must be an existing absolute canonical platform package directory"); }
  } else {
    try { packageJson = require.resolve("@jhckevin/dsh-auto-review-bridge-linux-x64-gnu/package.json"); }
    catch { throw new BridgeFailure("artifact", "required linux-x64-gnu bridge package is unavailable"); }
  }
  const root = dirname(packageJson);
  const metadata = readTrustedJson(packageJson, 16384);
  const manifest = readTrustedJson(join(root, "artifact-manifest.json"), 65536);
  if (!isDeepStrictEqual(metadata, EXPECTED.package) || !isDeepStrictEqual(manifest, EXPECTED.manifest)) {
    throw new BridgeFailure("artifact", "platform manifest or package differs from host-pinned provenance");
  }
  return {
    bridge: artifact(root, EXPECTED.manifest.bridge), launcher: artifact(root, EXPECTED.manifest.launcher),
    minimumGlibc: EXPECTED.manifest.minimumGlibc,
    expectedHandshake: {protocol: 2, upstreamCommit: EXPECTED.manifest.upstreamCommit,
      bridgePatchSha256: EXPECTED.manifest.patchSha256, irVersion: 1, os: "linux", arch: "x86_64"},
  };
}
/** Fresh scoped owner. await close() drains/rejects work and observes child exit. */
export function createCodexApprovalBridge() { return createHostBridge(trustedBridgeOptions()); }
/** Legacy process-wide owner retained for consumers that have not migrated. */
export function acquireCodexApprovalBridge() { return acquireHostBridge(trustedBridgeOptions()); }
export { BridgeFailure };
