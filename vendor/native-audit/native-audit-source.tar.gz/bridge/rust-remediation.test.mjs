import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('.', import.meta.url));
const binary = process.env.BRIDGE_REMEDIATION_BINARY ?? `${root}codex-approval-protocol-bridge-v2.remediated-gnu2.31`;

async function run(requests) {
  const child = spawn(`${root}landlock-run.linux-x64`, ['--ro', '/', '--rw', '/dev/null', '--', binary], {
    stdio: ['pipe', 'pipe', 'pipe'],
  });
  const stdout = [], stderr = [];
  let bytes = 0;
  const timeout = setTimeout(() => child.kill('SIGKILL'), 10000);
  child.stdout.on('data', chunk => {
    bytes += chunk.length;
    if (bytes > 8 * 1024 * 1024) child.kill('SIGKILL');
    else stdout.push(chunk);
  });
  child.stderr.on('data', chunk => stderr.push(chunk));
  const done = new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('close', (code, signal) => resolve({ code, signal }));
  });
  child.stdin.on('error', () => {});
  child.stdin.end(requests.map((request, index) => JSON.stringify({ id: `r${index}`, session_id: 'rust-test', ...request })).join('\n') + '\n');
  try {
    const exit = await done;
    assert.equal(exit.code, 0, Buffer.concat(stderr).toString());
    assert.equal(exit.signal, null);
    const responses = Buffer.concat(stdout).toString('utf8').trim().split('\n').map(JSON.parse);
    assert.equal(responses.length, requests.length);
    responses.forEach((response, index) => {
      assert.equal(response.id, `r${index}`);
      assert.equal(response.session_id, 'rust-test');
    });
    return responses;
  } finally {
    clearTimeout(timeout);
    if (child.exitCode === null) child.kill('SIGKILL');
  }
}

test('long Unicode serde errors stay bounded and do not kill the shared process', async () => {
  const requests = [];
  for (const prefix of ['', 'x', 'xx', 'xxx']) {
    for (const char of ['中', 'é', '😀']) {
      requests.push({ method: 'parse_core_review_decision', wire: JSON.stringify(prefix + char.repeat(5000)) });
    }
  }
  requests.push({ method: 'parse_core_review_decision', wire: '"approved"' });
  const responses = await run(requests);
  for (const response of responses.slice(0, -1)) {
    assert.equal(response.ok, false);
    assert.equal(response.error.kind, 'serde');
    assert.ok(Buffer.byteLength(response.error.message) <= 4096);
    assert.equal(response.error.message.includes('\uFFFD'), false);
  }
  assert.equal(responses.at(-1).result.ir.decision, 'approved');
});

test('handshake requires successful network/filesystem/indirect-syscall probes', async () => {
  const [response] = await run([{ method: 'handshake' }]);
  assert.equal(response.ok, true);
  assert.equal(response.result.protocol, 2);
  assert.equal(response.result.bridgePatchSha256, createHash('sha256').update(readFileSync(`${root}codex-bridge-v2.patch`)).digest('hex'));
  assert.equal(response.result.hardening.noNewPrivileges, true);
  assert.equal(response.result.hardening.network, 'seccomp-deny');
  assert.equal(response.result.hardening.filesystem, 'seccomp-deny-open-plus-launcher');
});

test('raw i64 numeric tokens are not rounded by JavaScript before Rust serde', async () => {
  const values = ['-9223372036854775808', '9223372036854775807', '-9007199254740993', '9007199254740993', '0'];
  const wire = value => `{"call_id":"call","command":[],"cwd":"/work","parsed_cmd":[],"started_at_ms":${value}}`;
  const responses = await run(values.map(value => ({ method: 'parse_core_exec', wire: wire(value) })));
  responses.forEach((response, i) => {
    assert.equal(response.ok, true);
    const expected = values[i];
    assert.equal(response.result.ir.startedAtMs, expected);
    assert.ok(response.result.canonicalWire.includes(`"started_at_ms":${expected}`));
  });
  // Pinned serde_json treats raw -0 as a float, not an i64. Do not normalize
  // it in JavaScript; Value-based tests would erase this wire distinction.
  for (const value of ['9223372036854775808', '-9223372036854775809', '1e0', '1.0', '-0', 'null']) {
    const [response] = await run([{ method: 'parse_core_exec', wire: wire(value) }]);
    assert.equal(response.ok, false, value);
    assert.equal(response.error.kind, 'serde');
  }
});

test('upstream known-field duplicates reject while unknown fields remain ignored', async () => {
  const base = '"call_id":"call","command":[],"cwd":"/work","parsed_cmd":[],"started_at_ms":1';
  const [unknown, duplicate, alias] = await run([
    { method: 'parse_core_exec', wire: `{${base},"future_field":{"deep":true}}` },
    { method: 'parse_core_exec', wire: `{${base},"call_id":"second"}` },
    { method: 'parse_core_exec', wire: `{${base},"environmentId":"a","environment_id":"b"}` },
  ]);
  assert.equal(unknown.ok, true);
  assert.equal(duplicate.ok, false);
  assert.equal(alias.ok, false);
});

test('oversized serialized response is a correlated resource error, not process death', async () => {
  const wire = JSON.stringify({
    call_id: 'call', command: [], cwd: '/work', parsed_cmd: [], started_at_ms: 1,
    reason: 'x'.repeat(2300000),
  });
  const [limited, next] = await run([
    { method: 'parse_core_exec', wire },
    { method: 'parse_core_review_decision', wire: '"approved"' },
  ]);
  assert.equal(limited.ok, false);
  assert.equal(limited.error.kind, 'resource_limit');
  assert.equal(next.ok, true);
  assert.equal(next.result.ir.decision, 'approved');
});

test('nested x64 NonZeroUsize permissions remain opaque lossless wire', async () => {
  const wire = '{"call_id":"c","command":[],"cwd":"/work","parsed_cmd":[],"started_at_ms":1,"additional_permissions":{"network":null,"file_system":{"entries":[],"glob_scan_max_depth":18446744073709551615}}}';
  const [response] = await run([{ method: 'parse_core_exec', wire }]);
  assert.equal(response.ok, true);
  assert.equal(typeof response.result.ir.additionalPermissionsWire, 'string');
  assert.equal(Object.hasOwn(response.result.ir, 'additionalPermissions'), false);
  assert.ok(response.result.ir.additionalPermissionsWire.includes('"glob_scan_max_depth":18446744073709551615'));
  assert.ok(response.result.canonicalWire.includes('"glob_scan_max_depth":18446744073709551615'));
});
