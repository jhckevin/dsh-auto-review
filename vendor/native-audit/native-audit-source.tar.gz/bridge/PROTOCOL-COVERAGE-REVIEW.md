# ISSUE-022B B1 原生 Bridge 协议覆盖独立审查

## 结论与范围

**FAIL：不能验收为 B1 完整实现，更不能宣称完整 Auto Review 100% 迁移。**

- 独立审查者：`/root/protocol_coverage_review`。
- 固定公开 Codex commit：`9f97cb79eb15b38d24c552c56fe24e211ff9cf3a`。
- 审查目标 HEAD：`da79c3cd4285f20e857b6839e0515a60cfd62ae0`。
- 目标工作区：`/srv/pi-lab-dev/worktrees/dsh-auto-review-native`。
- 审查时目标仅有冻结的未提交 `src/codex-parity/approval-protocol.ts` 草稿；旧已提交实现使用 `git show HEAD:<path>` 区分。
- 本报告审查的旧 Rust patch SHA256：`6d44f0519319f2f1a1c19d61e8c5fcdcc3c2136d916d0089175db34fa0f2d23f`，文件 `codex-bridge-v2.patch`。该 patch 正由实现者继续修改；以下结论不是对后续 patch 的复核。
- 原始代码通过 `git show <固定commit>:<path>` 读取，未将 `/srv/pi-lab-dev/tmp/codex-9f97cb79` 的 dirty 文件作为真值。
- 本审查没有构建 Rust、执行模型调用、修改主仓库。后续唯一写入为本报告。
- Rust 沙盒、FD、包信任根、可复现构建等安全整改与协议覆盖是不同验收轴；安全整改不能清除本报告的协议缺口。

旧 Bridge 确实直接调用 Rust serde，且只有七个解析方法：`parse_core_exec`、`parse_core_apply_patch`、`parse_core_review_decision`、`parse_core_ask_for_approval`、`parse_core_approvals_reviewer`、`parse_v2_command_response`、`parse_v2_file_response`。七个方法不是 B1 全部契约。

## 源到实现覆盖矩阵

表中上游路径均相对于固定 Codex 的 `codex-rs/`；目标路径相对于上述目标工作区；patch 行号对应审查时旧 patch。

| 模块 | 固定源真值 | 旧 Bridge / 目标状态 | 未完成验收项 |
| --- | --- | --- | --- |
| Core AskForApproval serde | `protocol/src/protocol.rs:965` | patch:288 直接真实类型 serde | Core Default 无接口；仅 on-failure 单例，Granular 缺字段/null/unknown/重复字段未差分 |
| Core ApprovalsReviewer | `protocol/src/config_types.rs::ApprovalsReviewer` | patch:294 直接真实类型 | User Default 无接口；alias 单例不足以证明完整 reject/default/null 行为 |
| ReviewDecision | `protocol/src/protocol.rs:4008` | patch:282 真 serde | Default 和 to_opaque_string 未暴露；全变体未在 bridge 测试 |
| Core Exec 完整解析 | `protocol/src/approvals.rs:245` | patch:278 真 serde；IR i64 为十进制字符串 | 仅 Exec MAX 单例；字段/alias/duplicate alias/null/unknown/非法数字 corpus 缺失 |
| Exec effective ID | `protocol/src/approvals.rs:316` | patch:145 实际调用 | 仅默认 call_id；approval_id 存在/空串/null 未覆盖 |
| Exec effective decisions | `protocol/src/approvals.rs:322,336` | Bridge 未调用和输出；旧 TS 手写仍存在 | 需真实 effective_available_decisions 结果，含 Some([])、网络优先、首个 Allow、额外权限 |
| Core ApplyPatch / FileChange | `protocol/src/approvals.rs:432`；`protocol/src/protocol.rs:4084` | patch:279 间接真 FileChange serde | 仅空 changes + MIN；三分支/null/缺字段/extra/路径 map 未 bridge 差分 |
| V2 Ask / Reviewer | `app-server-protocol/src/protocol/v2/shared.rs` | Bridge 无方法；旧 TS 手写 | 与 Core 隔离：V2 无 Default，Ask 无 on-failure alias |
| V2 Command 请求参数 | `app-server-protocol/src/protocol/v2/item.rs:1529` | Bridge 无方法 | i64、kind 默认、environmentId 显式 null、nullable/skip 字段和 availableDecisions |
| V2 File 请求参数 | `app-server-protocol/src/protocol/v2/item.rs:1612` | Bridge 无方法；旧 TS:224 | 旧 TS 拒 unknown、限 safeInteger；reason/grantRoot 需显式 null |
| V2 Command / File 响应 | `app-server-protocol/src/protocol/v2/item.rs:1605,1630` | patch:300,308 真 serde | 仅 accept 和 decline 各一例；完整 enum/amendment/unknown/null/type 错误未覆盖 |
| Core 到 V2 decision 映射 | `app-server-protocol/src/protocol/v2/item.rs:84` | 旧 TS:120 手写；golden 8 样本 | Bridge 未调用真实 From；network Deny 缺样本 |
| V2 响应到 Core / 失败收敛 | `app-server/src/bespoke_event_handling.rs:1981,1991,2033` | 未实现 | 映射/completion status/client与recv错误/turn-transition 特例 |
| 纯 Reviewer 路由 | `core/src/guardian/review.rs:205` | 旧 TS:239 strict 直接 Guardian | 明确偏离：纯路由只 OnRequest 或 Granular + AutoReview，strict 属中央阶段 |
| ApprovalStore | `core/src/tools/sandboxing.rs:40,70` | oracle patch:96 只 raw get/put | 没调用 with_cached_approval，不能称 session-only 运行时覆盖 |
| PermissionRequest | `hooks/src/events/permission_request.rs:67,87,152,188` | oracle patch:150 仅 parser 与纯 fold | 无 preview/run/parse_completed/dispatcher 生命周期真值 |
| Oracle 再生成门禁 | `scripts/generate-codex-approval-protocol-oracle.sh` | 固定 commit/blob、新 detached worktree 正确 | 无 --check；66-69 行直接 mv 覆盖 golden；未强制 package/CI 差分 |

## 具体证据与必须整改项

### 1. Bridge owner 测试不等于协议覆盖

`bridge-owner-v2.test.mjs:68-92` 的一个测试遍历七方法，基本每方法一个 happy sample：Exec MAX、Patch MIN、approved、on-failure、guardian_subagent、command accept、file decline。其余测试主要验证 FD、预算、取消和生命周期。

其中 `canonicalWire` 仅正则匹配 MAX 数字存在，未完整逐字段和精确数字 token 差分。不得将 owner 的 8/8 写为协议 100% 覆盖。

### 2. Core Default 与 opaque 输出未迁移

固定 `protocol/src/protocol.rs:4045-4080` 定义 `ReviewDecision::default()` 为 `Denied { rejection: "denied" }`；`to_opaque_string()` 有九种结果。

当前 oracle 已导出 `defaults.reviewDecision`、每项 `opaque`，但 `tests/approval-protocol.spec.ts:20-24,50-51` 未声明和消费。network Deny 连 oracle 输入也缺失。

必须验证全部输出：`approved`、`approved_with_amendment`、`approved_for_session`、`approved_mcp_policy_amendment`、`approved_with_network_policy_allow`、`denied_with_network_policy_deny`、`denied`、`timed_out`、`abort`。

### 3. Exec 解析后的有效行为缺失

旧 `ExecIrV1` 仅调用 `effective_approval_id()`，没有 `effective_available_decisions()`。

必须直接使用固定上游的真实方法，区分：

- `Some([])` 原样保留；只有 None 推导。
- network context 优先于 additional permissions。
- network amendments 只取首个 Allow；Deny-only 不提供持久 Allow。
- additional permissions 返回 Approved、Abort。
- ordinary 可附 execpolicy amendment。
- `environmentId` 和 `environment_id` 同时出现的 duplicate 必须交真实 serde；不能先被 JS 预解析抹除。

### 4. V2 请求参数和响应落地不可省略

固定 `item.rs:1593` 的 `strip_experimental_fields()` 仅清除 additional_permissions，不能擅自清除 available_decisions。

固定 `bespoke_event_handling.rs:1981`：Accept 到 Approved；AcceptForSession 到 ApprovedForSession；Decline 到 Denied("rejected by user")；Cancel 到 Abort。

固定 `:2065-2088`：network Deny 有 Declined completion status；network Allow 没有该 status。固定 `:2090-2112`：坏响应、client 错误、receiver 错误为 Denied("approval request failed") + Failed；turn-transition 特例直接 return，不能伪造 Denied 提交。固定 `:664-669`：无效 cwd 在 UI 前 Denied("invalid command approval cwd")。

需把 `bespoke_event_handling.rs` 纳入源 blob/FQN 清单，并区分纯映射 B1 与宿主生命周期 B2/B3 的状态。

### 5. Store oracle 的 session-only 结论不成立

`tests/oracle/codex-approval-protocol-oracle.patch:96-107` 只调用 get/put，并且将 Approved 存入，证明的是 raw store 可以存不同 decision，不是 session-only 策略。

真实 `with_cached_approval` 必须测：

- empty keys 直接 fetch，早退不产生 approval counter。
- 所有 key 已 ApprovedForSession 才跳过 fetch；partial 仍 fetch。
- 非空 keys 的 fetch 后记录 counter，包括 decision opaque。
- 只有 ApprovedForSession 才写所有 keys；其他 decision 不写。
- key 序列化失败时 get miss、put no-op。

`tests/approval-protocol.spec.ts:95-99` 应更名，并新增真实函数 oracle。不能用静态数组宣称流程已测。

### 6. PermissionRequest 测试只是固定 JSON 自检

`tests/approval-protocol.spec.ts:85-92` 仅断言 parser.length 为 6 及 fold 对象等于手写常量，未将输入传给待验收实现，未消费 parser.result/invalidReason。实现不存在时该测试仍会通过。

需导出真实 `parse_completed` 与 `run` 行为：

- 无匹配 handler：None + []。
- exit0 普通文本：Completed + None。
- malformed JSON-looking：Failed + None。
- exit2 非空 stderr：Blocked + Deny。
- exit2 空 stderr、timeout/error、其他 exit、无 status：Failed + None。
- 多 handler 乱序完成仍按配置顺序 fold；first deny wins。
- Async 不控制和阻塞当前决定；记录其真实生命周期。
- run-id、turn、suffix 及 started/completed 数量一致。

## 下一阶段可执行验收清单

1. 补齐 Bridge 协议接口：Core 三 Default、ReviewDecision opaque、Exec effective decisions、V2 请求与配置类型。内部 wire 禁止先由 JS JSON.parse。
2. raw-wire corpus：四类 i64 字段覆盖 MIN/MAX、正负 2^53 附近、越界、指数、小数、-0；struct 覆盖缺省/null/unknown/duplicate known/duplicate alias；enum 覆盖全部 variant 与嵌套 payload。
3. 实际映射差分：Core 到 V2 From、V2 到 Core 与错误分支；app-server 生命周期单独标状态。
4. 补 B2 依赖 oracle：真正 with_cached_approval 和 PermissionRequest 生命周期。不得提前宣称 B2 已运行时接入。
5. 所有 golden 字段必须被消费；存在未消费字段使 coverage gate 失败。
6. 再生成器 --check 写临时目录、比较失败退出、不覆盖 golden；校验 source pre-clean、patch SHA、changed-path allowlist、source FQN/blob，并接强制 CI。
7. 新提交后二次独立审核，逐项区分 implemented、differential-tested、runtime-integrated，不以 native Bridge 总括 100%。

附注：ApplyPatch 包含 HashMap，不可未经证明就承诺跨进程 canonicalWire 的键顺序逐字稳定。数字 token 必须精确验证；map 语义比较与可复现序列化分开定义。

## 追加纠正：raw wire 的负零必须拒绝

以下为主审 `/root` 随后提供的旧 GNU2.31 Bridge 直接 raw-wire 实测证据，区别于本报告前述只读源码审查；本报告作者未重跑该实测。

- `started_at_ms:-0` 返回 serde 错误：`invalid type: floating point -0.0, expected i64`，位置为 column 79。
- `started_at_ms` 为 i64 MIN、i64 MAX、`9007199254740993`、`-9007199254740993` 的四个 raw-wire 输入均成功。
- 因此固定上游的 raw deserializer 对 `-0` 是拒绝，不是 canonical 为整数 0。过去摘要中的负零归一化说法不能用于 raw-wire 合同。
- 经 JavaScript Number 或 serde_json::Value 等中间表示预解析，可能先丢失原始数值 token 特征或归一化为 0；这类 oracle 不可替代 `serde_json::from_str` 的原始 wire 差分。
- 下一阶段 raw-wire corpus 中的 `-0` 用例应断言拒绝，并与整数 `0` 的接受分开；不得为了旧预期修改上游 serde 行为。

主审说明 `rust-remediation.test.mjs` 已依实测更新断言，未改上游语义。本追加只记录证据和纠正，不构成对新 Rust patch 或整个 B1 的 PASS。
