# v0.0.0-prototype.4 实测记录（局部通过，完整门禁仍失败）

源码冻结提交：`198ac99ddf8bf136fdfb4a4373b65eaca2ca22ec`。所有编译产物复用上一版固定 Rust 字节，本轮没有 Rust 编译。仅在远程 staging 修改，未触碰主插件 worktree。

## 本轮结果

- 首次只读 bind-mount 快速测试：11/19 通过，8 个 mock-child 场景失败。原因是修改后的 mock 源文件为 mode 664，映射为容器 root 后仍有 group-write，被 artifact 信任检查拒绝。未通过的记录保留在 `evidence/owner-prototype4-fixture-permission-failure.log`，SHA256 `5d54b3abee7566c24bfdbbcd1e31ea28ad4b08529ca19e9b1814ae81d4d03828`。夹具改为 755 后通过；生产信任代码未放宽。
- 数值配置修复后快速测试：20/20，0 fail/cancel/skip，见 `evidence/owner-prototype4-config.log`，SHA256 `215a6c9a416b51cc93a9c9441392d5c0ca44fe8e232c6964057d8f6e7852c88c`。
- 最终重新 npm pack 两包、离线安装、root 安装后 uid 65532 运行：20/20 owner 回归和 9/9 包场景通过，脚本 exit 0。见 `evidence/package-prototype4-final.log`，SHA256 `f032838cf017f6eaf50872b2442580dbb458d6330cbc52460c493383a116465f`。
- 9 个包场景为 installed、same-uid、host-only、manifest-extra、manifest-version、manifest-path、manifest-size、manifest-symlink、package-version；除 installed 外均验证预期拒绝。运行容器 `--network=none --read-only`，仅 16MiB noexec/nosuid/nodev tmpfs。
- `verify-artifacts.mjs` 实跑 exit 1，同时保留 LICENSE-GATE-FAIL（12）与 UPSTREAM-DEVELOPMENT-GATE-FAIL（controlled execution runner 未实现）。没有把 JSON 状态或此测试记录视为接受授权。本轮不发布、不合入、不宣称 production-ready。

## 冻结哈希

| 对象 | SHA256 |
| --- | --- |
| owner 及 host 副本 | `efd4cc34a16707e85713ad981119477156711c0e99c8a35b4f4ea5c30a1f6a3d` |
| owner tests | `34f19bbe7d561836096fcbb3f0760219408936cd0c1642b2aabdda830e4633af` |
| mock-child | `4d36dc45696f585f1b270e22f0e44508ae84dac93329f1d74d90338894245470` |
| host pinned provenance | `524c71db4b73cf1e9f39e964b5323324db5d282e5e20db324cc7589218a0695a` |
| SBOM（仅 metadata version 更新） | `122ca1fa6d9b21bfc4735e730989b3339b205e9f86de2da994763a6239b236f8` |
| host prototype.4 tgz | `dba22ed36607b368617fafc62a3dc14fae1e1c3088853dcfbb30e49ed0ab6619` |
| platform prototype.4 tgz | `75e995e2985cb4a29bf9d080874a2878fed9e9813adff7b217e25b0767564236` |
| 最终测试 image | `dbddb9a31f323bf4a83a31cc8bf3ea45570c0b27a98ef84dab4e57f37042cb19` |
| Rust patch（未变） | `35c5196aee02d0a4dd229a0faf7fe782d64c435042ecc675940be8b1b785eebd` |
| GNU2.31 binary（未变，两份相同） | `be0889b1bc892a16c8dd026f552a8152e4d633723d2495e94ebb4fd4b4351ffc` |

两位独立 reviewer 已收到同一冻结 commit 与 image ID；本记录不预写尚未完成的复审结论。原 prototype.3 的两份 owner/package FAIL 报告不覆盖、不删除。
