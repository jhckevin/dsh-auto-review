# ISSUE022B · v0.0.0-prototype.5：旧进程事件隔离

本版只修复独立安全复审发现的旧子进程事件污染新 generation。prototype.4 的局部测试通过不能覆盖这个新发现，其 FAIL 及复现证据保留。Rust patch、binary、launcher 不改变、不重新编译；包继续 private，不合入主插件、不发布。

## 根因与修复

旧 bridge 在 SIGSTOP 下积压大 stdin write，被 AbortSignal 杀死；零 backoff 立即启动新 bridge 后，旧 write callback 才返回 EPIPE。旧代码的 callback 不检查 child，错误地调用 host-wide restart 杀死新 generation。延长 backoff 只能隐藏竞态，不是解决方法。

统一 `isCurrent(child, generation)` 检查：

- stdin write callback 与同步 write exception：仅当前 child/generation 可以 restart；写后回填 writeBlocked 同样受保护。
- stdout：入口和每帧循环检查身份，防止 drain/abort 后继续消费旧 chunk。
- stderr、stdin drain、stdin error、child error/exit：全部在改变 host 状态之前检查身份。
- inflight timeout：除 child/generation 外，必须仍是 pending Map 中同一个 item，防止请求 ID 复用。
- queue timeout：除 child/generation 外，必须仍包含同一个 queue item；已退休 callback 不触发 drain。
- AbortSignal：必须是当前 generation 且 item 仍 pending 或 queued。attachAbort 可能同步取消，因此返回后再次检查，取消后不继续 write。
- startup/handshake catch：不能再次重启已经退休或被替换的 child；尚未成功 spawn 的错误也必须属于原启动代次。

close 的局部退出等待 timer 与 backoff timer 只唤醒其局部 promise；不直接修改共享 generation。close 只终止其捕获的旧 child，startup 在等待后检查 closing/closed。

## 回归设计

真实 Rust bridge、真实 Landlock launcher、非 root 只读容器，执行 12 轮：handshake → SIGSTOP → 1MiB 请求填满 pipe → 20ms 后 Abort → 不等待旧写回调、零 backoff 立即 handshake。旧请求必须 cancelled，新 handshake 成功，generation 恰好加一，PID 改变，后续合法请求继续成功，无隐式重发。

先对 prototype.4 冻结镜像运行同一新增测试，首轮重现 `BridgeFailure(write EPIPE)`；修复后再跑新增测试和原 20 项回归。真实 pipe 用例验证该复现路径，其他回调检查由源码审计补充，不能声称对所有 OS 事件交错穷举证明。

完整许可与上游开发门禁不属于此次修复，仍未完成。两位 reviewer 须对新的冻结提交和安装镜像独立复核，不能沿用 prototype.4 的结论。
