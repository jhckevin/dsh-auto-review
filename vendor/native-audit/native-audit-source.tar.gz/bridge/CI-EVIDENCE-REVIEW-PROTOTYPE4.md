# Independent CI evidence-blocking remediation review

Date: 2026-09-02. Reviewer: bridge_security_review.

Verdict: PASS for the narrowly scoped false-green prevention fix; P0=0/P1=0/P2=0 new findings in this scope. Actual combined CI remains FAILED/BLOCKED. This is not completion of upstream development gates or license collection.

## Frozen source

Commit: `94d725b425d99caf1f23bb4acce1aaa0b71d7438`.

Working copies of the following four files were verified identical to that commit with `git diff 94d725b -- ...`:

- evidence-gates.mjs SHA256 `15ea9b13ca31ca372a05838e54bd7a1aba69a4c3e6f738893e8a4bee6905377f`
- evidence-gates.test.mjs SHA256 `1e0d4a3f5f29a1b376981314bca088e0f7ae2142b41cf211f439ab7ba07ee0c5`
- verify-artifacts.mjs SHA256 `1d4738fefd5f4b84c2d1e23f80e176831cf680cd72f079fac27d49d9207a6fdd`
- ci-check.sh SHA256 `93abbbd831f4ae21f19b3ef31fc09448059f7745c402647bd974d9b51d849ca4`

Base directory: `/srv/pi-lab-dev/tmp/issue022b-native-bridge-prototype`. Only this report was written using remote safe apply_patch. Owner changes occurring separately were not re-reviewed. No source, original license or evidence data was modified.

## Independent execution

1. `/srv/pi-lab-dev/toolchains/node-v24.8.0-linux-x64/bin/node --test evidence-gates.test.mjs`: 5 tests, 5 pass, no failures/skips/cancellations; duration 172.152392ms.
2. `/srv/pi-lab-dev/toolchains/node-v24.8.0-linux-x64/bin/node verify-artifacts.mjs`: exit 1 with BOTH actual reasons:
   - `LICENSE-GATE-FAIL: 12 components lack source-backed license material`
   - `UPSTREAM-DEVELOPMENT-GATE-FAIL: controlled execution runner is not implemented; JSON status/evidence cannot authorize acceptance`

The actual inventory test recomputed 672 unique components, preserved 12 unique real gaps including fxhash@0.2.1, and read/hash-checked a real included license. Path tests rejected absolute/traversal/empty/alias/NUL/oversized inputs and non-file evidence. No spoofed-passed evidence test was executed and no previously rejected operation was retried.

## Source findings and resolution

### Fixed graph and component completeness

`evidence-gates.mjs:37-47` requires the reviewed dependency graph SHA256 `3dc5c8c6df7305ed896fd364a00ae5466677500e90c8d6663552fa894349b851` before parsing. A Map deduplicates legitimate repeated cargo-tree references by name@version and rejects conflicting license expressions.

Lines 48-86 require matching audit graph hash, exact component count, known unique SBOM component IDs, identity consistency with name/version, graph-derived license expressions and exactly one licenseMaterials property per component. Missing/nonempty material coverage is recomputed from actual properties/files rather than authorized by audit.missing. The recomputed list must exactly agree with audit.missing, so clearing that summary no longer substitutes for material coverage.

### Material path/type/hash verification

`readEvidence` at lines 17-34 validates bounded relative paths, disallows traversal/empty/platform-alias segments and symlinks in all package-relative segments, requires a nonempty regular file under the fixed operator-controlled root and enforces a size cap. Material entries at lines 71-81 require exact path/sha256 keys, component-specific directory prefixes, no duplicate paths, SHA256 syntax and matching file bytes.

This is development evidence validation under an operator-controlled staging directory, not a concurrent hostile filesystem security boundary or a legal certification that every license is sufficient. It does not manufacture or alter missing license text. All 12 missing components remain blocked.

### No metadata-only development approval path

`inspectDevelopmentEvidence` at lines 90-99 checks the fixed upstream commit and required gate list, then ALWAYS returns accepted:false because the controlled runner is not implemented. No status value or arbitrary nonempty evidence list enables success. Therefore the previous self-reported passed/nonempty predicate is removed rather than disguised as validation.

This deliberate denial is sufficient to resolve the narrowly identified false-green path while honestly leaving the development workflow incomplete. A future passing path requires its own reviewed implementation executing the real commands and binding source identity, logs, digests and completion results; this report does not pre-approve that future design.

### Combined CI propagation

`verify-artifacts.mjs:23-36` accumulates real license gaps and the development denial, throwing before its success marker. `ci-check.sh` runs with set -eu, includes the five evidence tests, and calls verify-artifacts before package/rebuild/final-marker stages. A passing runtime suite cannot reach the final combined success marker while these blockers remain.

## Disposition

The prior OWNER-PACKAGE-REVIEW P1 concerning metadata-only CI approval is resolved for these frozen files. The correct observable result is still CI exit 1, not release acceptance.

Excluded: owner lifecycle/queue/prototype-key fixes, complete B1 parity, native Harness integration, source-backed completion of missing licenses, real upstream formatter/linter/nextest/lock-update runner, and production release. Original FAIL reports remain historical evidence; this report does not replace them or close unrelated findings.
