# Rust Bridge 修复第二独立限定审查

## 结论

**限定 Rust 修复范围 PASS；本范围未发现 P0/P1/P2 阻断项。完整 B1 仍为 FAIL。**

本结论只覆盖 UTF-8 错误截断、最终编码响应 cap、deny-by-default syscall allowlist/进程限制、additionalPermissionsWire 无损序列化，以及原七方法的限定回归样本。不是完整协议、owner、包信任根、供应链、生产集成或完整沙盒验收，不能将任何未完成模块改为 complete。

- 独立审查者：`/root/protocol_coverage_review`。
- 固定上游：`9f97cb79eb15b38d24c552c56fe24e211ff9cf3a`。
- patch：`35c5196aee02d0a4dd229a0faf7fe782d64c435042ecc675940be8b1b785eebd`。
- binary `codex-approval-protocol-bridge-v2.remediated-gnu2.31`：`be0889b1bc892a16c8dd026f552a8152e4d633723d2495e94ebb4fd4b4351ffc`。
- `rust-remediation.test.mjs`：`1f5d3a706e6ef760f8f4294b851081b40edb7af71d7a7914492d97f4764bbc3e`。
- 源文件 `/srv/pi-lab-dev/tmp/issue022b-bridge-worktree/codex-rs/approval-protocol-bridge-prototype/src/main.rs`：`89431c545ed50c6a4b7f64a94138772807155ae41ce17ab2fcf1fe774b14742a`。
- 开始和结束均重新核对 patch/binary SHA。未构建 Rust，未修改 Rust、owner 或主仓库。唯一持久化写入为本报告。

## 源码审查

以下行号为上述 main.rs。

| 修复点 | 源码证据 | 结论 |
| --- | --- | --- |
| Unicode 错误截断 | 183-192：超过 4096 bytes 时向后退到 is_char_boundary，再 truncate | 不再因多字节截断点 panic；UTF-8 完整且上限按 bytes |
| 最终响应 cap | 276-318：BoundedFrame 在 extend 前检查；serde_json::to_writer；超限改写同 id/session 的 resource_limit；写 stdout 前完成编码 | 防止半截响应；resource error 后可继续处理下一请求 |
| 输入 cap | 326-353：fill_buf 增量读取，追加前检查 4 MiB，缺结尾 newline 返回错误 | 保留原有有界读取，不受本修复退化 |
| syscall allowlist | 386-453：校验 x86_64 arch，只有显式 syscall 可通过，其余 EPERM；x32 编号未列入 | open/socket/exec/clone/io_uring/process_vm 等不在许可集；不再依赖 blacklist |
| 启动防护 | 455-524：socket/filesystem/x32/io_uring_setup/clone3/process_vm_readv 拒绝探针；RLIMIT_AS/FSIZE/NOFILE/NPROC；NoNewPrivs；main 先 harden | handshake 前先完成全部探针和限制 |
| permissions 无损 | 72-73、167-180：真实 AdditionalPermissionProfile 序列化为 JSON 字符串或 null | NonZeroUsize 不再进入 JS Number；没有手写字段猜测 |
| 原七方法 | 195-273：仍直接 from_str 到固定上游类型，再真实 serde 输出 | 限定样本未发现解析语义退化；缺失方法仍然缺失 |

## 独立执行结果

使用远程 Node 24.8.0，经过 `landlock-run.linux-x64 --ro / --rw /dev/null -- <binary>` 执行。

### 已有修复测试

独立执行 `node --test rust-remediation.test.mjs`：**6/6 PASS，0 fail/skip/cancel**。覆盖长中文/重音/emoji 错误存活、启动探针、raw i64、unknown/duplicate alias、超大最终响应及后续请求、嵌套 NonZeroUsize MAX。

其中 raw `-0` 明确被拒绝；i64 MIN/MAX、正负 9007199254740993 和 0 被接受。不得用 Number/Value 归一化替代原始 wire。

### 审查者额外样本

在单一进程中发送以下 **14 个响应样本，14/14 PASS**，脚本仅通过 Node stdin 临时执行，未写源文件：

1. envelope 内原始 0xff 非法 UTF-8：invalid_envelope，下一请求仍正常。
2. Exec write_stdin、空 approval_id、environment_id alias、显式空 decisions：正确保留；effective ID 是空串。
3. Patch i64 MAX、Unicode update、缺 move_path、unknown extra：MAX 无损，move_path 为 null。
4. ReviewDecision network Deny：成功。
5. Granular 缺可默认 bool、unknown extra：成功，skill_approval false。
6. Reviewer user：成功。
7. V2 command execpolicy amendment、unknown outer extra：成功。
8. V2 file cancel、unknown outer extra：成功。
9. additional_permissions null：IR additionalPermissionsWire null。
10. NonZeroUsize 为 0：拒绝。
11. NonZeroUsize 超过 u64 MAX：拒绝。
12. 深层错误形状数组：拒绝，进程继续；这不是完整递归深度边界证明。
13. reason 含 500000 个 U+0001，编码转义膨胀：correlated resource_limit，未输出半帧。
14. 上述错误后 approved：成功。

### 活进程限制核验

独立启动握手后直接读取其 `/proc/<pid>/status` 和 `limits` 并断言：

- NoNewPrivs=1；Seccomp=2。
- Max address space soft/hard=268435456 bytes。
- Max file size soft/hard=0。
- Max open files soft/hard=32。
- Max processes soft/hard=1。

全部 PASS；核验后关闭 stdin，进程自然退出。

## 必须保留的边界

- 4 MiB cap 是最终编码帧上限，不是整个请求生命周期内存上限；canonicalWire/IR 在此前已分配，代码准确注明另受输入上限及 RLIMIT_AS 约束。未做内存耗尽/CPU 压力验收。
- allowlist 仍允许 read/write/mmap 等对继承 FD 的操作，因此父 owner 必须严控继承 FD；本审查不验证 owner 的 FD/环境/包根可信度。
- additionalPermissionsWire 是内部 IR 变化；消费者必须与 patch/schema 配对，不可 JSON.parse 后把大整数当授权数据。owner 适配由其他审查负责。
- 本次没有重新验证 source-to-binary 可复现构建、SBOM、许可证、root-owned 包或发布链。
- 原 `PROTOCOL-COVERAGE-REVIEW.md` 中完整 B1 缺口保持 FAIL：默认/opaque、effective decisions、V2 请求参数、映射落地、真实 Store/PermissionRequest oracle 与强制 CI 不能被这 6+14 个 Rust 修复测试替代。
