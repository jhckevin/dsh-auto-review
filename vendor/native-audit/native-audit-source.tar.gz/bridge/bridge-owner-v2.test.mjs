import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import {
  lstatSync, readFileSync, realpathSync, statSync,
} from "node:fs";
import { execFileSync, spawn } from "node:child_process";
import { afterEach, test } from "node:test";
import {
  BridgeFailure, acquireHostBridge, closeHostBridgeForTests,
} from "./bridge-owner-v2.mjs";

const root = new URL(".", import.meta.url).pathname;
const bridgePath = process.env.CODEX_BRIDGE_TEST_BINARY
  ?? `${root}codex-approval-protocol-bridge-v2.linux-x64-gnu`;
const launcherPath = `${root}landlock-run.linux-x64`;
const wrongPath = `${root}wrong-session-bridge.sh`;

function sha(path) {
  return createHash("sha256").update(readFileSync(path)).digest("hex");
}

function artifact(path) {
  const stat = statSync(path);
  return {
    path, realpath: realpathSync(path), trustRoot: realpathSync(path),
    uid: stat.uid, size: stat.size, sha256: sha(path),
  };
}

const expectedHandshake = {
  protocol: 2,
  upstreamCommit: "9f97cb79eb15b38d24c552c56fe24e211ff9cf3a",
  bridgePatchSha256: "5cb90364c0a728dc97c278815905c5f6469a9139563fb08d17808908c1bef5c7",
  irVersion: 1,
  os: "linux",
  arch: "x86_64",
};

function options(overrides = {}) {
  return {
    bridge: artifact(bridgePath),
    launcher: artifact(launcherPath),
    expectedHandshake,
    artifactOwnerUid: 0,
    baseBackoffMs: 1,
    maxBackoffMs: 5,
    timeoutMs: 500,
    ...overrides,
  };
}

afterEach(async () => closeHostBridgeForTests());

test("old pipe EPIPE cannot kill an immediate zero-backoff replacement generation", {timeout: 15000}, async () => {
  const host = acquireHostBridge(options({baseBackoffMs: 0, maxBackoffMs: 0, timeoutMs: 1000}));
  const session = host.createSession();
  const wire = JSON.stringify({denied: {rejection: "x".repeat(1024 * 1024)}});
  for (let iteration = 0; iteration < 12; iteration += 1) {
    await host.request(session, "handshake");
    const oldPid = host.pid;
    const oldGeneration = host.generation;
    process.kill(oldPid, "SIGSTOP");
    const controller = new AbortController();
    const pending = host.request(session, "parse_core_review_decision", wire, {signal: controller.signal});
    const rejected = assert.rejects(pending, e => e.kind === "cancelled");
    await new Promise(resolve => setTimeout(resolve, 20));
    controller.abort();
    // No delay: deliberately race the old process's failed queued stdin write against a fresh child.
    const replacement = host.request(session, "handshake");
    await rejected;
    assert.equal((await replacement).protocol, 2);
    assert.equal(host.generation, oldGeneration + 1);
    assert.notEqual(host.pid, oldPid);
    assert.equal((await host.request(session, "parse_core_review_decision", '"approved"')).ir.decision, "approved");
    assert.equal(host.state, "running");
  }
});

function mockOptions(overrides = {}) {
  return options({bridge: artifact(root + "mock-bridge.mjs"),
    expectedHandshake: {...expectedHandshake, bridgePatchSha256: "6d44f0519319f2f1a1c19d61e8c5fcdcc3c2136d916d0089175db34fa0f2d23f"}, ...overrides});
}

test("invalid timers and budgets reject before startup; zero queues remain supported", async () => {
  const baseline = options();
  const fields = ["timeoutMs", "queueTimeoutMs", "shutdownMs", "probeMs", "baseBackoffMs", "maxBackoffMs",
    "maxInflight", "maxQueue", "maxInflightBytes", "maxQueueBytes", "maxResponseFrameBytes", "maxStderrBytes"];
  for (const field of fields) {
    for (const value of [NaN, Infinity, -1, 1.5, Number.MAX_SAFE_INTEGER + 1, "100"]) {
      assert.throws(() => acquireHostBridge({...baseline, [field]: value}), e => e.kind === "configuration");
    }
  }
  for (const field of ["timeoutMs", "queueTimeoutMs", "shutdownMs", "probeMs", "baseBackoffMs", "maxBackoffMs"]) {
    assert.throws(() => acquireHostBridge({...baseline, [field]: 2147483648}), e => e.kind === "configuration");
  }
  for (const field of ["timeoutMs", "queueTimeoutMs", "shutdownMs", "probeMs", "maxInflight", "maxInflightBytes", "maxResponseFrameBytes", "maxStderrBytes"]) {
    assert.throws(() => acquireHostBridge({...baseline, [field]: 0}), e => e.kind === "configuration");
  }
  assert.throws(() => acquireHostBridge({...baseline, baseBackoffMs: 5, maxBackoffMs: 1}), e => e.kind === "configuration");
  assert.throws(() => acquireHostBridge({...baseline, maxInflight: Number.MAX_SAFE_INTEGER, maxQueue: 1}), e => e.kind === "configuration");
  assert.throws(() => acquireHostBridge({...baseline, maxInflightBytes: Number.MAX_SAFE_INTEGER, maxQueueBytes: 1}), e => e.kind === "configuration");
  const host = acquireHostBridge({...baseline, maxQueue: 0, maxQueueBytes: 0, baseBackoffMs: 0, maxBackoffMs: 0});
  assert.equal(host.generation, 0);
  const session = host.createSession();
  assert.equal((await host.request(session, "parse_core_review_decision", '"approved"')).ir.decision, "approved");
});

test("prototype names in all external variants fail the generation and never replay", {timeout: 15000}, async () => {
  for (const method of ["parse_core_review_decision", "parse_v2_command_response", "parse_core_ask_for_approval"]) {
    for (const key of ["__proto__", "constructor", "toString", "valueOf"]) {
      const host = acquireHostBridge(mockOptions());
      const session = host.createSession();
      await host.request(session, "handshake");
      const generation = host.generation;
      const outcomes = await Promise.allSettled([
        host.request(session, "parse_core_review_decision", '"hold"'),
        host.request(session, method, JSON.stringify(`prototype:${key}`)),
      ]);
      assert.ok(outcomes.every(x => x.status === "rejected" && x.reason instanceof BridgeFailure && x.reason.kind === "protocol"));
      assert.equal(host.pid, undefined);
      assert.equal(host.state, "backoff");
      const result = await host.request(session, "parse_core_review_decision", '"dispatch-count"');
      assert.equal(result.ir.decision.denied.rejection, "1");
      assert.equal(host.generation, generation + 1);
      await closeHostBridgeForTests();
    }
  }
});

test("unexpected method validator exceptions become protocol BridgeFailure", async () => {
  const host = acquireHostBridge(mockOptions());
  const session = host.createSession();
  await assert.rejects(host.request(session, "handshake", '"bad-handshake-coercion"'),
    e => e instanceof BridgeFailure && e.kind === "protocol");
  assert.equal(host.pid, undefined);
  assert.equal((await host.request(session, "parse_core_review_decision", '"dispatch-count"')).ir.decision.denied.rejection, "1");
});

test("unsendable single frames reject before queuing whether busy or idle", {timeout: 5000}, async () => {
  const host = acquireHostBridge(mockOptions({maxInflight: 1, maxInflightBytes: 1024, maxQueueBytes: 8192}));
  const session = host.createSession();
  await host.request(session, "handshake");
  const first = host.request(session, "parse_core_review_decision", '"delay:150"');
  const oversized = JSON.stringify("x".repeat(2048));
  await assert.rejects(host.request(session, "parse_core_review_decision", oversized), e => e.kind === "backpressure");
  await first;
  await assert.rejects(host.request(session, "parse_core_review_decision", oversized), e => e.kind === "backpressure");
  assert.equal((await host.request(session, "parse_core_review_decision", '"dispatch-count"')).ir.decision.denied.rejection, "2");
});

test("queue expiry releases budgets without dispatch and inflight receives a fresh full timeout", {timeout: 5000}, async () => {
  const host = acquireHostBridge(mockOptions({maxInflight: 1, maxQueue: 1,
    maxInflightBytes: 1024, maxQueueBytes: 1024, timeoutMs: 600, queueTimeoutMs: 200}));
  const session = host.createSession();
  await host.request(session, "handshake");
  const generation = host.generation;
  const first = host.request(session, "parse_core_review_decision", '"delay:300"');
  await assert.rejects(host.request(session, "parse_core_review_decision", '"must-not-run"'), e => e.kind === "queue_timeout");
  const start = performance.now();
  const replacement = host.request(session, "parse_core_review_decision", '"delay:550"');
  await Promise.all([first, replacement]);
  assert.ok(performance.now() - start > 600, "queued waiting must not shorten the 600ms execution deadline");
  assert.equal(host.generation, generation);
  assert.equal((await host.request(session, "parse_core_review_decision", '"dispatch-count"')).ir.decision.denied.rejection, "3");
});

test("queued deadlines are removed on abort and close without late generation changes", {timeout: 5000}, async () => {
  for (const action of ["abort", "session", "host"]) {
    const host = acquireHostBridge(mockOptions({maxInflight: 1, maxQueue: 1, queueTimeoutMs: 80}));
    const session = host.createSession();
    await host.request(session, "handshake");
    const controller = new AbortController();
    const first = host.request(session, "parse_core_review_decision", '"hold"');
    const queued = host.request(session, "parse_core_review_decision", '"must-not-run"', {signal: controller.signal});
    const settled = Promise.allSettled([first, queued]);
    await new Promise(resolve => setTimeout(resolve, 10));
    if (action === "abort") controller.abort();
    else if (action === "session") await host.closeSession(session);
    else await host.close();
    assert.ok((await settled).every(x => x.status === "rejected" && x.reason.kind ===
      ({abort: "cancelled", session: "session_closed", host: "closed"})[action]));
    const state = host.state;
    await new Promise(resolve => setTimeout(resolve, 100));
    assert.equal(host.state, state);
    if (action !== "host") {
      const fresh = action === "session" ? host.createSession() : session;
      assert.equal((await host.request(fresh, "parse_core_review_decision", '"dispatch-count"')).ir.decision.denied.rejection, "1");
    }
    await closeHostBridgeForTests();
  }
});

test("startup waiters reserve aggregate count and byte budgets before await", async () => {
  for (const mode of ["count", "bytes"]) {
    const host = acquireHostBridge(options({maxInflight: mode === "count" ? 1 : 4,
      maxQueue: mode === "count" ? 1 : 4, maxInflightBytes: 1024, maxQueueBytes: 1024}));
    const session = host.createSession();
    const wire = mode === "count" ? '"approved"' : JSON.stringify({denied: {rejection: "x".repeat(600)}});
    const outcomes = await Promise.all(Array.from({length: 32}, () =>
      host.request(session, "parse_core_review_decision", wire).then(() => "ok", error => error.kind)));
    assert.equal(outcomes.filter(x => x === "ok").length, mode === "count" ? 2 : 1);
    assert.equal(outcomes.filter(x => x === "backpressure").length, mode === "count" ? 30 : 31);
    assert.equal((await host.request(session, "parse_core_review_decision", '"approved"')).ir.decision, "approved");
    await closeHostBridgeForTests();
  }
});


test("response cap applies to each frame, not a coalesced stdout chunk", async () => {
  const host = acquireHostBridge(options({bridge: artifact(root + "mock-bridge.mjs"),
    expectedHandshake: {...expectedHandshake, bridgePatchSha256: "6d44f0519319f2f1a1c19d61e8c5fcdcc3c2136d916d0089175db34fa0f2d23f"},
    maxResponseFrameBytes: 1024}));
  const session = host.createSession();
  const results = await Promise.all([host.request(session, "parse_core_review_decision", '"coalesce"'),
    host.request(session, "parse_core_review_decision", '"coalesce"')]);
  assert.equal(results.length, 2);
  assert.equal(results[0].ir.decision.denied.rejection.length, 280);
});
test("method IR and canonicalWire shape reject malformed successful responses", async () => {
  for (const wire of ['"bad-ir"', '"bad-canonical"']) {
    const host = acquireHostBridge(options({bridge: artifact(root + "mock-bridge.mjs"),
      expectedHandshake: {...expectedHandshake, bridgePatchSha256: "6d44f0519319f2f1a1c19d61e8c5fcdcc3c2136d916d0089175db34fa0f2d23f"}}));
    await assert.rejects(host.request(host.createSession(), "parse_core_review_decision", wire), e => e.kind === "protocol");
    assert.equal(host.pid, undefined);
    await closeHostBridgeForTests();
  }
});

test("closed session cannot resume after await start", async () => {
  const host = acquireHostBridge(options());
  const session = host.createSession();
  await host.request(session, "handshake");
  const pending = host.request(session, "parse_core_review_decision", '"approved"');
  const rejected = assert.rejects(pending, e => e.kind === "session");
  await host.closeSession(session);
  await rejected;
});

test("close during startup and restart backoff never resurrects child", async () => {
  const host = acquireHostBridge(options({baseBackoffMs: 150, maxBackoffMs: 150}));
  const session = host.createSession();
  await host.request(session, "handshake");
  const pid = host.pid;
  process.kill(pid, "SIGKILL");
  while (host.state !== "backoff") await new Promise(r => setTimeout(r, 5));
  const pending = host.request(session, "handshake");
  const rejected = assert.rejects(pending, e => e.kind === "closed");
  await host.close();
  await rejected;
  assert.equal(host.pid, undefined);
  assert.equal(host.state, "closed");
});

test("raw wire type and byte limit are enforced before bridge startup", async () => {
  const host = acquireHostBridge(options());
  const session = host.createSession();
  await assert.rejects(host.request(session, "parse_core_review_decision", "中".repeat(2 * 1024 * 1024)), e => e.kind === "resource_limit");
  await assert.rejects(host.request(session, "parse_core_review_decision", {}), e => e.kind === "invalid_request");
  assert.equal(host.generation, 0);
  assert.equal(host.pid, undefined);
});


test("fd-exec, sandbox handshake, singleton, and opaque session handles", async () => {
  const host = acquireHostBridge(options());
  assert.equal(acquireHostBridge(options()), host);
  const session = host.createSession();
  const handshake = await host.request(session, "handshake");
  assert.equal(handshake.protocol, 2);
  assert.equal(handshake.bridgePatchSha256, expectedHandshake.bridgePatchSha256);
  assert.equal(host.state, "running");
  await assert.rejects(host.request({}, "handshake"), e => e.kind === "session");
  assert.throws(() => acquireHostBridge(options({ minimumGlibc: "99.0" })),
    e => e.kind === "version_isolation");
  await host.closeSession(session);
});

test("all seven methods produce explicit V1 IR and exact canonical wire", async () => {
  const host = acquireHostBridge(options());
  const session = host.createSession();
  const execWire = '{"call_id":"call","command":[],"cwd":"/work","parsed_cmd":[],"kind":"command","turn_id":"","started_at_ms":9223372036854775807,"reason":"line\\n\\\"quoted\\\""}';
  const exec = await host.request(session, "parse_core_exec", execWire);
  assert.equal(exec.ir.schemaVersion, 1);
  assert.equal(exec.ir.startedAtMs, "9223372036854775807");
  assert.equal(exec.ir.effectiveApprovalId, "call");
  assert.match(exec.canonicalWire, /9223372036854775807/u);
  const patch = await host.request(session, "parse_core_apply_patch",
    '{"call_id":"patch","changes":{},"started_at_ms":-9223372036854775808}');
  assert.equal(patch.ir.startedAtMs, "-9223372036854775808");
  assert.equal(patch.ir.schemaVersion, 1);
  const decision = await host.request(session, "parse_core_review_decision", '"approved"');
  assert.equal(decision.ir.decision, "approved");
  const ask = await host.request(session, "parse_core_ask_for_approval", '"on-failure"');
  assert.equal(ask.ir.policy, "on-request");
  const reviewer = await host.request(session, "parse_core_approvals_reviewer", '"guardian_subagent"');
  assert.equal(reviewer.ir.reviewer, "auto_review");
  const command = await host.request(session, "parse_v2_command_response", '{"decision":"accept"}');
  assert.equal(command.ir.decision, "accept");
  const file = await host.request(session, "parse_v2_file_response", '{"decision":"decline"}');
  assert.equal(file.ir.decision, "decline");
  for (const result of [decision, ask, reviewer, command, file]) assert.equal(result.ir.schemaVersion, 1);
});

test("request size and aggregate queued/inflight byte budgets fail before write", async () => {
  const host = acquireHostBridge(options({
    maxInflight: 1, maxQueue: 1, maxInflightBytes: 1024, maxQueueBytes: 1024,
  }));
  const session = host.createSession();
  await host.request(session, "handshake");
  await assert.rejects(host.request(session, "parse_core_review_decision", "x".repeat(4 * 1024 * 1024)),
    e => e.kind === "resource_limit");
  process.kill(host.pid, "SIGSTOP");
  const first = host.request(session, "handshake");
  const queued = host.request(session, "handshake");
  await assert.rejects(host.request(session, "handshake"), e => e.kind === "backpressure");
  process.kill(host.pid, "SIGCONT");
  await first;
  await queued;
});

test("AbortSignal kills generation and rejects collateral work across sessions", async () => {
  const host = acquireHostBridge(options({ maxInflight: 4 }));
  const firstSession = host.createSession(), secondSession = host.createSession();
  await host.request(firstSession, "handshake");
  const firstPid = host.pid;
  process.kill(firstPid, "SIGSTOP");
  const controller = new AbortController();
  const first = host.request(firstSession, "handshake", undefined, { signal: controller.signal });
  const second = host.request(secondSession, "handshake");
  controller.abort();
  await assert.rejects(first, e => e.kind === "cancelled");
  await assert.rejects(second, e => e.kind === "cancelled");
  assert.equal((await host.request(firstSession, "handshake")).protocol, 2);
  assert.notEqual(host.pid, firstPid);
});

test("id collision, artifact hash, immutable mode, and ABI checks fail closed", async () => {
  let ids = 0;
  const host = acquireHostBridge(options({ idFactory: () => (ids++ === 0 ? "bootstrap" : "same") }));
  const session = host.createSession();
  await host.request(session, "handshake");
  process.kill(host.pid, "SIGSTOP");
  const first = host.request(session, "handshake");
  await assert.rejects(host.request(session, "handshake"), e => e.kind === "id_collision");
  process.kill(host.pid, "SIGCONT");
  await first;
  await closeHostBridgeForTests();

  const badHash = options();
  badHash.bridge = { ...badHash.bridge, sha256: "0".repeat(64) };
  const hashHost = acquireHostBridge(badHash);
  await assert.rejects(hashHost.request(hashHost.createSession(), "handshake"), e => e.kind === "artifact");
  await closeHostBridgeForTests();
  assert.throws(() => acquireHostBridge(options({ minimumGlibc: "99.0" })), e => e.kind === "abi");
});

test("cross-session response is rejected and the generation is terminated", async () => {
  const mockExpected = {
    ...expectedHandshake,
    upstreamCommit: "9f97cb79eb15b38d24c552c56fe24e211ff9cf3a",
    bridgePatchSha256: "6d44f0519319f2f1a1c19d61e8c5fcdcc3c2136d916d0089175db34fa0f2d23f",
    os: "linux",
    arch: "x86_64",
  };
  const host = acquireHostBridge(options({ bridge: artifact(root + "mock-bridge.mjs"), expectedHandshake: mockExpected }));
  const session = host.createSession();
  await host.request(session, "handshake");
  await assert.rejects(host.request(session, "parse_core_review_decision", '"wrong-session"'), e => e.kind === "protocol");
  assert.equal(host.pid, undefined);
});

test("artifacts used by fd execution are regular immutable non-symlinks", () => {
  for (const path of [bridgePath, launcherPath]) {
    const stat = lstatSync(path);
    assert.equal(stat.isSymbolicLink(), false);
    assert.equal(stat.isFile(), true);
    assert.equal(stat.mode & 0o222, 0);
  }
});

test("Rust incremental framer rejects 4 MiB + 1 before an unbounded allocation", async () => {
  const child = spawn("/usr/bin/time", [
    "-v", launcherPath, "--ro", "/", "--rw", "/dev/null", "--", bridgePath,
  ], { stdio: ["pipe", "pipe", "pipe"] });
  const stdout = [], stderr = [];
  child.stdout.on("data", chunk => stdout.push(chunk));
  child.stderr.on("data", chunk => stderr.push(chunk));
  child.stdin.end(Buffer.alloc(4 * 1024 * 1024 + 1, 0x61));
  const { code, signal } = await new Promise(resolve => child.once("exit", (code, signal) => resolve({ code, signal })));
  const errorText = Buffer.concat(stderr).toString("utf8");
  const rss = /Maximum resident set size \(kbytes\):\s*(\d+)/u.exec(errorText);
  assert.equal(Buffer.concat(stdout).length, 0);
  assert.ok(code !== 0 || signal !== null);
  assert.ok(rss !== null && Number(rss[1]) < 64 * 1024, errorText);
});
