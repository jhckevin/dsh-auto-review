# 原生审批协议包 0.1.0-rc.1：发行候选与受保护安装

后续工作树的许可证材料门禁修复见 [ISSUE-032-LICENSE-MATERIALS.md](./ISSUE-032-LICENSE-MATERIALS.md)：严格区分 2 项精确上游原文与 10 项固定发布声明加规范正文。下文描述冻结 rc.1 tarball 的历史状态；旧制品没有被覆盖，新材料必须随未来新版本打包，不追溯宣称旧包通过。

当前生成公开命名的本地 tarball，不执行 npm publish。此前 prototype.5 文档描述历史证据；当前包名为 `@jhckevin/dsh-auto-review-bridge-host` 和 `@jhckevin/dsh-auto-review-bridge-linux-x64-gnu`，均为 `0.1.0-rc.1`。host 精确依赖同版 platform。法定原始 LICENSE/NOTICE 与上游引用保留，不能把协议 serde 桥接宣传为完整 Guardian 引擎。

## 用户 profile 与原生运行层分离

DSH profile 通常可由运行用户写入。其 npm/pnpm platform 目录不符合当前原生执行信任契约；同 UID chmod 0555 也不充分。新增环境变量：

```sh
DSH_AUTO_REVIEW_NATIVE_RUNTIME=/opt/dsh-auto-review-native/0.1.0-rc.1/node_modules/@jhckevin/dsh-auto-review-bridge-linux-x64-gnu
```

值必须是 platform 包根目录的现存绝对 canonical 路径，不能是 binary 路径、相对路径或 symlink。仍检查所有祖先 root-owned、组/其他用户不可写、当前非 root 运行用户不可写，并验证精确 package/manifest、size、SHA 与 same-fd 执行。错误配置直接失败，不回退用户可写依赖。未设置变量时保持通过依赖解析平台的原行为。

### 管理员首次安装示例（文档，不由插件执行）

先审核来源与 tarball 的 SHA256；在 root 管理终端执行，仅创建专用目录：

```sh
install -d -o root -g root -m 0755 /opt/dsh-auto-review-native/0.1.0-rc.1
npm install --prefix /opt/dsh-auto-review-native/0.1.0-rc.1 --offline --ignore-scripts --no-audit --no-fund /approved-artifacts/jhckevin-dsh-auto-review-bridge-linux-x64-gnu-0.1.0-rc.1.tgz
```

运行用户仍以非 root 启动 DSH，配置上述环境变量。用户 profile 可安装 host/AutoReview 插件并按插件范围启停；首次受保护 platform 安装与升级仍需管理员。插件不执行 sudo/chown、不修改宿主权限、不自动下载或编译二进制。没有管理员的安装方案需要另外选择并验证等价保护，不在本候选中冒充已支持。

host 本身属于 DSH 受信扩展代码；保护 platform 不意味着可抵御已被任意修改的 host JavaScript。

## 许可证证据的两种口径

12 项此前缺少上游 LICENSE 文本的依赖均在固定发布包声明了 MIT、Apache-2.0 或双许可。这不等于没有授权。

`packages/platform/provenance/license-declarations/` 包含：固定 Cargo.lock、逐 checksum 验证的 12 份原 .crate、119 份原始 manifest/README/Rust 文件、原声明/作者字段/已有 copyright 的位置，以及独立存放的 SPDX v3.27.0 标准全文。双许可优先附 Apache-2.0；MIT-only 保留标准正文，不虚构缺失的权利人或年份。标准正文明确不是那些 crate 原本随附的 LICENSE 文件。

`python3 check-license-declarations.py` 检查材料哈希、发布包成员逐字节相等和声明覆盖；该 PASS 不替代上游 LICENSE 文件完整性、法律审核、上游开发流程或完整 Guardian 移植门禁。原缺件门禁保持，不改成虚假 PASS。

## 固定来源包

`source-archive.py --upstream-repo <固定上游Git仓库> --revision <桥接源码commit> --out dist/<新目录>` 从明确 Git commit 归档，不带脏文件、缓存或 `.git`。压缩 mtime 固定为零，两次归档可逐字节比较；它不是新的二进制可重复构建证明。

## 本地候选验收

`Containerfile.public-package` 在既有无网络测试镜像中安装真实新 tarball；非 root、只读根下测试独立 owner，以及平台缺失/元数据损坏/same-UID/受保护路径等分支。测试不访问模型 API、不修改任何线上服务，也不代表未经支持的平台可用。旧 `Containerfile.scoped-*` 仅保留历史 private 工厂证据，不是本候选构建入口。

最终镜像 `daf3cf41d5efc316c60942aea34dfb86a3309d268d88f258c30473c69d68c9b1` 实跑 25/25 owner 与 12/12 包场景。原始日志 `evidence/public-package-final-run.log`。对应 tarball 在 `dist/public-rc1/`，host SHA256 `1fa0edd6d68811818622cdaff4bb240c743ad8484548d710c9b8629ca4415d27`，platform SHA256 `7e879d7384d2ede31ddeca0928d85e7f6203734232b49ea0aa8a32324424a24d`。
