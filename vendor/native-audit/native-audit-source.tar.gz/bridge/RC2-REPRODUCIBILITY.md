# rc2 build and package verification

This release candidate uses Rust 1.95.0 and the fixed development patch
`5cb90364c0a728dc97c278815905c5f6469a9139563fb08d17808908c1bef5c7`.
The two recorded isolated builds produced identical stripped binaries. This is
not a claim that rebuilding a floating apt image reproduces the builder image.
The builder ID, original command, dpkg inventory, toolchain output and source
proof are preserved in the two-build evidence and development execution record.

## Rebuild inputs

Use Linux x86-64, Python 3.12, Podman, the recorded immutable Debian 11 builder,
Rustup containing 1.95.0, and a prepopulated Cargo mirror cache. Prepare a **new**
root with an empty `target/`, `evidence/development.patch` copied from this
repository, and an independent upstream Git checkout in `src/` at commit
`9f97cb79eb15b38d24c552c56fe24e211ff9cf3a` with that patch applied. Mark new
patch-added files intent-to-add so `git diff --binary HEAD` includes them.
The builder verifies this exact diff before and after compilation.

```sh
python3 build-rc2-candidate.py --root "$NEW_BUILD_ROOT" \
  --cargo-home "$PREPARED_CARGO_HOME" --rustup-home "$PREPARED_RUSTUP_HOME" \
  --name native-rc2-independent-repro
```

The published driver is parameterized from the executed recipe, with an added
8 GiB free-space stop guard. It was syntax/CLI checked; the recorded two actual
builds used the archived recipe, not a retrospective execution of this wrapper.
It never downloads, deletes evidence, publishes, or replaces installed packages.
Source is mounted read-only; network is none; compilation uses one job/CPU and
4 GiB. Run the second build serially with another fresh source/target and compare
the stripped bytes. The original rc1 scripts now exit 2 instead of certifying rc2
with obsolete Rust/tool paths.

## Independent source/package checks

```sh
python3 license-evidence.test.py
python3 launcher-evidence.test.py
python3 verify-packed-licenses.test.py  # invokes actual npm pack
python3 verify-packed-licenses.py "$PLATFORM_TGZ"
python3 launcher-evidence.py --platform-root "$EXTRACTED_PLATFORM"
node --test evidence-gates.test.mjs development-evidence.test.mjs development-runner.test.mjs
```

Node tests do not replace actual upstream `just`/Bazel execution. The complete
source-bound f execution record is packaged separately; its independent verifier
must accept the candidate artifact manifest. License checks retain ten missing
upstream standalone files, original declarations and `legalApproval:false`.
The fixed `.source` mapping preserves npm-filtered originals without inferring
or inventing notices. The launcher is outside the 672 Rust components: both
official 0.1.1 npm archives, their original LICENSE files, package metadata, C
source and binary bytes are bound independently. No source-to-binary rebuild
claim is made for that unchanged official launcher.

`Containerfile.rc2-package` verifies upgrade/owner fixtures. The separate
`Containerfile.rc2-cold-proof` uses explicit fresh project manifests and checks
host-only platform absence; it is not claimed to be a pristine operating system.
Both use no network, root-owned installation followed by nonroot execution.
