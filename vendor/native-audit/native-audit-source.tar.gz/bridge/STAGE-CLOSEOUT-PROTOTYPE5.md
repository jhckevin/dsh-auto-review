# prototype.5 本轮限定修复归档

2026-09-02。本轮完成的是 native bridge 原型的安全/可靠性修复，不是完整 Auto Review 迁移或发布。

## 冻结结果

- 源码：`de31e9e6e05a5aa4e14c7858f6a33d1c4c097518`；之后仅有证据文档提交。
- 私有版本：`0.0.0-prototype.5`，没有推送、合入主插件或部署到线上。
- 主工作区仍为 `da79c3cd4285f20e857b6839e0515a60cfd62ae0`，原 approval-protocol.ts 草稿保留。
- 主审独立运行最终只读、离线、非 root 镜像：21/21 owner 与 9/9 安装包场景通过，见 `evidence/root-package-prototype5.log`。
- 主审再次运行组合 CI：证据测试 5/5，但总命令 exit 1，许可证缺失和上游受控 runner 未实现共同阻断，见 `evidence/root-combined-ci-prototype5.log`。没有最终 VALID。
- 两位独立审查者分别提交 `OWNER-RACE-REVIEW-PROTOTYPE5.md`、`OWNER-RACE-SECOND-REVIEW-PROTOTYPE5.md`，各自复跑最终镜像两次并给本次限定范围 PASS（0/0/0）。此前 CI 防误放行修复另有独立 PASS，见 `CI-EVIDENCE-REVIEW-PROTOTYPE4.md`。

## 本轮关闭的具体缺陷

- 原型键导致非函数调用、校验异常逃逸 stdout 回调。
- 单帧永远无法满足 inflight 预算仍入队、排队缺少期限。
- 取消、关闭和队列过期后的计数/字节预算与计时器回收。
- 非有限数字、负值、非整数、timer 溢出和聚合预算溢出的配置输入。
- 旧 child 的 EPIPE、stderr、drain、timer 等异步事件污染新 generation。
- CI 只信任自报 missing/status/evidence 而可能误放行。

真实 pipe 竞态回归先在 prototype.4 首轮复现失败，再在新版本连续 12 轮通过；独立审查另有重复实跑与原始复现。所有失败报告和原始日志保留，没有把未通过版本改写为通过。

## 下一步及未完成范围

1. 先完成固定上游要求的真实开发验收流程与测试布局，不能用手写 status 或现有 cargo test 替代。
2. 按 `B1-NEXT-MODULE-PLAN.md` 独立补齐 Exec 有效可选决定的原生派生、真实 oracle 和对应 IR/schema；计划中的 13 个正例与 3 个拒绝控制尚未实现。
3. 继续其余 B1 默认值、Core/V2 映射、ApprovalStore/PermissionRequest 生命周期，再推进中央审批和 Harness 接入；每模块冻结后独立复审。
4. 分发前解决剩余 12 项原始许可证材料缺口。本轮文件完整性核对不是法律充分性保证。

本轮没有 Flash/Pro 实际模型行为测试、WebUI 验收或生产灰度。不能用桥接测试数量推导模型安全率，也不能声称全部架构 100% 完成或不存在任何 BUG。
