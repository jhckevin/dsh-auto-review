# Owner prototype.5 generation race 第二独立复审

## 限定结论

**PASS，P0=0/P1=0/P2=0（本次已识别 owner race 修复及回归范围）。完整 B1 仍 FAIL，不得 close。**

- 审查者：`/root/protocol_coverage_review`。
- 冻结 commit：`de31e9e6e05a5aa4e14c7858f6a33d1c4c097518`。
- owner SHA256：`7e9bc2e8708568e2b9322ee0f35e164bf90107d6fee254fc52408d7111a4d1c9`，读取前核对一致。
- 镜像 ID：`495fbd85d47dcee6ccf19450a864c53893d2a90430fa4737b1683597a262ca93`。
- 与 prototype.4 `198ac99` 对照审查源码差异；没有修改源码、没有构建镜像或 Rust。唯一持久化为此报告。

## Diff 审查

新 `#isCurrent(child,generation)` 同时检查 child 对象身份与递增 generation，不依赖可能复用的 PID。

已核对覆盖以下异步边界：

- stdin write callback、同步 write throw 和写后 writeBlocked 更新。
- stderr data、stdin drain、stdin error、child error/exit。
- stdout data 入口及解析多个响应帧的每轮循环。
- inflight timeout（另检查 pending item 身份）、queue timeout（另检查 item 仍在queue）。
- abort listener（另检查 item 仍在pending或queue）。
- handshake 完成与晚到 startup failure catch。

因此已退役child的EPIPE回调不能再无条件调用restart并终止新child；旧stderr/drain不能污染新代次计数和写阻塞状态。旧generation的timer/abort亦不能通过重用request id错误作用于新item。现有failAll继续清timer/listener/pending/queue。

proto-key own属性检查、method validator异常收敛、数值配置、队列独立期限均保留；此次diff未撤销上轮修复。

## 独立执行

直接运行冻结镜像两次，不重建：`podman run --pull=never --rm --network=none --read-only --tmpfs /tmp:rw,noexec,nosuid,nodev,size=16m <固定镜像ID>`。

两次均退出0；每次：

- owner **21/21 PASS**，0 fail/cancel/skip。
- 包 **9/9 PASS**，uid65532；负面场景表示按预期拒绝。

真实pipe race是21个测试中的一个，每次内部12轮（本审查累计24轮），不是mock callback：启动真实Rust bridge，SIGSTOP旧PID，发送1 MiB拒绝文本形成未完成stdin写，20ms后abort，并在zero backoff下立即请求replacement握手。断言旧pending cancelled、新握手成功、generation恰加1、PID改变、随后approved正常。本轮独立实际执行，不再仅引用其他reviewer的复现。

完整21项亦包括三入口乘四原型名的真实mock-child负例、validator意外异常、queue过期/预算释放、关闭/取消晚到计时器、无重放新generation、配置非法值、七接口基础IR和4 MiB输入边界。

## 不变的限制

本次没有逐一人工注入所有旧stderr/drain/timer事件；这些由源码guard审查加已有生命周期回归支撑，不声明所有调度组合已穷尽。21个测试和24轮真实race不构成零缺陷保证。

许可证、upstream-development、完整B1协议覆盖、中央审批生命周期、生产部署与WebUI均不在本次PASS内。原完整B1 FAIL和历史失败报告保持；只能记录此owner race修复在冻结snapshot上独立复审通过。
