#!/opt/node/bin/node
import readline from "node:readline";
const handshake = {protocol: 2, upstreamCommit: "9f97cb79eb15b38d24c552c56fe24e211ff9cf3a",
  bridgePatchSha256: "6d44f0519319f2f1a1c19d61e8c5fcdcc3c2136d916d0089175db34fa0f2d23f",
  irVersion: 1, os: "linux", arch: "x86_64",
  hardening: {noNewPrivileges: true, network: "seccomp-deny", filesystem: "seccomp-deny-open-plus-launcher", rlimits: true}};
const batched = [];
let dispatched = 0;
for await (const line of readline.createInterface({input: process.stdin})) {
  const request = JSON.parse(line);
  let result = handshake;
  if (request.method !== "handshake") {
    dispatched += 1;
    result = {canonicalWire: '"approved"', ir: {schemaVersion: 1, decision: "approved"}};
    if (request.wire === '"bad-ir"') result.ir.schemaVersion = 2;
    if (request.wire === '"bad-canonical"') result.canonicalWire = {};
    if (request.wire === '"coalesce"') {
      const decision = {denied: {rejection: "x".repeat(280)}};
      result = {canonicalWire: JSON.stringify(decision), ir: {schemaVersion: 1, decision}};
    }
    if (request.wire === '"dispatch-count"') result.ir.decision = {denied: {rejection: String(dispatched)}};
    if (request.wire?.startsWith('"prototype:')) {
      const key = JSON.parse(request.wire).slice("prototype:".length);
      const variant = JSON.parse(`{"${key}":{}}`);
      result.ir = {schemaVersion: 1, [request.method === "parse_core_ask_for_approval" ? "policy" : "decision"]: variant};
    }
    if (request.wire === '"must-not-run"') result.canonicalWire = {};
  }
  if (request.wire === '"bad-handshake-coercion"') result = {...handshake, upstreamCommit: {toString: null}};
  const response = JSON.stringify({id: request.id, session_id: request.wire === '"wrong-session"' ? "wrong-session" : request.session_id, ok: true, result}) + "\n";
  if (request.wire === '"hold"') continue;
  if (request.wire?.startsWith('"delay:')) {
    setTimeout(() => process.stdout.write(response), Number(JSON.parse(request.wire).slice(6)));
  } else if (request.wire === '"coalesce"') {
    batched.push(response); if (batched.length === 2) process.stdout.write(batched.splice(0).join(""));
  } else process.stdout.write(response);
}
