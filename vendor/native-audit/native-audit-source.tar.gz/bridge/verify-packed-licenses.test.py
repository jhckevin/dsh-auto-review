#!/usr/bin/env python3
"""Real npm pack/extraction regressions, not source-tree-only assertions."""
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tarfile
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('packed', ROOT/'verify-packed-licenses.py')
packed = importlib.util.module_from_spec(spec)
spec.loader.exec_module(packed)

class PackedTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='actual-npm-pack-')
        cls.folder = Path(cls.temp.name)
        result = subprocess.run(['npm','pack',str(ROOT/'packages/platform'),'--ignore-scripts','--json',
                                 '--pack-destination',str(cls.folder)],check=True,capture_output=True,text=True,timeout=60)
        cls.archive = cls.folder/json.loads(result.stdout)[0]['filename']

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def test_actual_npm_pack_has_all_1350_bound_materials(self):
        self.assertEqual(packed.verify_archive(self.archive)['verifiedMaterialReferences'],1350)

    def test_extracted_missing_orig_and_self_relabel_both_fail(self):
        with tempfile.TemporaryDirectory(prefix='npm-negative-') as temp:
            platform = packed.extract_package(self.archive,Path(temp))
            path = platform/'licenses/debugserver-types@0.5.0/original-crate/Cargo.toml.orig.source'
            path.rename(path.with_name(path.name+'.extra'))
            with self.assertRaises(ValueError): packed.verify_tree(platform)
            coverage = platform/'provenance/license-material-coverage.json'
            doc = json.loads(coverage.read_text())
            for item in doc['components']['debugserver-types@0.5.0']['originalCrateFiles']:
                if item['materialPath'].endswith('Cargo.toml.orig.source'): item['materialPath'] += '.extra'
            coverage.write_text(json.dumps(doc))
            with self.assertRaises(ValueError): packed.verify_tree(platform)

    def test_extracted_other_component_material_hash_tamper_fails(self):
        with tempfile.TemporaryDirectory(prefix='npm-negative-') as temp:
            platform = packed.extract_package(self.archive,Path(temp))
            sbom = json.loads((platform/'provenance/sbom.cdx.json').read_text())
            component = next(x for x in sbom['components'] if x['bom-ref'] not in packed.gate.EXPECTED)
            paths = json.loads(next(x['value'] for x in component['properties'] if x['name']=='licenseMaterials'))
            (platform/paths[0]['path']).write_bytes(b'forged copyright')
            with self.assertRaisesRegex(ValueError,'hash mismatch'): packed.verify_tree(platform)

    def test_tar_traversal_links_duplicates_fail(self):
        for kind in ('traversal','symlink','duplicate'):
            with self.subTest(kind=kind), tempfile.TemporaryDirectory(prefix='npm-unsafe-') as temp:
                root = Path(temp)
                archive = root/'unsafe.tgz'
                with tarfile.open(archive,'w:gz') as out:
                    item = tarfile.TarInfo('package/../escape' if kind=='traversal' else 'package/file')
                    if kind=='symlink':
                        item.type=tarfile.SYMTYPE
                        item.linkname='/etc/passwd'
                        out.addfile(item)
                    else:
                        item.size=1
                        out.addfile(item,io.BytesIO(b'x'))
                        if kind=='duplicate': out.addfile(item,io.BytesIO(b'x'))
                dest=root/'unpack'
                dest.mkdir()
                with self.assertRaises(ValueError): packed.extract_package(archive,dest)

if __name__ == '__main__': unittest.main(verbosity=2)
