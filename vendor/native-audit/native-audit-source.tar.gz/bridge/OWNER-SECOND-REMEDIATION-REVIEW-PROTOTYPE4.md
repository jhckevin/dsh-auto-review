# Owner prototype.4 第二独立修复复审

## 限定结论

**本次 owner 修复范围 PASS，P0=0/P1=0/P2=0。完整 B1 仍 FAIL，不得 close 或标整体 complete。**

此 PASS 关闭本审查者先前的 externalVariant 原型键异常问题，并核验本次 validator 异常边界、队列期限与数值配置整改；不等于完整协议、生产集成、许可证或可复现构建全部通过。旧 FAIL 报告保留，不改写历史。

- 审查者：`/root/protocol_coverage_review`。
- 冻结 commit：`198ac99ddf8bf136fdfb4a4373b65eaca2ca22ec`。
- owner SHA256：`efd4cc34a16707e85713ad981119477156711c0e99c8a35b4f4ea5c30a1f6a3d`。
- 独立执行镜像：`dbddb9a31f323bf4a83a31cc8bf3ea45570c0b27a98ef84dab4e57f37042cb19`。
- 开始核对 HEAD 与固定 commit 相同、owner hash 一致。结束仅有其他操作者新增 evidence 日志；未改源码。没有大构建，唯一持久写入为本报告。

## 修复核验

1. `externalVariant` 先 `Object.hasOwn(variants,key)`，再检查 handler 为 function。原先 own `__proto__` 取到原型后调用的路径被关闭。
2. `#onData` 将整个 `validateMethodResult` 放入 try/catch；false 或意外抛错统一成 protocol BridgeFailure，restart generation，不再越过 stdout 回调。
3. mock 子进程实际返回三入口（CoreDecision/V2CommandDecision/Granular）乘四原型名的畸形 IR；不是只用对象字面量假造 __proto__。每轮同时存在 hold 请求，全部 pending 均 protocol 拒绝，pid 清空、状态 backoff；新 generation 的 dispatch-count 为 1，证明未重放旧请求且可恢复。
4. bad-handshake-coercion 触发 validator 内意外异常；仍 protocol 拒绝并可创建新 generation。
5. 单请求若永远超过 maxInflightBytes，在入队前拒绝。队列独立 queueTimeoutMs，performance.now 截止检查；过期移除、释放字节和 abort listener；转 inflight 清 queue timer并获得完整执行timeout。
6. failAll/abort/close 清 queue timer；已移出队列项不能重复settle。已覆盖关闭/取消后等待过期窗口而无晚到generation变化。
7. normalizedOptions 限制数值为 safe integer；timer不超2147483647，非零必要项>=1，queue和backoff可为0；验证backoff顺序及聚合加法不溢出。NaN/Infinity/负数/小数不再破坏预算和timer比较。

## 独立执行结果

直接运行冻结镜像，无重新build，参数：`--pull=never --rm --network=none --read-only --tmpfs /tmp:rw,noexec,nosuid,nodev,size=16m`。

- Owner：**20/20 PASS**；0 fail/skip/cancel。
- 包：**9/9 PASS**；全部uid65532。installed成功；same-uid、host-only、manifest-extra/version/path/size/symlink、package-version均按预期拒绝。负例passed不表示允许安装物使用。

额外只读临时data-module验证（只导出原函数、未替换实现、未写测试源文件）：

- 三 externalVariant 入口 × 六 own原型相关名称（__proto__、constructor、toString、valueOf、hasOwnProperty、__defineGetter__）：**18/18返回false，不抛异常**。
- 12个timer/预算字段 × 10个非法值（true、字符串1、对象、数组、BigInt 1、NaN、Infinity、-Infinity、-1、0.5）：**120/120为configuration拒绝**。
- maxQueue=0、maxQueueBytes=0、baseBackoffMs=0、maxBackoffMs=0：接受，零队列/零backoff仍可配置。

## 不变的边界

- unknown-field严格校验仅作用于内部IR；上游输入raw serde规则仍由Rust控制。
- canonicalWire及additionalPermissionsWire仍为原始字符串；此复审未将其转换为JS Number授权结构，也未声称验证完整canonical/IR语义一致性。
- 许可证12项缺失、upstream-development pending及整个B1覆盖缺口并未由owner修复解决。组合CI不得绕过这些失败。
- 本次不重验Rust编译、全量源对二进制可复现、供应链许可、完整B1/中央审批运行时或WebUI。

仅在以上明确范围内允许记录prototype.4 owner整改通过；继续保留完整B1 FAIL状态。

## 后续独立发现补充（未由本审查者复现）

主审随后转达另一位 security reviewer 在同一 `198ac99` 快照发现真实 P2：zero backoff、real pipe SIGSTOP、约 1 MB 写入、abort 后立即重启时，旧 stdin write callback 的 EPIPE 因没有 child/generation guard 可错误终止新 generation；stderr/drain 回调亦缺少同类 guard。实现者正在 prototype.5 修复。

本补充保留上述已完成限定整改的历史 PASS，但**不能将其解释为 prototype.4 版本整体通过**。此问题为其他独立审查者发现，本审查者尚未重跑该 race；待 prototype.5 冻结后另作 diff、race 和总回归复审。完整 B1 与版本总验收仍未通过。
