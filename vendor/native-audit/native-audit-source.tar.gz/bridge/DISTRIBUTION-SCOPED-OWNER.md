# ISSUE-027A：插件范围的原生协议 owner

状态：发行准备，不是公开发布。包名和版本仍为 private prototype.5；许可证材料与上游开发流程门禁没有通过。

## 接口

- `createCodexApprovalBridge()`：平台包入口，每次生成独立 owner。保持平台、root-owned 元数据、固定 provenance 与 same-fd 二进制校验，不放宽到普通用户可写安装目录。
- `createHostBridge(options)`：底层独立 owner 工厂，经过现有完整 options 校验。
- owner 方法不变：`createSession()`、`request(session, method, wire, options)`、`closeSession(session)`、`close()`；只读 `pid/state/generation`。
- 旧 `acquireCodexApprovalBridge()` / `acquireHostBridge()` 保留 singleton 语义，给未迁移消费者使用。

`close()` 不影响其他工厂 owner 或 legacy singleton。它同步停止接收该 owner 的新任务，拒绝 pending/queue，令旧代次异步回调失效，并返回共享的关闭 Promise。先等待 shutdownMs 正常退出，超时后 SIGKILL，再等待 shutdownMs 观察退出；仍未观察到退出则以 shutdown_timeout 拒绝，不能报告已成功销毁。状态最终 closed，不会重新启动。新插件 scope 必须创建新 owner，不能复用旧 closed owner，也不能调用全局 test reset。

该桥接只提供固定上游协议的原生 serde/IR，不是完整 Guardian 风险判断引擎。

## 本轮证据

`evidence/scoped-owner-initial.log`：真实 Rust child + 原生 launcher，非 root uid65532、只读根、无网络、1 CPU、512MiB、128 PID。

- 原有 21 项 owner 回归与新增 4 项范围/关闭回归：25/25。
- 已安装包及 same-UID、缺件、篡改 manifest 等原有 9 场景：9/9。
- 新案例覆盖：两个 owner 的 session/child 隔离、关闭后新建、与 legacy 并存、堵塞进程强制退出、启动阶段关闭、并发 close Promise 幂等。
- 镜像 de1c92a022a4340d79512d1eda6a8398ae4d1eb6c9ec775676e40e6f919da306，基于已存在 prototype.5 安装镜像，仅覆盖新 JS 和测试文件。不是新双 tarball 验收，也没有重编 Rust。

## 分发仍需完成

1. 完成剩余 12 项许可证来源材料取证及独立审核，不以 SPDX 字符串或改写标准文本伪装原文。
2. 完成上游要求的开发/构建门禁，重新验证必要来源、二进制、SBOM 和发行包。
3. 用户确定公开命名范围后统一修改 host/platform/预期 provenance，并使用可复现源码包及新 tarball 验收；当前不实际 publish。
4. 普通 npm/pnpm 用户目录与 symlink 不满足当前信任边界。热插拔插件不等于可以无条件热装原生受信执行组件。需要受信只读安装层，或另行证明 DSH 提供等价保护后审查新的信任方案；本提交没有降低校验。
