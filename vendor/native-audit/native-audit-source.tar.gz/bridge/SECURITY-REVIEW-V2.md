# Native bridge V2 independent security review

Date: 2026-09-02. Reviewer: bridge_security_review. Verdict: FAIL.
Severity totals: P0=0, P1=5, P2=2. This is not a release acceptance.

## Reviewed snapshot and scope

- Fixed upstream Codex: `9f97cb79eb15b38d24c552c56fe24e211ff9cf3a`.
- Reviewed OLD Rust patch SHA256: `6d44f0519319f2f1a1c19d61e8c5fcdcc3c2136d916d0089175db34fa0f2d23f`.
- Last-read owner SHA256: `d1728191c0276a431997543e1bf79af152c479e60d5c38655007e041b8278272`.
- Last-read `packages/host/index.mjs` SHA256: `7bfe9630aebdb6d7bde3a65a99f6f4f88d71e08f802a86ea1370104790da0577`.
- Tested old GNU2.31 binary SHA256: `0ad7c1efa3287a35313e9d6ea6a19ebc5ab9962f588432051ea6759d33f41c4f`.
- Paths below are relative to `/srv/pi-lab-dev/tmp/issue022b-native-bridge-prototype/` unless stated otherwise.
- Review was read-only. Only this report was subsequently added with the approved remote safe apply_patch wrapper. No source edits or large Rust builds were performed by this reviewer.

The implementer changed root-owned artifact checks during this review. The closed-session reproduction ran before that change; its lifecycle code was confirmed unchanged in the last-read owner above. Same-UID configuration was no longer usable for follow-up dynamic tests after the new gate. No in-flight remediation is represented as passed. Re-review requires frozen new hashes and new test evidence.

## P1-1: Unicode error truncation crashes the shared bridge

Location: old `codex-bridge-v2.patch:231-235`, generated Rust `approval-protocol-bridge-prototype/src/main.rs:166-170`.

`message.truncate(4096)` does not align to a UTF-8 character boundary. A bounded, invalid enum string can panic instead of returning a typed Serde failure. One session can therefore terminate the shared bridge and reject collateral in-flight work.

Actual isolated reproduction using the old GNU2.31 binary:

```js
import { spawnSync } from 'node:child_process';
for (let n = 0; n < 3; n++) {
  const wire = JSON.stringify('x'.repeat(n) + '中'.repeat(1800));
  const p = spawnSync('./codex-approval-protocol-bridge-v2.linux-x64-gnu2.31', {
    input: JSON.stringify({ id: 'i', session_id: 's', method: 'parse_core_review_decision', wire }) + '\n',
    encoding: 'utf8',
  });
  console.log({ prefix: n, status: p.status, signal: p.signal, stdoutBytes: p.stdout.length, stderr: p.stderr });
}
```

Observed prefix=0 and prefix=1: exit 101, stdout 0, `assertion failed: self.is_char_boundary(new_len)` at Rust main.rs:169. Prefix=2: exit 0, normal Serde error response. The first request is approximately 5.4KB, far below the frame cap.

Required: truncate at a valid UTF-8 boundary and add long multilingual Serde diagnostics plus collateral-session regression tests.

## P1-2: Session/host closure races asynchronous startup

Locations in last-read owner: `bridge-owner-v2.mjs:181-199,263-265`.

`request()` checks session membership only before `await #start()`. Closing the session during startup does not cancel the waiting caller or revalidate its membership after the await.

Actual reproduction on the pre-root-gate owner, using real immutable-mode prototype binaries and the then-supported same-UID test configuration:

```js
const session = host.createSession();
const pending = host.request(session, 'parse_core_review_decision', '"approved"');
await host.closeSession(session);
console.log(await pending, host.state);
```

Observed: `{ canonicalWire: '"approved"', ir: { decision: 'approved', schemaVersion: 1 } }`, state `running`. The closed session's request completed successfully. The affected request/start logic remained unchanged at owner SHA d1728191 above.

Related statically confirmed branch: `#spawnAndHandshake()` waits through backoff but does not recheck closed state or generation afterward. `close()` can finish while that timer is pending; the old startup can then spawn and set state to running. A follow-up reproduction was stopped by the new root-owned gate, so this branch is not labeled dynamically reproduced.

Required: cancellation/generation ownership for startup; state/session/generation rechecks after every await; close must prevent all pending startup from resurrecting the host. Include close-during-start, close-during-backoff, session-close-during-start, and stale callback tests.

## P1-3: Node input limits are enforced after unbounded allocations

Location: last-read `bridge-owner-v2.mjs:181-199`.

No primitive string type or raw wire byte-length validation precedes startup and envelope construction. Code runs `JSON.stringify(envelope)` and `Buffer.from(...)` before checking 4MiB, and before queue/in-flight aggregate budgets. A huge string can allocate several huge copies first; an object can also invoke `toJSON`. Rust incremental framing does not protect Node.

Required: validate method and primitive wire type, bound raw bytes before serialization/startup, then bounded envelope/escaping size and aggregate admission. Do not call current tests proof of pre-allocation rejection: they only establish pre-write rejection.

## P1-4: Package manifest is not part of the verified trust chain

Location: `packages/host/index.mjs:8-11,24-37` at SHA 7bfe9630 above.

Manifest is read and parsed before owner/symlink/writability/size/schema checks on that file. The manifest's own commit, patch and artifact hashes then supply the expected values. `spec.path` is not constrained to the platform package, so traversal can select another root-owned old binary. Exact optionalDependencies metadata does not verify the resolved runtime package version.

The latest owner fixes same-UID and trustRoot=file bypasses for executable paths, but does not establish manifest trust. This is a trust-chain and rollback-selection gap, not an experimentally demonstrated arbitrary-code-execution claim.

Required: bounded trusted manifest loading, exact schema/platform/package-version validation, host-pinned provenance binding, package-local artifact containment and symlink checks. Reject malformed/mutable manifests before resolving artifacts.

## P1-5: Old seccomp hardening claim exceeds the actual filter

Location: old `codex-bridge-v2.patch:391-465`.

The old x86_64 filter checks architecture, compares a blacklist of native syscall numbers, then defaults to ALLOW. It does not reject the x32 syscall bit. On x32-enabled kernels, x32 syscall numbers can evade native-number comparisons. io_uring indirect file/network operations and clone3 are omitted. ptrace/process_vm operations are also unfiltered. open_by_handle_at has additional capability requirements and is not by itself a demonstrated bypass.

Existing socket/open single probes cannot establish the full advertised network/filesystem/process boundary. Scope: safe Rust JSON parsing does not normally issue these calls. This is a defense-in-depth boundary deficiency if the native process/dependency is compromised; no claim that ordinary JSON can directly escape was tested or made.

Required: a minimal syscall allowlist with unknown/x32 calls denied, tests of indirect syscall paths, and precise hardening wording. Alternatively narrow the contract rather than claiming a complete no-network sandbox from two probes. The bridge does not replace the parent Harness sandbox.

## P2-1: Response cap is checked on a chunk aggregate, not each frame

Location: original owner lines 349-359, shifted by +8 in SHA d1728191.

Before splitting newlines, `buffer.length + chunk.length` is compared with maxResponseFrameBytes. A valid near-cap frame tail and the next frame coalesced into one OS chunk can be incorrectly rejected. Split and validate incrementally per frame, bounding only the incomplete frame.

Also canonicalWire and IR duplicate portions of payload. Valid near-cap input may produce an over-cap output. Define this as an explicit response-size/resource rejection, not an unexplained malformed-protocol restart that also rejects unrelated sessions.

## P2-2: Successful method-specific IR is not validated at reception

Location: original owner lines 97-124 and 363-372, shifted by +8 in SHA d1728191.

Success only requires an object result. It does not validate canonicalWire type, IR schemaVersion, method-specific required fields or i64 decimal encoding. Handshake checks an arbitrary expected subset rather than the complete versioned contract.

Rust's seven explicit IR structs and direct pinned Serde are real improvements, but do not replace Node's typed receive-boundary checks. Validate success according to the pending method and fixed IR version. Missing broader B1 methods are not counted as defects of this seven-method prototype.

## Improvements actually observed

- Rust incoming framer bounds bytes before extend.
- Node queue/in-flight byte budgets, fatal UTF-8 and cumulative stderr limits exist.
- Request/session response pairing, collateral rejection on cancellation and no implicit replay exist.
- Same-fd hashing and `/proc/self/fd` execution are implemented.
- Last-read owner requires non-root runtime, root-owned entire executable ancestry and actual write-permission rejection. The old same-UID success is not a production acceptance.
- Rust IR directly uses fixed upstream Serde; both observed i64 timestamp fields become decimal strings.
- Rust applies RLIMIT_AS/FSIZE/NOFILE/NPROC, no_new_privs and seccomp before handshake, not just in documentation.

## Acceptance status

FAIL remains the verdict for the reviewed snapshots. Eight existing unit tests do not constitute complete safety or production acceptance. New patch/hash/builds occurring during or after this review require a separate frozen-source re-review; this report must remain as historical failure evidence.
