# ISSUE-032：公开源码交付与轻量 native-audit CI

## 交付边界

`source-archive.py` 对显式 Git commit 执行 `git archive`，不混入未跟踪缓存、
运行目录、凭据或新旧二进制。上游固定为
`9f97cb79eb15b38d24c552c56fe24e211ff9cf3a`。完整第三方材料保留在
`packages/platform/licenses` 与 `packages/platform/provenance`，不可只摘出审计汇总。

manifest v2 从被归档 commit 的 `license-audit.json` 读取材料口径，而非使用当前
工作树：672 个组件材料覆盖、0 个材料缺口、10 个未找到上游原始 LICENSE 文件的
组件继续分别记录，`legalApproval=false`。这不是法律充分性结论，也不是重新运行
全部门禁。十项已附固定发布包声明、原始源码与明确标注来源的规范许可正文，
不能将其重命名为已恢复的上游原 LICENSE。

`releaseEligible=false` 保留：完整上游开发门禁与更新后二进制的构建/可重复性验收
尚未闭环。已有旧 tgz/binary 不因新源码档案而获得更新或新的通过声明。

## 可用于公开 Actions 的独立小型目录

可以将以下跟踪文件按原相对路径放入 `native-audit/`，不要调用主 `ci-check.sh`：

- `development-runner.mjs`、`development-evidence.mjs`、`development-runner.test.mjs`
- `evidence-gates.mjs`、`evidence-gates.test.mjs`
- `license-evidence.py`、`license-evidence.test.py`、`license-source-gate.test.mjs`
- `source-archive.py`、`source-archive.test.py`
- `packages/platform/provenance/`、`packages/platform/licenses/`
- `packages/platform/artifact-manifest.json`、`packages/platform/LICENSE`、
  `packages/platform/NOTICE`

环境只需 Linux、Node.js 24 与 Python 3.11+；无需 npm install、Rust 编译、模型
API 或 native binary。在 `native-audit/` 下执行：

```sh
mkdir -p dist
node --test development-runner.test.mjs evidence-gates.test.mjs license-source-gate.test.mjs
python3 license-evidence.test.py
python3 source-archive.test.py
```

这些测试覆盖真实有界子进程日志/退出、伪造执行证据拒绝、路径与符号链接拒绝、
672 组件许可材料哈希、错误来源分类及部分材料篡改拒绝。测试中的小型 Node
子进程不是 Rust 运行结果。`evidence-gates.test.mjs` 刻意断言当前完整开发证据
不能被接受，不能把该测试成功解释为开发门禁成功。

建议 Actions job 命名为 `native-audit-source-and-negative-tests`，权限仅
`contents: read`，10 分钟超时，失败也上传日志；保持独立的完整 native 开发/
重构建门禁状态。既不在该 job 中调用 `development-runner.mjs` 执行全上游计划，
也不上传旧 binary 冒充本 commit 编译产物。

## 证据定位

实际导出目录及 SHA256 在独立交付时报告，不能把旧版本 `dist/public-source-a`
或旧证据日志的 PASS 自动继承给新提交。归档内历史工程日志只作为历史记录，
manifest 的明确 commit 和门禁范围优先；不包含用户模型会话轨迹。
